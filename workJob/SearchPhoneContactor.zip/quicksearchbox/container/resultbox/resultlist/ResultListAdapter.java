package com.smartisanos.quicksearchbox.container.resultbox.resultlist;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.smartisanos.home.R;
import com.smartisanos.quicksearchbox.container.resultbox.resultlist.item.doublesingle.ItemDoubleSingle;
import com.smartisanos.quicksearchbox.container.resultbox.resultlist.item.title.ItemTitle;
import com.smartisanos.quicksearchbox.ibase.BaseItemOnClikcListener;
import com.smartisanos.quicksearchbox.repository.ui.bean.BaseBean;
import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.DoubleSingleItemBean;
import com.smartisanos.quicksearchbox.repository.ui.bean.title.TitleBean;
import com.smartisanos.quicksearchbox.util.GuavaUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by anmingyu on 16-9-2.
 */
public class ResultListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements ResultListContract.Presenter {

    private Context mContext;
    private LayoutInflater mLayoutInflater;

    //datastructrue
    private List<BaseBean> mRealDataList;

    //private ResultListContract.OnResultListItemClickListener mOnResultListItemClickListener;

    public ResultListAdapter(Context context, HashMap<String, List<DoubleSingleItemBean>> dataMap) {
        mContext = GuavaUtil.checkNotNull(context);
        mLayoutInflater = LayoutInflater.from(context);
        init(GuavaUtil.checkNotNull(dataMap));
    }

    public void init(HashMap<String, List<DoubleSingleItemBean>> dataMap) {
        mRealDataList = dataMapToDataList(dataMap);
    }

    private List<BaseBean> dataMapToDataList(HashMap<String, List<DoubleSingleItemBean>> dataMap) {
        boolean onlySearchOnlineFlag = true;
        //apps
        if (mRealDataList == null) {
            mRealDataList = new ArrayList<BaseBean>();
        }
        String appTitle = mContext.getString(R.string.resultgroup_title_app);
        if (dataMap.containsKey(appTitle) && (!(dataMap.get(appTitle).size() < 1))) {
            onlySearchOnlineFlag = false;
            mRealDataList.add(new TitleBean(appTitle));
            mRealDataList.addAll(dataMap.get(appTitle));
            //showmore
        }
        //contacts
        String contactTitle = mContext.getString(R.string.resultgroup_title_contact);
        if (dataMap.containsKey(contactTitle) && dataMap.get(contactTitle) != null && (!(dataMap.get(contactTitle).size() < 1))) {
            onlySearchOnlineFlag = false;
            mRealDataList.add(new TitleBean(contactTitle));
            mRealDataList.addAll(dataMap.get(contactTitle));
        }
        //more
        String moreTitle = mContext.getString(R.string.resultgroup_title_more);
        if (dataMap.containsKey(moreTitle)) {
            if (!onlySearchOnlineFlag) {
                mRealDataList.add(new TitleBean(moreTitle));
            }
            mRealDataList.addAll(dataMap.get(moreTitle));
        }
        /*
        //record
        String recordTitle = mContext.getString(R.string.resultgroup_title_record);
        if (dataMap.containsKey(recordTitle)) {
            mRealDataList.add(new TitleBean(recordTitle));
            mRealDataList.addAll(dataMap.get(recordTitle));
        }
        */
        return mRealDataList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ItemDoubleSingle itemDoubleSingle;
        ViewHolderDoubleSingleItem viewHolderDoubleSingleItem;
        switch (viewType) {
            case BaseBean.TYPE_TITLE: {
                ItemTitle itemTitle = (ItemTitle) mLayoutInflater.inflate(R.layout.resultlist_item_grouptitle, parent, false);
                ViewHolderTitle viewHolderTitle = new ViewHolderTitle(itemTitle);
                return viewHolderTitle;
            }
            case BaseBean.TYPE_ITEM_APP: {
                itemDoubleSingle = (ItemDoubleSingle) mLayoutInflater.inflate(R.layout.resultlist_item_doublesingle_app, parent, false);
                viewHolderDoubleSingleItem = new ViewHolderDoubleSingleItem(itemDoubleSingle);
                return viewHolderDoubleSingleItem;
            }
            case BaseBean.TYPE_ITEM_CONTACT:
            case BaseBean.TYPE_ITEM_CLEARRECORD:
            case BaseBean.TYPE_ITEM_SEARCHONLINE:
            case BaseBean.TYPE_ITEM_DISPLAYMORE: {
                itemDoubleSingle = (ItemDoubleSingle) mLayoutInflater.inflate(R.layout.resultlist_item_doublesingle, parent, false);
                viewHolderDoubleSingleItem = new ViewHolderDoubleSingleItem(itemDoubleSingle);
                return viewHolderDoubleSingleItem;
            }
        }
        return null;
    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ViewHolderTitle) {
            TitleBean titleBean = (TitleBean) mRealDataList.get(position);
            String text = titleBean.getTitle();
            ((ViewHolderTitle) holder).getTitleView().setText(text);
        } else if (holder instanceof ViewHolderDoubleSingleItem) {
            //view
            final ItemDoubleSingle itemDoubleSingle = ((ViewHolderDoubleSingleItem) holder).getItemDoubleSingle();
            //bean
            final DoubleSingleItemBean doubleSingleItemBean = (DoubleSingleItemBean) mRealDataList.get(position);
            switch (doubleSingleItemBean.getType()) {
                //app,contact,searchonline的onclick都是intent
                case BaseBean.TYPE_ITEM_APP:
                case BaseBean.TYPE_ITEM_CONTACT:
                case BaseBean.TYPE_ITEM_SEARCHONLINE: {
                    itemDoubleSingle.setLongClickable(false);
                    itemDoubleSingle.setBackgroundResource(R.drawable.resultlist_item_bg_seletor);
                    itemDoubleSingle.create(doubleSingleItemBean);
                }
                break;
                case BaseBean.TYPE_ITEM_CLEARRECORD: {
                    itemDoubleSingle.setBackgroundResource(R.drawable.resultlist_item_bg_seletor);
                    doubleSingleItemBean.setBaseItemOnClikcListener(new BaseItemOnClikcListener() {
                        @Override
                        public boolean longClick() {
                            return false;
                        }

                        @Override
                        public void onClick() {

                        }
                    });
                    itemDoubleSingle.create(doubleSingleItemBean);
                    itemDoubleSingle.setLongClickable(false);
                }
                break;
                case BaseBean.TYPE_ITEM_DISPLAYMORE: {
                    itemDoubleSingle.setBackgroundResource(R.drawable.resultlist_item_bg_nophoto_selector);
                    doubleSingleItemBean.setBaseItemOnClikcListener(new BaseItemOnClikcListener() {
                        @Override
                        public boolean longClick() {
                            return false;
                        }

                        @Override
                        public void onClick() {

                        }
                    });
                    itemDoubleSingle.create(doubleSingleItemBean);
                    itemDoubleSingle.setLongClickable(false);
                    break;
                }
            }
        }
    }

    @Override
    public int getItemViewType(int position) {
        return mRealDataList.get(position).getType();
    }

    @Override
    public int getItemCount() {
        return mRealDataList.size();
    }

    @Override
    public void init() {

    }

    @Override
    public void clearDataList() {
        mRealDataList.clear();
    }

    /*
     * TitleHolder
     */
    private class ViewHolderTitle extends ResultList.ViewHolder {
        private TextView mTitle;

        public ViewHolderTitle(View itemView) {
            super(itemView);
            mTitle = (TextView) itemView;
        }

        public TextView getTitleView() {
            return mTitle;
        }
    }

    /*
     * DoubleSingleItemHolder
     */
    private class ViewHolderDoubleSingleItem extends ResultList.ViewHolder {
        private ItemDoubleSingle mItemDoubleSingle;

        public ViewHolderDoubleSingleItem(View itemView) {
            super(itemView);
            mItemDoubleSingle = (ItemDoubleSingle) itemView;
        }

        public ItemDoubleSingle getItemDoubleSingle() {
            return mItemDoubleSingle;
        }
    }
}
