package com.smartisanos.quicksearchbox.container.resultbox.resultlist;

import com.smartisanos.quicksearchbox.ibase.BasePresenter;
import com.smartisanos.quicksearchbox.ibase.BaseView;

/**
 * Created by anmingyu on 16-9-2.
 */
public interface ResultListContract {

    interface View extends BaseView<Presenter> {

    }

    interface Presenter extends BasePresenter {
        void clearDataList();
    }

}
