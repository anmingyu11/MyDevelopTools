package com.smartisanos.quicksearchbox.container.resultbox.resultlist.item.doublesingle;

/**
 * Created by anmingyu on 16-9-1.
 */
public class ItemDoublesinglePresenter {
    private ItemDoubleSingle mView;
}