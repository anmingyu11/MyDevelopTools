package com.smartisanos.quicksearchbox.container.resultbox.resultlist.item.doublesingle;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.smartisanos.quicksearchbox.ibase.BaseItemOnClikcListener;
import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.DoubleSingleItemBean;
import com.smartisanos.quicksearchbox.util.GuavaUtil;
import com.smartisanos.quicksearchbox.util.LogUtil;
import com.smartisanos.quicksearchbox.util.Util;

/**
 * Created by anmingyu on 16-9-1.
 */
public class ItemDoubleSingle extends RelativeLayout implements ItemDoubleSingleContract.View {

    private DoubleSingleItemBean mDoubleSingleItemBean;
    //views
    private ImageView mIcon;
    private TextView mText;
    //Presenter
    private ItemDoubleSingleContract.Presenter mPresenter;
    //listeners
    private BaseItemOnClikcListener mBaseItemOnClikcListener;

    public ItemDoubleSingle(Context context) {
        super(context);
    }

    public ItemDoubleSingle(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ItemDoubleSingle(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        mIcon = (ImageView) getChildAt(0);
        mText = (TextView) getChildAt(1);

    }

    @Override
    public void create(final DoubleSingleItemBean doubleSingleItemBean) {
        //text
        setText(GuavaUtil.checkNotNull(doubleSingleItemBean.getText()));
        //icon
        if (doubleSingleItemBean.getIcon() != null) {
            setIconVisible();
            setIcon(doubleSingleItemBean.getIcon());
        } else {
            setIconGone();
        }
        //setOnclickListener
        if (doubleSingleItemBean.getBaseItemOnClikcListener() != null) {
            setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    doubleSingleItemBean.getBaseItemOnClikcListener().onClick();
                }
            });
            if (isLongClickable()) {
                setOnLongClickListener(new OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        return doubleSingleItemBean.getBaseItemOnClikcListener().longClick();
                    }
                });
            }
        } else {
            LogUtil.error("this item cannot be click");
        }
    }

    @Override
    public void setLongClickable() {
        setLongClickable(true);
    }

    @Override
    public void setUnLongClickable() {
        setLongClickable(false);
    }

    @Override
    public void setText(String text) {
        mText.setText(text);
    }

    @Override
    public void setText(int stringId) {
        mText.setText(getContext().getResources().getString(stringId));
    }

    @Override
    public void setIcon(int drawable) {
        mIcon.setBackgroundResource(drawable);
    }

    @Override
    public void setIcon(Drawable drawable) {
        mIcon.setBackground(drawable);
    }

    @Override
    public void setIcon(Bitmap bitmap) {
        mIcon.setBackground(Util.bitmapToDrawable(getContext(), bitmap));
    }

    @Override
    public void setIconVisible() {
        mIcon.setVisibility(View.VISIBLE);
    }

    @Override
    public void setIconInVisible() {
        mIcon.setVisibility(View.INVISIBLE);
    }

    @Override
    public void setIconGone() {
        mIcon.setVisibility(View.GONE);
    }

    @Override
    public void setPresenter(ItemDoubleSingleContract.Presenter presenter) {
        mPresenter = presenter;
    }

}
