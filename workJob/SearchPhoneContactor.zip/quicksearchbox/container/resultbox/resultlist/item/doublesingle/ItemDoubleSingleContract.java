package com.smartisanos.quicksearchbox.container.resultbox.resultlist.item.doublesingle;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;

import com.smartisanos.quicksearchbox.ibase.BasePresenter;
import com.smartisanos.quicksearchbox.ibase.BaseView;
import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.DoubleSingleItemBean;

/**
 * Created by anmingyu on 16-9-1.
 */
public interface ItemDoubleSingleContract {

    interface View extends BaseView<Presenter> {

        //create
        void create(DoubleSingleItemBean doubleSingleItemBean);

        //text
        void setText(String text);

        void setText(int stringId);

        //icon
        void setIcon(int drawable);

        void setIcon(Drawable drawable);

        void setIcon(Bitmap bitmap);

        void setIconVisible();

        void setIconInVisible();

        void setIconGone();

        //longclick
        void setLongClickable();

        void setUnLongClickable();

    }

    interface Presenter extends BasePresenter {

        //online
        int getSearchOnLineIconDrawableId();

        String getSearchOnLineText();

        //clearRecord
        int getClearRecordIconDrawableId();

        String getClearRecordText();

        //app
        int getAppIconDrawableId();

        Drawable getAppIconDrawable();

        Bitmap getAppIconBitmap();

        String getAppName();

        //Contact
        int getContactPortraitDrawableId();

        Drawable getContactPortraitDrawable();

        Bitmap getContactPortraitBitmap();

        String getContactName();
    }
}
