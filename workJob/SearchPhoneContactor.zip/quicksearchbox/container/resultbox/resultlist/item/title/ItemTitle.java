package com.smartisanos.quicksearchbox.container.resultbox.resultlist.item.title;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * Created by anmingyu on 16-9-2.
 */
public class ItemTitle extends TextView {
    public ItemTitle(Context context) {
        super(context);
    }

    public ItemTitle(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ItemTitle(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
