package com.smartisanos.quicksearchbox.container.resultbox.resultlist;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;

/**
 * Created by anmingyu on 16-9-1.
 */
public class ResultList extends RecyclerView implements ResultListContract.View {

    public ResultList(Context context) {
        super(context);
    }

    public ResultList(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void setPresenter(ResultListContract.Presenter presenter) {

    }
}
