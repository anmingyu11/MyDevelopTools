package com.smartisanos.quicksearchbox.container.resultbox;

import android.content.Context;

import com.smartisanos.home.R;
import com.smartisanos.quicksearchbox.repository.BeanRepository;
import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.DoubleSingleItemBean;
import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.SearchOnlineBean;
import com.smartisanos.quicksearchbox.util.GuavaUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by anmingyu on 16-9-1.
 */
public class ResultBoxPresenter implements ResultBoxContract.Presenter {

    private Context mContext;
    //Repository
    private BeanRepository mBeanRepository;
    //view
    private ResultBoxContract.View mResultBoxView;

    public ResultBoxPresenter(Context context, BeanRepository beanRepository, ResultBoxContract.View resultBoxView) {
        mContext = context;
        mBeanRepository = beanRepository;
        mResultBoxView = resultBoxView;
        mResultBoxView.setPresenter(this);
    }

    @Override
    public void init() {

    }

    @Override
    public void createQwertyQueryResult(String keyWord) {
        HashMap<String, List<DoubleSingleItemBean>> dataMap = new HashMap<String, List<DoubleSingleItemBean>>();

        createSearchOnlineResult(dataMap, keyWord);
        createContactResult(false, dataMap, keyWord);
        createAppResult(false, dataMap, keyWord);
        //callResultBoxFragment refresh
        mResultBoxView.refreshResult(dataMap);
    }

    @Override
    public void createT9QueryResult(String keyWord) {
        HashMap<String, List<DoubleSingleItemBean>> dataMap = new HashMap<String, List<DoubleSingleItemBean>>();

        createSearchOnlineResult(dataMap, keyWord);
        createContactResult(true, dataMap, keyWord);
        createAppResult(true, dataMap, keyWord);
        //callResultBoxFragment refresh
        mResultBoxView.refreshResult(dataMap);
    }

    private void createSearchOnlineResult(HashMap<String, List<DoubleSingleItemBean>> dataMap, String keyWord) {
        //create SearchOnline bean
        SearchOnlineBean searchOnlineBean = mBeanRepository.createSearchOnlineBean(keyWord);
        List<DoubleSingleItemBean> searchOnlineList = new ArrayList<DoubleSingleItemBean>();
        searchOnlineList.add(searchOnlineBean);
        GuavaUtil.checkNotNull(dataMap).put(mContext.getString(R.string.resultgroup_title_more), searchOnlineList);
    }

    private void createAppResult(boolean isT9, HashMap<String, List<DoubleSingleItemBean>> dataMap, String keyWord) {
        List<DoubleSingleItemBean> appShowBeanList = mBeanRepository.createAppBeanList(isT9, keyWord);
        GuavaUtil.checkNotNull(dataMap).put(mContext.getString(R.string.resultgroup_title_app), appShowBeanList);
    }

    private void createContactResult(boolean isT9, HashMap<String, List<DoubleSingleItemBean>> dataMap, String keyWord) {
        List<DoubleSingleItemBean> contactShowBeanList = mBeanRepository.createContactBeanList(isT9, keyWord);
        GuavaUtil.checkNotNull(dataMap).put(mContext.getString(R.string.resultgroup_title_contact), contactShowBeanList);
    }

    @Override
    public void clearQueryResultShowBackground() {
        mResultBoxView.clearResult();
    }
}
