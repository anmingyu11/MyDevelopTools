package com.smartisanos.quicksearchbox.container.resultbox;

import com.smartisanos.quicksearchbox.ibase.BasePresenter;
import com.smartisanos.quicksearchbox.ibase.BaseView;
import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.DoubleSingleItemBean;

import java.util.HashMap;
import java.util.List;

/**
 * Created by anmingyu on 16-9-1.
 */
public interface ResultBoxContract {
    interface View extends BaseView<Presenter> {

        //Set visibility
        void setResultListGone();

        void setResultListVisible();

        void hideKeyBoard();

        //showresult
        void refreshResult(HashMap<String, List<DoubleSingleItemBean>> dataMap);
        //clearresult
        void clearResult();
    }

    interface Presenter extends BasePresenter {
        void createQwertyQueryResult(String keyWord);

        void createT9QueryResult(String keyWord);

        void clearQueryResultShowBackground();
    }
}
