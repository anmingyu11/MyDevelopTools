package com.smartisanos.quicksearchbox.container.resultbox;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.smartisanos.home.R;
import com.smartisanos.quicksearchbox.BaseFragment;
import com.smartisanos.quicksearchbox.SearchMainActivity;
import com.smartisanos.quicksearchbox.container.resultbox.resultlist.ResultList;
import com.smartisanos.quicksearchbox.container.resultbox.resultlist.ResultListAdapter;
import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.DoubleSingleItemBean;

import java.util.HashMap;
import java.util.List;

/**
 * Created by anmingyu on 16-8-30.
 */
public class ResultBoxFragment extends BaseFragment implements ResultBoxContract.View {

    //global
    private Context mContext;
    private SearchMainActivity mSearchMainActivity;

    private ResultList mResultList;
    private ResultListAdapter mResultListAdapter;

    //Presenter
    ResultBoxContract.Presenter mPresenter;

    public static ResultBoxFragment newInstance() {
        Bundle args = new Bundle();

        ResultBoxFragment fragment = new ResultBoxFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mContext = activity;
        mSearchMainActivity = (SearchMainActivity) mContext;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.resultbox_fragment, container, false);
        initView(root);
        return root;
    }

    @Override
    protected void initView(View root) {
        super.initView(root);
        mResultList = (ResultList) root.findViewById(R.id.resultbox_resultlist);
        mResultList.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        mResultList.setOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                if (newState != RecyclerView.SCROLL_STATE_IDLE) {
                    if (mSearchMainActivity.isT9KeyBoardShowing()) {
                        mSearchMainActivity.hideT9KeyBoard();
                    } else {
                        mSearchMainActivity.hideSoftKeyBoard();
                    }
                }
            }
        });
    }

    @Override
    public void refreshResult(HashMap<String, List<DoubleSingleItemBean>> dataMap) {
        if (mResultListAdapter == null) {
            mResultList.setAdapter(mResultListAdapter = new ResultListAdapter(getActivity(), dataMap));
        } else {
            mResultListAdapter.clearDataList();
            mResultListAdapter.init(dataMap);
        }
        mResultListAdapter.notifyDataSetChanged();
        ((SearchMainActivity) mContext).hideBackgroundHint();
        setResultListVisible();
    }

    @Override
    public void clearResult() {
        mResultListAdapter.clearDataList();
        mResultListAdapter.notifyDataSetChanged();
        ((SearchMainActivity) mContext).showBackgroundHint();
        setResultListGone();

    }

    @Override
    public void setResultListGone() {
        mResultList.setVisibility(View.GONE);
    }

    @Override
    public void setResultListVisible() {
        mResultList.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideKeyBoard() {

    }

    @Override
    public void setPresenter(ResultBoxContract.Presenter presenter) {
        mPresenter = presenter;
    }
}
