package com.smartisanos.quicksearchbox.container.editbox.enginelist;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * Created by anmingyu on 16-8-30.
 */
public class EngineList extends TextView{

    public EngineList(Context context) {
        super(context);
    }

    public EngineList(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public EngineList(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
