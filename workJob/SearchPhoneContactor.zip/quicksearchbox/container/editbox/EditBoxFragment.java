package com.smartisanos.quicksearchbox.container.editbox;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.smartisanos.home.R;
import com.smartisanos.quicksearchbox.BaseFragment;
import com.smartisanos.quicksearchbox.SearchMainActivity;
import com.smartisanos.quicksearchbox.container.editbox.clearbutton.ClearButton;
import com.smartisanos.quicksearchbox.container.editbox.enginelist.EngineList;
import com.smartisanos.quicksearchbox.container.editbox.keywordeditor.KeyWordEditor;
import com.smartisanos.quicksearchbox.util.GuavaUtil;
import com.smartisanos.quicksearchbox.util.Util;

import java.lang.reflect.Method;

/**
 * Created by anmingyu on 16-8-30.
 */
public class EditBoxFragment extends BaseFragment implements EditBoxContract.View {

    //context
    private Activity mContext;

    //view
    private KeyWordEditor mKeyWordEditor;
    public KeyWordEditor getKeyWordEditor() {
        return mKeyWordEditor;
    }
    private ClearButton mClearButton;
    private EngineList mEngineList;

    //presenter
    private EditBoxContract.Presenter mPresenter;

    /**
     * new Instance of this fragment
     *
     * @return
     */
    public static EditBoxFragment newInstance() {
        Bundle args = new Bundle();

        EditBoxFragment fragment = new EditBoxFragment();
        fragment.setArguments(args);
        return fragment;
    }

    //watcher
    //private KeyWordEditorWatcher mKeyWordEditorWatcher;

    public EditBoxFragment() {
        //mKeyWordEditorWatcher = new KeyWordEditorWatcher();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mContext = activity;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.editbox_fragment, container, false);
        initView(root);
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    //initViews
    @Override
    protected void initView(View root) {

        //KeyWordEditor
        mKeyWordEditor = (KeyWordEditor) root.findViewById(R.id.search_editbox_keywordeditor);
        mKeyWordEditor.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                query(s.toString());
            }
        });
        mKeyWordEditor.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    clearKeyWordEditor();
                    showKeyBoard(true);
                }
            }
        });
        mKeyWordEditor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showKeyBoard(false);
            }
        });
        //ClearButton
        mClearButton = (ClearButton) root.findViewById(R.id.search_editbox_clearbutton);
        mClearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearKeyWordEditor();
                setClearButtonInvisible();
                mPresenter.clearResultBoxShowBackGround();
            }
        });
        setClearButtonInvisible();

        //EngineList
        mEngineList = (EngineList) root.findViewById(R.id.search_editbox_enginelist);
        mEngineList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEngineList();
            }
        });
    }

    @Override
    public void query(String text) {
        if (TextUtils.isEmpty(text) && isClearButtonVisible()) {
            setClearButtonInvisible();
            mPresenter.clearResultBoxShowBackGround();
        } else if (!TextUtils.isEmpty(text)) {
            setClearButtonVisible();
            mPresenter.startQuery(text);
        }
    }

    @Override
    public Context getActivityContext() {
        return getActivity();
    }

    /**
     * 是否点击editbox时显示软键盘
     *
     * @param isShow
     */
    public void setShowSoftInputOnFocus(boolean isShow) {
        if (Build.VERSION.SDK_INT >= 21) {
            mKeyWordEditor.setShowSoftInputOnFocus(isShow);
            return;
        } else if (Build.VERSION.SDK_INT < 21 && Build.VERSION.SDK_INT > 14) {
            if (isShow) {
                try {
                    final Method method = EditText.class.getMethod("setShowSoftInputOnFocus", new Class[]{boolean.class});
                    method.setAccessible(true);
                    method.invoke(mKeyWordEditor, true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    final Method method = EditText.class.getMethod("setShowSoftInputOnFocus", new Class[]{boolean.class});
                    method.setAccessible(true);
                    method.invoke(mKeyWordEditor, false);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return;
        } else if (Build.VERSION.SDK_INT <= 14) {
            //3.0版本一下似乎无法设定显示软键盘
            if (isShow) {
                mKeyWordEditor.setInputType(InputType.TYPE_CLASS_TEXT);
            } else {
                mKeyWordEditor.setInputType(InputType.TYPE_NULL);
            }
            return;
        }
    }

    @Override
    public void showKeyBoard(boolean cleanEditor) {
        SearchMainActivity searchMainActivity = (SearchMainActivity) mContext;
        if (Util.isT9LastShown(searchMainActivity)) {
            searchMainActivity.showT9KeyBoard(cleanEditor);
        } else {
            searchMainActivity.showSoftKeyBoard(cleanEditor, mKeyWordEditor);
        }
    }

    @Override
    public void clearKeyWordEditor() {
        setKeyWordEditorText("");
    }

    @Override
    public String getKeyWordEditorText() {
        return mKeyWordEditor.getText().toString();
    }

    @Override
    public void setKeyWordEditorText(String text) {
        mKeyWordEditor.setText(text);
    }

    /**
     * T9keyboard input
     *
     * @param keyCode
     */
    @Override
    public void setKeyWordEditorKeyCode(int keyCode) {
        KeyEvent keyEvent = new KeyEvent(KeyEvent.ACTION_DOWN, keyCode);
        mKeyWordEditor.onKeyDown(keyCode, keyEvent);
    }

    @Override
    public boolean isClearButtonVisible() {
        if (mClearButton.getVisibility() == View.VISIBLE) {
            return true;
        }
        return false;
    }

    @Override
    public void setClearButtonVisible() {
        mClearButton.setVisibility(View.VISIBLE);
    }

    @Override
    public void setClearButtonInvisible() {
        mClearButton.setVisibility(View.INVISIBLE);
    }

    /**
     * 可以做在这里面选择搜索引擎
     */
    @Override
    public void showEngineList() {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getContext(), "搜索引擎", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void setPresenter(EditBoxContract.Presenter presenter) {
        mPresenter = GuavaUtil.checkNotNull(presenter);
    }

}
