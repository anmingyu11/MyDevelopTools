package com.smartisanos.quicksearchbox.container.editbox.keywordeditor;

import android.content.Context;
import android.util.AttributeSet;
import android.view.inputmethod.CompletionInfo;
import android.widget.EditText;

/**
 * Created by anmingyu on 16-8-30.
 */
public class KeyWordEditor extends EditText {

    public KeyWordEditor(Context context) {
        super(context);
    }

    public KeyWordEditor(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public KeyWordEditor(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public void onCommitCompletion(CompletionInfo text) {
        super.onCommitCompletion(text);
    }
}
