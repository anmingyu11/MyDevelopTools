package com.smartisanos.quicksearchbox.container.editbox.clearbutton;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * Created by anmingyu on 16-8-30.
 */
public class ClearButton extends TextView {

    public ClearButton(Context context) {
        super(context);
    }

    public ClearButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ClearButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
