package com.smartisanos.quicksearchbox.container.editbox;

import android.content.Context;
import android.view.inputmethod.InputMethodManager;

import com.smartisanos.quicksearchbox.SearchMainActivity;
import com.smartisanos.quicksearchbox.container.resultbox.ResultBoxContract;
import com.smartisanos.quicksearchbox.container.resultbox.ResultBoxPresenter;
import com.smartisanos.quicksearchbox.repository.BeanRepository;
import com.smartisanos.quicksearchbox.util.GuavaUtil;

/**
 * Created by anmingyu on 16-9-1.
 */
public class EditBoxPresenter implements EditBoxContract.Presenter {

    private Context mContext;
    private SearchMainActivity mSearchMainActivity;
    private InputMethodManager mInputMethodManager;
    private EditBoxContract.View mEditBoxView;

    private ResultBoxContract.Presenter mResultBoxPresenter;

    private BeanRepository mBeanRepository;


    public EditBoxPresenter(Context context,
                            EditBoxContract.View editBoxView,
                            ResultBoxPresenter resultBoxPresenter,
                            BeanRepository beanRepository) {
        mContext = context;
        mSearchMainActivity = (SearchMainActivity) mContext;
        mEditBoxView = GuavaUtil.checkNotNull(editBoxView);
        mResultBoxPresenter = GuavaUtil.checkNotNull(resultBoxPresenter);
        mBeanRepository = GuavaUtil.checkNotNull(beanRepository);
        mEditBoxView.setPresenter(this);
    }

    @Override
    public void init() {
    }

    @Override
    public void startQuery(String keyWord) {
        if (mContext == null) {
            mContext = mEditBoxView.getActivityContext();
        }
        if (mInputMethodManager == null) {
            mInputMethodManager = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
        }
        if (mSearchMainActivity == null) {
            mSearchMainActivity = (SearchMainActivity) mContext;
        }
        /*
        To T9 or To qwerty :that is the question.
        */
        if (mSearchMainActivity.isT9KeyBoardShowing()) {
            mResultBoxPresenter.createT9QueryResult(keyWord);
        } else {
            mResultBoxPresenter.createQwertyQueryResult(keyWord);
        }
    }

    @Override
    public void clearResultBoxShowBackGround() {
        mResultBoxPresenter.clearQueryResultShowBackground();
    }

}
