package com.smartisanos.quicksearchbox.container.editbox;

import android.content.Context;

import com.smartisanos.quicksearchbox.ibase.BasePresenter;
import com.smartisanos.quicksearchbox.ibase.BaseView;

/**
 * Created by anmingyu on 16-8-31.
 */
public interface EditBoxContract {

    interface View extends BaseView<Presenter> {

        //getMainActivityContext
        Context getActivityContext();
        //keyBoard
        void showKeyBoard(boolean cleanEditor);

        //keyWordEditor
        void clearKeyWordEditor();

        String getKeyWordEditorText();

        void setKeyWordEditorText(String text);

        void setKeyWordEditorKeyCode(int keyCode);
        //clearTextButton
        boolean isClearButtonVisible();

        void setClearButtonVisible();

        void setClearButtonInvisible();

        //query
        void query(String s);
        //engineList
        void showEngineList();
    }

    interface Presenter extends BasePresenter {
        //分发搜索
        void startQuery(String keyWord);

        //清除结果
        void clearResultBoxShowBackGround();

    }
}
