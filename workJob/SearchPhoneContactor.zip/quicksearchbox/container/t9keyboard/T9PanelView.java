package com.smartisanos.quicksearchbox.container.t9keyboard;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.smartisanos.home.R;
import com.smartisanos.quicksearchbox.util.LogUtil;

/**
 * Created by anmingyu on 16-9-28.
 */

public class T9PanelView extends RelativeLayout {

    private LinearLayout mT9KeyBoard;
    private ObjectAnimator mShowT9Animator;
    private ObjectAnimator mHideT9Animator;
    private int keyBoardAnimDuration = 300;

    public T9PanelView(Context context) {
        super(context);
        init();
    }

    public T9PanelView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public T9PanelView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        LayoutInflater.from(getContext()).inflate(R.layout.search_t9, this, true);
        mT9KeyBoard = (LinearLayout) getChildAt(0);
    }

    public boolean onBackPressed() {
        if (mT9KeyBoard.getVisibility() == View.GONE) {
            return true;
        } else {
            hideT9Panel(true);
            return false;
        }
    }

    public void showT9Panel(boolean withAnim) {
        if (mT9KeyBoard.getVisibility() == View.VISIBLE) {
            if (mT9KeyBoard.getTranslationY() != 0) {
                mT9KeyBoard.setTranslationY(0);
            }
            LogUtil.debug("is visible");
            return;
        }
        if (mHideT9Animator != null) {
            mHideT9Animator.cancel();
        }
        if (!withAnim) {
            mT9KeyBoard.setVisibility(View.VISIBLE);
            return;
        }

        if (mShowT9Animator == null) {
            mShowT9Animator = ObjectAnimator.ofFloat(mT9KeyBoard, View.TRANSLATION_Y,
                    getContext().getResources().getDimension(R.dimen.t9_keyboard_height), 0);
            mShowT9Animator.setDuration(keyBoardAnimDuration);
            mShowT9Animator.setInterpolator(new DecelerateInterpolator());
            mShowT9Animator.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationStart(Animator animation) {
                    super.onAnimationStart(animation);
                    mT9KeyBoard.setVisibility(View.VISIBLE);
                }
            });
        }
        if (!mShowT9Animator.isRunning()) {
            mT9KeyBoard.setTranslationY(mT9KeyBoard.getHeight());
            mShowT9Animator.start();
        }
    }

    public boolean hideT9Panel(boolean withAnim) {
        if (mT9KeyBoard.getVisibility() == View.GONE) {
            return false;
        }
        if (mShowT9Animator != null) {
            mShowT9Animator.cancel();
        }
        if (!withAnim) {
            mT9KeyBoard.setVisibility(View.GONE);
            return true;
        }

        if (mHideT9Animator == null) {
            mHideT9Animator = ObjectAnimator.ofFloat(mT9KeyBoard, View.TRANSLATION_Y,
                    0, getContext().getResources().getDimension(R.dimen.t9_keyboard_height));
            mHideT9Animator.setDuration(keyBoardAnimDuration);
            mHideT9Animator.setInterpolator(new DecelerateInterpolator());
            mHideT9Animator.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    mT9KeyBoard.setVisibility(View.GONE);
                }
            });
        }
        if (!mHideT9Animator.isRunning()) {
            mHideT9Animator.start();
        }
        return true;
    }
}
