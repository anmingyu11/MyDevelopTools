package com.smartisanos.quicksearchbox.container.t9keyboard;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.NinePatch;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.TextView;

import com.smartisanos.home.R;

/**
 * Created by anmingyu on 16-9-28.
 */

public class DialButtonView extends TextView {

    private boolean mIsActionDown = false;
    private NinePatch mNinePatch;
    private Rect mRect = new Rect();

    public DialButtonView(Context context) {
        super(context);
    }

    public DialButtonView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public DialButtonView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mIsActionDown = true;
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                mIsActionDown = false;
                invalidate();
                break;
            case MotionEvent.ACTION_CANCEL:
                mIsActionDown = false;
                invalidate();
                break;
        }
        return super.onTouchEvent(event);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mIsActionDown && isEnabled()) {
            mRect.right = getWidth();
            mRect.bottom = getHeight();
            if (mNinePatch == null) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.btn_pressed);
                mNinePatch = new NinePatch(bitmap, bitmap.getNinePatchChunk(), null);
            }
            mNinePatch.draw(canvas, mRect);
        }
    }
}