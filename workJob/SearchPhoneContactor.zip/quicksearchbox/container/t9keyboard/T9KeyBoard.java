package com.smartisanos.quicksearchbox.container.t9keyboard;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import com.smartisanos.home.R;
import com.smartisanos.quicksearchbox.SearchMainActivity;

/**
 * Created by anmingyu on 16-9-28.
 */

public class T9KeyBoard extends LinearLayout implements View.OnClickListener {
    private SearchMainActivity mSearchMainActivity;
    public static final int CLOSE_PANEL_CODE = -1;

    public T9KeyBoard(Context context) {
        super(context);
        mSearchMainActivity = (SearchMainActivity) context;
        init();
    }

    public T9KeyBoard(Context context, AttributeSet attrs) {
        super(context, attrs);
        mSearchMainActivity = (SearchMainActivity) context;
        init();
    }

    public T9KeyBoard(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mSearchMainActivity = (SearchMainActivity) context;
        init();
    }

    private void init() {
        setOrientation(LinearLayout.VERTICAL);
        LayoutInflater.from(getContext()).inflate(R.layout.search_t9keyboard, this, true);
        initDialButton();
    }

    private void initDialButton() {
        DialButtonView dialButtonView;
        /*********************** Left row *********************************************/
        dialButtonView = (DialButtonView) findViewById(R.id.one);
        dialButtonView.setBackgroundResource(R.drawable.btn_1_classic_normal);
        dialButtonView.setOnClickListener(this);

        dialButtonView = (DialButtonView) findViewById(R.id.four);
        dialButtonView.setBackgroundResource(R.drawable.btn_4_classic_normal);
        dialButtonView.setOnClickListener(this);

        dialButtonView = (DialButtonView) findViewById(R.id.seven);
        dialButtonView.setBackgroundResource(R.drawable.btn_7_classic_normal);
        dialButtonView.setOnClickListener(this);

        dialButtonView = (DialButtonView) findViewById(R.id.down);
        dialButtonView.setBackgroundResource(R.drawable.btn_down_classic_normal);
        dialButtonView.setOnClickListener(this);

        /*********************** Middle row *********************************************/
        dialButtonView = (DialButtonView) findViewById(R.id.two);
        dialButtonView.setBackgroundResource(R.drawable.btn_2_classic_normal);
        dialButtonView.setOnClickListener(this);

        dialButtonView = (DialButtonView) findViewById(R.id.five);
        dialButtonView.setBackgroundResource(R.drawable.btn_5_classic_normal);
        dialButtonView.setOnClickListener(this);

        dialButtonView = (DialButtonView) findViewById(R.id.eight);
        dialButtonView.setBackgroundResource(R.drawable.btn_8_classic_normal);
        dialButtonView.setOnClickListener(this);

        dialButtonView = (DialButtonView) findViewById(R.id.zero);
        dialButtonView.setBackgroundResource(R.drawable.btn_0_classic_normal);
        dialButtonView.setOnClickListener(this);

        /*********************** Right row *********************************************/
        dialButtonView = (DialButtonView) findViewById(R.id.three);
        dialButtonView.setBackgroundResource(R.drawable.btn_3_classic_normal);
        dialButtonView.setOnClickListener(this);

        dialButtonView = (DialButtonView) findViewById(R.id.six);
        dialButtonView.setBackgroundResource(R.drawable.btn_6_classic_normal);
        dialButtonView.setOnClickListener(this);

        dialButtonView = (DialButtonView) findViewById(R.id.nine);
        dialButtonView.setBackgroundResource(R.drawable.btn_9_classic_normal);
        dialButtonView.setOnClickListener(this);

        dialButtonView = (DialButtonView) findViewById(R.id.delete);
        dialButtonView.setBackgroundResource(R.drawable.btn_delete_classic_normal);
        dialButtonView.setOnClickListener(this);
        dialButtonView.setHapticFeedbackEnabled(false);
        dialButtonView.setOnLongClickListener(new OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                mSearchMainActivity.clearResultFromT9KeyBoard();
                return true;
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.one:
                keyPressed(KeyEvent.KEYCODE_1);
                break;
            case R.id.two:
                keyPressed(KeyEvent.KEYCODE_2);
                break;
            case R.id.three:
                keyPressed(KeyEvent.KEYCODE_3);
                break;
            case R.id.four:
                keyPressed(KeyEvent.KEYCODE_4);
                break;
            case R.id.five:
                keyPressed(KeyEvent.KEYCODE_5);
                break;
            case R.id.six:
                keyPressed(KeyEvent.KEYCODE_6);
                break;
            case R.id.seven:
                keyPressed(KeyEvent.KEYCODE_7);
                break;
            case R.id.eight:
                keyPressed(KeyEvent.KEYCODE_8);
                break;
            case R.id.nine:
                keyPressed(KeyEvent.KEYCODE_9);
                break;
            case R.id.zero:
                keyPressed(KeyEvent.KEYCODE_0);
                break;
            case R.id.delete:
                keyPressed(KeyEvent.KEYCODE_DEL);
                break;
            case R.id.down:
                keyPressed(CLOSE_PANEL_CODE);
                break;
        }
    }

    public void keyPressed(int keyCode) {
        if (keyCode == CLOSE_PANEL_CODE) {
            mSearchMainActivity.hideT9KeyBoard();
        } else {
            mSearchMainActivity.inputFromT9KeyBoard(keyCode);
        }
    }
}