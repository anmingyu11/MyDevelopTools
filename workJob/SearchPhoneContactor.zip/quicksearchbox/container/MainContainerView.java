package com.smartisanos.quicksearchbox.container;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

/**
 * Created by anmingyu on 16-8-30.
 */
public class MainContainerView extends RelativeLayout{

    public MainContainerView(Context context) {
        super(context);
    }

    public MainContainerView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public MainContainerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
