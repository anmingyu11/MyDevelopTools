package com.smartisanos.quicksearchbox.ibase;

/**
 * Created by anmingyu on 16-9-2.
 */
public interface BaseItemOnClikcListener {
    boolean longClick();

    void onClick();
}
