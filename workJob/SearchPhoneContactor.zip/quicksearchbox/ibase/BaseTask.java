package com.smartisanos.quicksearchbox.ibase;

/**
 * Created by anmingyu on 16-9-1.
 */
public interface BaseTask {
}
