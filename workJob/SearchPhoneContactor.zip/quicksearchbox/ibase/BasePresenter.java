package com.smartisanos.quicksearchbox.ibase;

/**
 * Created by anmingyu on 16-8-30.
 */
public interface BasePresenter {
    /**
     * 初始化业务
     */
    void init();
}
