package com.smartisanos.quicksearchbox.ibase;

/**
 * Created by anmingyu on 16-8-30.
 */
public interface BaseView<T> {
    /**
     * 上帝接口,给view层加业务逻辑接口presenter
     * @param presenter
     */
    void setPresenter(T presenter);
}
