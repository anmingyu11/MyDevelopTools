package com.smartisanos.quicksearchbox;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;

import com.smartisanos.home.R;
import com.smartisanos.launcher.data.Utils;
import com.smartisanos.quicksearchbox.container.MainContainerView;
import com.smartisanos.quicksearchbox.container.editbox.EditBoxFragment;
import com.smartisanos.quicksearchbox.container.editbox.EditBoxPresenter;
import com.smartisanos.quicksearchbox.container.resultbox.ResultBoxFragment;
import com.smartisanos.quicksearchbox.container.resultbox.ResultBoxPresenter;
import com.smartisanos.quicksearchbox.container.t9keyboard.T9PanelView;
import com.smartisanos.quicksearchbox.repository.BeanRepository;
import com.smartisanos.quicksearchbox.repository.app.db.helper.AppSearchIndexHelper;
import com.smartisanos.quicksearchbox.repository.contact.db.ContactChangeMonitor;
import com.smartisanos.quicksearchbox.repository.contact.db.helper.ContactSearchIndexHelper;
import com.smartisanos.quicksearchbox.util.ActivityUtil;
import com.smartisanos.quicksearchbox.util.EngineUtil;
import com.smartisanos.quicksearchbox.util.LogUtil;
import com.smartisanos.quicksearchbox.util.Util;


/**
 * Created by anmingyu on 16-8-29.
 */
public class SearchMainActivity extends BaseActivity {
    static {
        LogUtil.disableLog();
    }

    //views
    private MainContainerView mMainContainer;
    private ViewGroup mEditBoxContainer;
    private ViewGroup mResultContainer;
    private ViewGroup mBackgroundHintContainer;
    private Boolean isT9KeyBoardShowing = false;
    //Repository
    private BeanRepository mBeanRepository;

    //EditBox
    private EditBoxFragment mEditBoxFragment;
    private EditBoxPresenter mEditBoxPresenter;

    //ResultBox
    private ResultBoxFragment mResultBoxFragment;
    private ResultBoxPresenter mResultBoxPresenter;

    //manager
    private FragmentManager mFragmentManager;

    //t9 panel
    private T9PanelView mT9PanelView;
    //global
    public static final int MSG_REFRESHRESULT = 0;
    private Handler mainHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case MSG_REFRESHRESULT: {
                    refreshResultBox();
                    break;
                }
            }
        }
    };

    private Context mContext;

    public Handler getMainHandler() {
        return mainHandler;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) throws RuntimeException {
        super.onCreate(savedInstanceState);
        Utils.applyTransparentStatusBar(this, getWindow());
        Utils.setMiuiStatusBarDarkMode(this, true);
        setContentView(R.layout.activity_search_main);
        init();
        ContactChangeMonitor.getInstance(this).registMonitor();
    }

    @Override
    protected void onPause() {
        super.onPause();
        hideSoftKeyBoard();
    }

    @Override
    public void onBackPressed() {
        if (mT9PanelView.onBackPressed()) {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ContactChangeMonitor.getInstance(this).unRegistMonitor();
        mContext = null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        ContactSearchIndexHelper contactSearchIndexHelper = ContactSearchIndexHelper.getInstance(this);
        AppSearchIndexHelper appSearchIndexHelper = AppSearchIndexHelper.getInstance(this);
        //第一次初始化
        if (!Util.isIndexDataInit(this)) {
            if (!contactSearchIndexHelper.initLocalContactIndexFirst()) {
                throw new RuntimeException("不能初始化联系人数据");
            } else {
                LogUtil.debug("联系人数据初始化成功");
                Util.indexDataInited(this);
            }
        } else {
            //需要判断联系人数据库是否有更改
            contactSearchIndexHelper.syncContactAccurate();
            //重新同步应用数据
            appSearchIndexHelper.loadAppSearchBeans();
            //重新刷新结果列表
            refreshResultBox();
        }
    }

    /**
     * 刷新结果列表
     */
    public void refreshResultBox(){
        mEditBoxFragment.query(mEditBoxFragment.getKeyWordEditorText());
    }

    private void init() {
        mContext = this;
        initQuickSearchBoxSetting();
        initManager();
        initBeanRepository();
        initMainContainer();
    }

    private void initManager() {
        mFragmentManager = getSupportFragmentManager();
    }

    //@AfterView
    private void initMainContainer() {
        mMainContainer = (MainContainerView) findViewById(R.id.main_container);
        mEditBoxContainer = (ViewGroup) findViewById(R.id.search_editbox_container);
        mResultContainer = (ViewGroup) findViewById(R.id.search_resultbox_container);
        mBackgroundHintContainer = (ViewGroup) findViewById(R.id.background_hint_container);
        initResultBoxFragment();
        initEditBoxFragment();
        initPreseters();
        initBottomPannel();
        initT9Pannel();
    }

    private void initBottomPannel() {
        ImageView tabInputSoft = (ImageView) findViewById(R.id.tab_input_soft);
        ImageView tabInputT9 = (ImageView) findViewById(R.id.tab_input_t9);
        //显示输入法框架
        tabInputSoft.setClickable(true);
        tabInputSoft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Util.isT9Shown()) {
                    showSoftKeyBoard(true, findViewById(R.id.search_editbox_keywordeditor));
                } else {
                    showSoftKeyBoard(false, findViewById(R.id.search_editbox_keywordeditor));
                }
            }
        });
        //显示t9键盘
        tabInputT9.setClickable(true);
        tabInputT9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Util.isT9Shown()) {
                    showT9KeyBoard(true);
                } else {
                    showT9KeyBoard(false);
                }
            }
        });
    }

    private void initT9Pannel() {
        mT9PanelView = (T9PanelView) findViewById(R.id.search_t9_panel);
    }

    private void initBeanRepository() {
        mBeanRepository = BeanRepository.getInstance(mContext);
    }

    /**
     * init SettingPreference
     * the pref name is "QuickSearchBoxSetting.xml"
     */
    private void initQuickSearchBoxSetting() {
        try {
            //EngineInit
            if (EngineUtil.getCurrentEngine(mContext) == EngineUtil.ENGINE_ERROR)
                EngineUtil.setSearchEngineToDefault(mContext);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initEditBoxFragment() {

        mEditBoxFragment = (EditBoxFragment) mFragmentManager.findFragmentById(R.id
                .search_editbox_container);
        //CreateEditBoxFragment
        if (mEditBoxFragment == null) {
            mEditBoxFragment = EditBoxFragment.newInstance();
        }
        ActivityUtil.addFragmentToActivity(mFragmentManager, mEditBoxFragment, R.id.search_editbox_container);
    }

    private void initResultBoxFragment() {
        mResultBoxFragment = (ResultBoxFragment) mFragmentManager.findFragmentById(R.id.search_resultbox_container);
        //CreateResultBoxFragment
        if (mResultBoxFragment == null) {
            mResultBoxFragment = ResultBoxFragment.newInstance();
        }
        ActivityUtil.addFragmentToActivity(mFragmentManager, mResultBoxFragment, R.id.search_resultbox_container);

    }

    private void initPreseters() {
        mResultBoxPresenter = new ResultBoxPresenter(mContext, mBeanRepository, mResultBoxFragment);
        mEditBoxPresenter = new EditBoxPresenter(this, mEditBoxFragment, mResultBoxPresenter, mBeanRepository);
    }

    public void inputFromT9KeyBoard(int keyCode) {
        mEditBoxFragment.setKeyWordEditorKeyCode(keyCode);
    }

    public void clearResultFromT9KeyBoard() {
        mEditBoxFragment.clearKeyWordEditor();
        showBackgroundHint();
    }

    public void hideT9KeyBoard() {
        mT9PanelView.hideT9Panel(true);
        isT9KeyBoardShowing = false;
    }

    public void showT9KeyBoard(boolean clearEditor) {
        if (clearEditor) {
            mEditBoxFragment.clearKeyWordEditor();
        }
        mEditBoxFragment.setShowSoftInputOnFocus(false);
        mT9PanelView.showT9Panel(true);
        isT9KeyBoardShowing = true;
        Util.setLastShownKeyBoard(this, true);
    }

    public boolean isT9KeyBoardShowing() {
        return isT9KeyBoardShowing;
    }

    /**
     * showSoftKeyboard
     */
    public void showSoftKeyBoard(boolean clearEditor) {
        showSoftKeyBoard(clearEditor, mEditBoxFragment.getKeyWordEditor());
    }

    /**
     * showSoftKeyboard
     */
    public void showSoftKeyBoard(boolean clearEditor, final View view) {
        if (clearEditor) {
            mEditBoxFragment.clearKeyWordEditor();
        }
        mEditBoxFragment.setShowSoftInputOnFocus(true);
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    view.requestFocus();
                    imm.showSoftInput(view, 0);
                }
            }
        }, 100);
        Util.setLastShownKeyBoard(this, false);
    }

    /**
     * hideSoftKeyBoard
     */
    public void hideSoftKeyBoard() {
        hideSoftKeyBoard(mEditBoxFragment.getKeyWordEditor());
    }

    /**
     * hideSoftKeyBoard
     */
    public void hideSoftKeyBoard(final View view) {
        mainHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }
            }
        }, 100);
    }

    public void clearResultShowBackGround() {
        mResultBoxFragment.clearResult();
        mResultContainer.setVisibility(View.GONE);
        mBackgroundHintContainer.setVisibility(View.VISIBLE);
    }

    public void hideBackgroundHint() {
        mBackgroundHintContainer.setVisibility(View.GONE);
    }

    public void showBackgroundHint() {
        mBackgroundHintContainer.setVisibility(View.VISIBLE);
    }

    public void changeBackgroundHint() {
        //TODO:修改hint文字
    }
}
