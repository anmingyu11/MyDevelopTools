package com.smartisanos.quicksearchbox.repository.app.db.helper;

import android.content.Context;

import com.smartisanos.launcher.LauncherModel;
import com.smartisanos.launcher.data.ItemInfo;
import com.smartisanos.quicksearchbox.pinyinsearch.util.QwertyUtil;
import com.smartisanos.quicksearchbox.pinyinsearch.util.T9Util;
import com.smartisanos.quicksearchbox.repository.app.bean.AppSearchBean;
import com.smartisanos.quicksearchbox.util.IndexUtil;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

/**
 * Created by anmingyu on 16-9-23.
 */

public class AppSearchIndexHelper {
    //global
    private static AppSearchIndexHelper sAppSearchIndexHelper;
    private Context mContext;
    private AppSearchBean[] mAppSearchBeen;

    private AppSearchIndexHelper(Context context) {
        mContext = context;
    }

    public static AppSearchIndexHelper getInstance(Context context) {
        if (sAppSearchIndexHelper == null) {
            return sAppSearchIndexHelper = new AppSearchIndexHelper(context);
        }
        return sAppSearchIndexHelper;
    }

    public void loadAppInfos() {
        if (mAppSearchBeen == null) {
            loadAppSearchBeans();
        }
    }

    public AppSearchBean[] loadAppSearchBeans() {
        HashMap<Long, ItemInfo> mAppMap = LauncherModel.getItemMap();
        Collection<ItemInfo> itemInfos = mAppMap.values();
        //List<ItemInfo> itemInfoList = ItemDB.listItem(false);
        //ItemInfoToArray
        ItemInfo[] itemInfoOriginArray = new ItemInfo[1];
        itemInfoOriginArray = itemInfos.toArray(itemInfoOriginArray);
        mAppSearchBeen = new AppSearchBean[itemInfoOriginArray.length];
        for (int i = 0; i < itemInfoOriginArray.length; i++) {
            ItemInfo itemInfo = itemInfoOriginArray[i];
            String searchIndex[] = new String[3];
            searchIndex[0] = itemInfo.originIndex;
            searchIndex[1] = itemInfo.qwertyIndex;
            searchIndex[2] = itemInfo.t9Index;
            mAppSearchBeen[i] = new AppSearchBean(
                    itemInfo.title,
                    itemInfo.packageName,
                    itemInfo.componentName,
                    IndexUtil.unParsePinyinUnit(itemInfo.title, searchIndex));
            mAppSearchBeen[i].iconInit(itemInfo.iconData);
        }
        //loadItemInfos();
        //loadIcons();
        //loadRedirectIcons();
        return mAppSearchBeen;
    }

    public List<AppSearchBean> qwertySearch(String keyWord) {
        List<AppSearchBean> resultList;
        if (keyWord == null) {
            throw new NullPointerException("keyWord is null");
        }
        loadAppInfos();
        /**
         * search process:
         * 1:Search by phone number
         * 2:Search by name
         * (1)Search by original name
         * (2)Search* by name pinyin characters(original name->name pinyin characters)
         */
        int mAppSearchBeeanLength = mAppSearchBeen.length;
        if (mAppSearchBeeanLength <= 0) {
            return null;
        } else {
            resultList = new ArrayList<AppSearchBean>();
        }
        for (int i = 0; i < mAppSearchBeeanLength; i++) {
            AppSearchBean appSearchBean = mAppSearchBeen[i];
            if (appSearchBean == null) {
                continue;
            }
            //app名字搜索
            if (QwertyUtil.match(appSearchBean.getPinyinSearchUnit(), keyWord)) {
                resultList.add(appSearchBean);
                continue;
            }
        }
        return resultList;
    }

    public List<AppSearchBean> t9Search(String keyWord) {
        List<AppSearchBean> resultList;
        if (keyWord == null) {
            throw new NullPointerException("keyWord is null");
        }
        loadAppInfos();
        /**
         * search process:
         * 1:Search by name
         * (1)Search by name pinyin characters(org name->name pinyin characters) ('0'~'9','*','#')
         * (2)Search by org name ('0'~'9','*','#')
         */
        int mAppSearchBeeanLength = mAppSearchBeen.length;
        if (mAppSearchBeeanLength <= 0) {
            return null;
        } else {
            resultList = new ArrayList<AppSearchBean>();
        }
        for (int i = 0; i < mAppSearchBeeanLength; i++) {
            AppSearchBean appSearchBean = mAppSearchBeen[i];
            if (appSearchBean == null) {
                continue;
            }
            //app名字搜索
            if (T9Util.match(appSearchBean.getPinyinSearchUnit(), keyWord)) {
                resultList.add(appSearchBean);
                continue;
            }
        }
        return resultList;
    }
}
