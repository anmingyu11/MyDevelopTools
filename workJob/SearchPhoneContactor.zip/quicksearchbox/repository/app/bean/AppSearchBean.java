package com.smartisanos.quicksearchbox.repository.app.bean;

import com.smartisanos.quicksearchbox.pinyinsearch.model.PinyinSearchUnit;

/**
 * Created by anmingyu on 16-9-21.
 */
public class AppSearchBean {
    private String title;
    private String packageName;
    private String componentName;
    private PinyinSearchUnit mPinyinSearchUnit;
    private byte[] iconData;
    private boolean isInstalled = true;

    public AppSearchBean(String title, String packageName, String componentName, PinyinSearchUnit pinyinSearchUnit) {
        this.title = title;
        this.packageName = packageName;
        this.componentName = componentName;
        mPinyinSearchUnit = pinyinSearchUnit;
    }

    public void setInstalled(boolean installed) {
        isInstalled = installed;
    }

    public boolean isInstalled() {
        return isInstalled;
    }

    public void iconInit(byte[] iconData) {
        this.iconData = iconData;
    }

    public String getTitle() {
        return title;
    }

    public String getPackageName() {
        return packageName;
    }

    public String getComponentName() {
        return componentName;
    }

    public PinyinSearchUnit getPinyinSearchUnit() {
        return mPinyinSearchUnit;
    }

    public byte[] getIconData() {
        return iconData;
    }

    @Override
    public String toString() {
        return "AppSearchBean{" +
                "title='" + title + '\'' +
                ", packageName='" + packageName + '\'' +
                ", componentName='" + componentName + '\'' +
                ", mPinyinSearchUnit is null= " + (mPinyinSearchUnit == null) +
                ", iconData is null= " + (iconData == null) +
                '}';
    }
}
