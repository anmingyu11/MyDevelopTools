package com.smartisanos.quicksearchbox.repository;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Message;
import android.widget.Toast;

import com.smartisanos.home.Launcher;
import com.smartisanos.home.R;
import com.smartisanos.home.apps.LauncherSettings;
import com.smartisanos.home.apps.Search;
import com.smartisanos.home.apps.Weather;
import com.smartisanos.home.settings.view.SettingMainActivity;
import com.smartisanos.launcher.LauncherModel;
import com.smartisanos.launcher.data.ItemInfo;
import com.smartisanos.launcher.data.SystemPreInstallApps;
import com.smartisanos.launcher.data.Utils;
import com.smartisanos.quicksearchbox.SearchMainActivity;
import com.smartisanos.quicksearchbox.container.resultbox.ResultBoxFragment;
import com.smartisanos.quicksearchbox.ibase.BaseItemOnClikcListener;
import com.smartisanos.quicksearchbox.repository.app.bean.AppSearchBean;
import com.smartisanos.quicksearchbox.repository.app.db.helper.AppSearchIndexHelper;
import com.smartisanos.quicksearchbox.repository.contact.bean.ContactBean;
import com.smartisanos.quicksearchbox.repository.contact.db.helper.ContactSearchIndexHelper;
import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.AppBean;
import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.ContactShowBean;
import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.DoubleSingleItemBean;
import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.SearchOnlineBean;
import com.smartisanos.quicksearchbox.util.GuavaUtil;
import com.smartisanos.quicksearchbox.util.Util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by anmingyu on 16-9-5.
 */
public class BeanRepository implements BeanSource {
    //global
    private static BeanRepository INSTANCE = null;
    private Context mContext;
    private Context mRemoteContext;
    private ContactSearchIndexHelper mContactSearchIndexHelper;
    private AppSearchIndexHelper mAppSearchIndexHelper;
    private ResultBoxFragment mResultBoxFragment;

    private BeanRepository(Context context) {
        mContext = GuavaUtil.checkNotNull(context);
        mContactSearchIndexHelper = ContactSearchIndexHelper.getInstance(mContext);
        mAppSearchIndexHelper = AppSearchIndexHelper.getInstance(mContext);
    }

    /**
     * Returns the single instance of this class, creating it if necessary.
     *
     * @return
     */
    public static BeanRepository getInstance(Context context) {
        if (INSTANCE == null) {
            return new BeanRepository(context);
        }
        return INSTANCE;
    }

    public void init3DEngineAndAnimation(Context context) {
        mRemoteContext = context;
    }

    @Override
    public SearchOnlineBean createSearchOnlineBean(String keyWord) {
        return new SearchOnlineBean(mContext, keyWord);
    }

    /**
     * 获得没安装的App
     */
    private ItemInfo getUninstalledApp(List<ItemInfo> unInstalledApps, String packageName) {
        for (ItemInfo itemInfo : unInstalledApps) {
            if (itemInfo.packageName.equals(packageName)) {
                return itemInfo;
            }
        }
        return null;
    }

    @Override
    public List<DoubleSingleItemBean> createContactBeanList(boolean isT9, String keyWord) {
        List<DoubleSingleItemBean> showBeanList;
        List<ContactBean> resultlist;
        //t9 or qwetry
        if (isT9) {
            resultlist = mContactSearchIndexHelper.t9Search(keyWord);
        } else {
            resultlist = mContactSearchIndexHelper.qwertySearch(keyWord);
        }
        if (resultlist != null) {
            showBeanList = new ArrayList<DoubleSingleItemBean>(resultlist.size());
        } else {
            return null;
        }
        for (ContactBean contactBean : resultlist) {
            showBeanList.add(new ContactShowBean(mContext, contactBean));
        }
        return showBeanList;
    }

    @Override
    public List<DoubleSingleItemBean> createAppBeanList(boolean isT9, String keyWord) {
        List<DoubleSingleItemBean> showAppResultBeanList;
        List<AppSearchBean> resultList;
        //t9 or qwetry
        if (isT9) {
            resultList = mAppSearchIndexHelper.t9Search(keyWord);
        } else {
            resultList = mAppSearchIndexHelper.qwertySearch(keyWord);
        }

        if (resultList != null) {
            showAppResultBeanList = new ArrayList<DoubleSingleItemBean>(resultList.size());
        } else {
            return null;
        }
        HashMap<Long, ItemInfo> itemInfoHashMap = LauncherModel.getItemMap();
        ItemInfo[] itemInfoArray = new ItemInfo[1];
        itemInfoArray = itemInfoHashMap.values().toArray(itemInfoArray);
        List<ItemInfo> unInstalledApps = new ArrayList<ItemInfo>();
        for (int i = 0; i < itemInfoArray.length; i++) {
            if (!itemInfoArray[i].installed) {
                unInstalledApps.add(itemInfoArray[i]);
            }
        }
        for (final AppSearchBean appSearchBean : resultList) {
            final List<ItemInfo> finalUnInstalledApps = unInstalledApps;
            Drawable drawable = Util.byteToDrawable(mContext, appSearchBean.getIconData());
            if (appSearchBean.getPackageName().equals(SystemPreInstallApps.CALENDAR.pkg)) {
                PackageManager pm = mContext.getPackageManager();
                List<ResolveInfo> resolveInfos = LauncherModel.findActivitiesForPackage(mContext, appSearchBean.getPackageName());
                Drawable[] drawables = Utils.generateShadowIconsDrawablesfromResolveInfo(mContext, pm, resolveInfos);
                //use light icon
                drawable = drawables[1];
            } else if (appSearchBean.getPackageName().equals(Weather.pkg)) {
                Drawable[] drawables = Utils.generateShadowIconDrawables(mContext, mContext.getResources().getDrawable(R.drawable.app_icon_weather));
                drawable = drawables[1];
            }
            showAppResultBeanList.add(new AppBean(
                    drawable,
                    appSearchBean.getTitle(),
                    new BaseItemOnClikcListener() {
                        @Override
                        public boolean longClick() {
                            return false;
                        }

                        @Override
                        public void onClick() {
                            Intent intent = new Intent();
                            ItemInfo itemInfo = getUninstalledApp(finalUnInstalledApps, appSearchBean.getPackageName());
                            if (itemInfo != null) {
                                //下载
                                if (Launcher.getInstance() != null) {
                                    Message msg = Launcher.getInstance().getMyHandler().obtainMessage();
                                    msg.what = Launcher.MESSAGE_REQUEST_DOWNLOAD_EMBEDDED_APP;
                                    Object[] objects = new Object[2];
                                    objects[0] = itemInfo;
                                    objects[1] = mContext;
                                    msg.obj = objects;
                                    Launcher.getInstance().getMyHandler().sendMessage(msg);
                                }
                            } else {
                                //桌面设置
                                if (appSearchBean.getPackageName().equals(LauncherSettings.pkg)) {
                                    intent.setClass(mContext, SettingMainActivity.class);
                                    mContext.startActivity(intent);
                                    ((SearchMainActivity) mContext).overridePendingTransition(R.anim.wallpaper_close_enter, R.anim
                                            .wallpaper_close_exit);
                                    return;
                                }
                                //搜索
                                if (appSearchBean.getPackageName().equals(Search.pkg)) {
                                    Toast.makeText(mContext, mContext.getText(R.string.search_searchapp_toast), Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                //天气
                                if (appSearchBean.getPackageName().equals(Weather.pkg)) {
                                    Utils.showWeatherInfoToast();
                                    return;
                                }
                                //启动
                                intent.setComponent(new ComponentName(appSearchBean.getPackageName(), appSearchBean.getComponentName()));
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
                                intent.setAction(Intent.ACTION_MAIN);
                                intent.addCategory(Intent.CATEGORY_LAUNCHER);
                                mContext.startActivity(intent);
                            }
                        }
                    }
            ));
        }
        return showAppResultBeanList;
    }

}
