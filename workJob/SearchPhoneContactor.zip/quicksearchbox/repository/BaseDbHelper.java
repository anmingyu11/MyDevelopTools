package com.smartisanos.quicksearchbox.repository;

import android.content.ContentValues;

/**
 * Created by anmingyu on 16-9-13.
 */
public interface BaseDbHelper {
    long insertSingle(ContentValues contentValues);

    long[] insertBulk(ContentValues[] contentValuesArray);

    int updateSingle(ContentValues contentValues, String whereClause, String[] whereArgs);

    int[] updateBulk(ContentValues[] contentValues, String whereClause, String[][] whereArgs);

    int deleteSingle(String whereClause, String[] whereArgs);

    int[] deleteBulk(String whereClause, String[][] whereArgs);

}
