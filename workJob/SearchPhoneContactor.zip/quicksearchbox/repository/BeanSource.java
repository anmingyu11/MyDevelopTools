package com.smartisanos.quicksearchbox.repository;

import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.DoubleSingleItemBean;
import com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle.SearchOnlineBean;

import java.util.List;

/**
 * Created by anmingyu on 16-9-5.
 */
public interface BeanSource {
    //searchOnline
    SearchOnlineBean createSearchOnlineBean(String keyWord);

    //contact
    List<DoubleSingleItemBean> createContactBeanList(boolean isT9, String keyWord);

    //app
    List<DoubleSingleItemBean> createAppBeanList(boolean isT9, String keyWord);
    //clearRecord
    //showmore

}
