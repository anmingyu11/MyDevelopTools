package com.smartisanos.quicksearchbox.repository;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.smartisanos.quicksearchbox.repository.contact.db.table.ContactSearchIndexTable;
import com.smartisanos.quicksearchbox.util.LogUtil;


/**
 * Created by anmingyu on 16-9-9.
 */
public class DataBaseHelper extends SQLiteOpenHelper {

    //global
    private static Context mContext;
    private static DataBaseHelper mDataBaseHelper;
    //private static SQLiteDatabase mWritableDb;
    //private static SQLiteDatabase mReadableDb;
    //Db property
    private static final String DB_NAME = "SearchIndex.db";
    private static final int DB_VERSION = 1;


    private DataBaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    private DataBaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version, DatabaseErrorHandler
            errorHandler) {
        super(context, name, factory, version, errorHandler);
    }

    public static DataBaseHelper getInstance(Context context) {
        if (mDataBaseHelper == null) {
            mDataBaseHelper = new DataBaseHelper(context);
        }
        return mDataBaseHelper;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //create index of app
        //create index of contact
        db.execSQL(ContactSearchIndexTable.CREATE_TABLE_SQL);
        //db.execSQL(AppSearchIndexTable.CREATE_TABLE_SQL);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        super.onDowngrade(db, oldVersion, newVersion);
        recreateDb(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    private void recreateDb(SQLiteDatabase db) {
        db.execSQL(ContactSearchIndexTable.DROP_TABLE_SQL);
        //db.execSQL(AppSearchIndexTable.DROP_TABLE_SQL);
        //recreaate app
        onCreate(db);
    }

    public void recreateAppTable() {
        SQLiteDatabase db = getWritableDatabase();
        //db.execSQL(AppSearchIndexTable.DROP_TABLE_SQL);
        //db.execSQL(AppSearchIndexTable.CREATE_TABLE_SQL);
        if (db != null) {
            db.close();
            db = null;
        }
        LogUtil.debug("删除并重新创建app索引表");
    }

    public void recreateContactTable() {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL(ContactSearchIndexTable.DROP_TABLE_SQL);
        db.execSQL(ContactSearchIndexTable.CREATE_TABLE_SQL);
        if (db != null) {
            db.close();
            db = null;
        }
        LogUtil.debug("删除并重新创建联系人索引表");
    }

    public Cursor query(String table, String[] columns, String selection,
                        String[] selectionArgs, String orderBy) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(table, columns, selection, selectionArgs, null, null, orderBy);
    }

    public synchronized int update(String table, ContentValues contentValues, String whereClause, String[] whereArgs) {
        SQLiteDatabase db = getWritableDatabase();
        return db.update(table, contentValues, whereClause, whereArgs);
    }

    public synchronized int[] update(String table, ContentValues[] contentValues, String whereClause, String[][] whereArgs) {
        SQLiteDatabase db = getWritableDatabase();
        int[] updateArray = new int[contentValues.length];
        try {
            db.beginTransaction();
            for (int i = 0; i < contentValues.length; i++) {
                updateArray[i] = db.update(table, contentValues[i], whereClause, whereArgs[i]);
            }
            db.setTransactionSuccessful();
            db.endTransaction();
            return updateArray;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (db != null) {
                db.close();
                db = null;
            }
        }
    }

    /*
    public synchronized long insert(String table, ContentValues values) {
        SQLiteDatabase db = getWritableDatabase();
        db.inser
    }
    */

    public synchronized long insert(String table, ContentValues values) {
        SQLiteDatabase db = getWritableDatabase();
        return db.insertOrThrow(table, null, values);
    }

    public synchronized long[] insert(String table, ContentValues[] contentValues) {
        SQLiteDatabase db = getWritableDatabase();
        long[] insertList = new long[contentValues.length];
        try {
            db.beginTransaction();
            for (int i = 0; i < contentValues.length; i++) {
                if (contentValues[i] != null) {
                    insertList[i] = db.insertOrThrow(table, null, contentValues[i]);
                }
            }
            db.setTransactionSuccessful();
            db.endTransaction();
            return insertList;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (db != null) {
                db.close();
                db = null;
            }
        }
    }

    public synchronized int delete(String table, String whereClause, String[] whereArgs) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(table, whereClause, whereArgs);
    }

    public synchronized int[] delete(String table, String whereClause, String[][] whereArgs) {
        SQLiteDatabase db = getWritableDatabase();
        int[] deleteList = new int[whereArgs.length];
        db.beginTransaction();
        for (int i = 0; i < whereArgs.length; i++) {
            deleteList[i] = db.delete(table, whereClause, whereArgs[i]);
        }
        db.setTransactionSuccessful();
        db.endTransaction();
        db.close();
        db = null;
        return deleteList;
    }
}