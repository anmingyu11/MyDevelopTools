package com.smartisanos.quicksearchbox.repository.contact.db.helper;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;

import com.smartisanos.quicksearchbox.SearchMainActivity;
import com.smartisanos.quicksearchbox.pinyinsearch.util.QwertyUtil;
import com.smartisanos.quicksearchbox.pinyinsearch.util.T9Util;
import com.smartisanos.quicksearchbox.repository.BaseDbHelper;
import com.smartisanos.quicksearchbox.repository.DataBaseHelper;
import com.smartisanos.quicksearchbox.repository.contact.bean.ContactBean;
import com.smartisanos.quicksearchbox.repository.contact.db.table.ContactSearchIndexTable;
import com.smartisanos.quicksearchbox.util.IndexUtil;
import com.smartisanos.quicksearchbox.util.LogUtil;
import com.smartisanos.quicksearchbox.util.Util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Created by anmingyu on 16-9-13.
 */
public class ContactSearchIndexHelper implements BaseDbHelper {

    //global
    private static ContactSearchIndexHelper sContactSearchIndexHelper;
    private Context mContext;
    private SearchMainActivity mMainActivity;
    private DataBaseHelper mDataBaseHelper;
    private ContentResolver mContentResolver;

    //单线程的线程池,所有关于db的操作都将在此线程池中排队执行
    private ExecutorService mExecutorService;
    private static final short EXECUTOR_TIMEOUT_SECONDS = 8;
    private static final String TAG = "ContactSearchIndexHelper";

    //实例化新的线程池,所有数据库任务都将再此执行
    private void initExecutor() {
        if (mExecutorService == null) {
            mExecutorService = Executors.newSingleThreadScheduledExecutor();
        } else if (mExecutorService.isTerminated()) {
            mExecutorService = null;
            mExecutorService = Executors.newSingleThreadScheduledExecutor();
        }
    }

    //diffType
    private Integer DIFFTYPE_REMOVE = 0;
    private Integer DIFFTYPE_ADD = 1;
    private Integer DIFFTYPE_MODIFY = 2;

    public Integer getDiffTypeRemove() {
        return DIFFTYPE_REMOVE;
    }

    public Integer getDiffTypeAdd() {
        return DIFFTYPE_ADD;
    }

    public Integer getDiffTypeModity() {
        return DIFFTYPE_MODIFY;
    }

    //beans
    private static ContactBean[] mLocalContactBeans = null;
    private static final Object mLocalContactBeanLocker = new Object();

    public static Object getLocalContactBeanLocker() {
        return mLocalContactBeanLocker;
    }

    //rawContent URI
    private static final Uri RAWCONTACT_CONTENT_URI = ContactsContract.RawContacts.CONTENT_URI;
    //phoneContent URI
    private static final Uri PHONE_CONTENT_URI = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;

    //rawcontacts projections
    private static final String[] Raw_IdProjection = new String[]{
            ContactsContract.RawContacts._ID,
    };
    //rawContactsIdVersion projections
    private static final int RawcontactsProjectionId_Id = 0;
    private static final int RawcontactsProjectionId_Version = 1;
    private static final String[] Raw_VersionProjection = new String[]{
            ContactsContract.RawContacts._ID,
            ContactsContract.RawContacts.VERSION
    };
    //phonedetail projections
    private static final int PhoneDetailProjection_RawId = 0;
    private static final int PhoneDetailProjection_ContactId = 1;
    private static final int PhoneDetailProjection_LookUpKey = 2;
    private static final int PhoneDetailProjection_Display_Name = 3;
    private static final int PhoneDetailProjection_Number = 4;
    private static final String[] PhonedetailProjection = new String[]{
            ContactsContract.CommonDataKinds.Phone.RAW_CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
    };
    //tablename
    private static final String mTableName = ContactSearchIndexTable.TABLE_NAME;

    private ContactSearchIndexHelper(Context context) {
        this.mContext = context;
        mMainActivity = (SearchMainActivity) context;
        mDataBaseHelper = DataBaseHelper.getInstance(context);
    }

    public static ContactSearchIndexHelper getInstance(Context context) {
        if (sContactSearchIndexHelper == null) {
            sContactSearchIndexHelper = new ContactSearchIndexHelper(context);
        }
        return sContactSearchIndexHelper;
    }

    //获取contentResolver
    private void initContentResolver() {
        if (mContentResolver != null) {
            return;
        }
        mContentResolver = mContext.getContentResolver();
    }

    /**
     * 清空本地的localBeans
     */
    private void clearLocalContactBeans() {
        synchronized (mLocalContactBeanLocker) {
            mLocalContactBeans = null;
        }
    }

    @Override
    public long insertSingle(ContentValues contentValues) {
        synchronized (mLocalContactBeanLocker) {
            return mDataBaseHelper.insert(mTableName, contentValues);
        }
    }

    @Override
    public long[] insertBulk(ContentValues[] contentValuesArray) {
        synchronized (mLocalContactBeanLocker) {
            return mDataBaseHelper.insert(mTableName, contentValuesArray);
        }
    }

    @Override
    public int updateSingle(ContentValues contentValues, String whereClause, String[] whereArgs) {
        synchronized (mLocalContactBeanLocker) {
            return mDataBaseHelper.update(mTableName, contentValues, whereClause, whereArgs);
        }
    }

    @Override
    public int[] updateBulk(ContentValues[] contentValues, String whereClause, String[][] whereArgs) {
        synchronized (mLocalContactBeanLocker) {
            return mDataBaseHelper.update(mTableName, contentValues, whereClause, whereArgs);
        }
    }

    @Override
    public int deleteSingle(String whereClause, String[] whereArgs) {
        synchronized (mLocalContactBeanLocker) {
            return mDataBaseHelper.delete(mTableName, whereClause, whereArgs);
        }
    }

    @Override
    public int[] deleteBulk(String whereClause, String[][] whereArgs) {
        synchronized (mLocalContactBeanLocker) {
            return mDataBaseHelper.delete(mTableName, whereClause, whereArgs);
        }
    }


    /**
     * @param reload 如果此参数设为true,重新初始化索引表,如果是false,获取Helper中的索引数组,如果索引数组为null,重新初始化之
     * @return
     */
    public ContactBean[] getLocalContactBeans(boolean reload) {
        if (mLocalContactBeans == null || reload) {
            clearLocalContactBeans();
            //获取三次,避免意外
            for (int i = 0; i < 3; i++) {
                if ((mLocalContactBeans = reloadLocalContactBeans()) != null) {
                    return mLocalContactBeans;
                }
            }
            throw new RuntimeException("获取索引表失败");
        }
        return mLocalContactBeans;
    }

    /**
     * 获取应用本地数据库中的索引表
     *
     * @return
     */
    private ContactBean[] reloadLocalContactBeans() {
        initExecutor();
        Future<ContactBean[]> future = mExecutorService.submit(
                new Callable() {
                    @Override
                    public ContactBean[] call() throws Exception {
                        synchronized (mLocalContactBeanLocker) {
                            try {
                                return mLocalContactBeans = loadLocalContactBeans();
                            } catch (Exception e) {
                                e.printStackTrace();
                                return null;
                            }
                        }
                    }
                });
        try {
            if (future.get(EXECUTOR_TIMEOUT_SECONDS, TimeUnit.SECONDS) != null) {
                if (mLocalContactBeans != null) {
                    LogUtil.debug("索引表长度 :" + mLocalContactBeans.length);
                    return mLocalContactBeans;
                } else {
                    LogUtil.debug("索引表为空");
                    return mLocalContactBeans = new ContactBean[0];
                }
            } else {
                //一般只有表中啥没有的时候到这里
                return mLocalContactBeans = new ContactBean[0];
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
            if (!future.isCancelled()) {
                future.cancel(true);
            }
            return null;
        } catch (ExecutionException e) {
            e.printStackTrace();
            if (!future.isCancelled()) {
                future.cancel(true);
            }
            return null;
        } catch (TimeoutException e) {
            LogUtil.error("获取本地联系人索引超时,重新初始化联系人索引表");
            e.printStackTrace();
            if (!future.isCancelled()) {
                future.cancel(true);
            }
            if (reinitLocalContactIndex()) {
                LogUtil.debug("重新创建索引表成功");
                Util.indexDataInited(mContext);
            } else {
                LogUtil.debug("重新创建索引表失败");
            }
            return null;
        }
    }

    /**
     * 第一次初始化表
     *
     * @return
     */
    public boolean initLocalContactIndexFirst() {
        for (int i = 0; i < 3; i++) {
            if (initLocalSearchIndexDb()) {
                synchronized (mLocalContactBeanLocker) {
                    mLocalContactBeans = loadLocalContactBeans();
                }
                if (mLocalContactBeans != null) {
                    LogUtil.debug("索引表长度 :" + mLocalContactBeans.length);
                } else {
                    LogUtil.debug("索引表为空");
                }
                return true;
            }
        }
        return false;
    }

    private int[] extractRawVersionFromLocalbean() {
        getLocalContactBeans(true);
        int[] rawVersion = new int[mLocalContactBeans.length];
        for (int i = 0; i < rawVersion.length; i++) {
            if (mLocalContactBeans[i] == null) {
                rawVersion[i] = -1;
            } else {
                rawVersion[i] = mLocalContactBeans[i].getRawDataVersion();
            }
        }
        return rawVersion;
    }

    /**
     * 重新初始化表(阻塞)
     */
    public boolean reinitLocalContactIndex() {
        for (int i = 0; i < 3; i++) {
            if (reInitLocalContactIndexTableBlock()) {
                synchronized (mLocalContactBeanLocker) {
                    mLocalContactBeans = loadLocalContactBeans();
                }
                if (mLocalContactBeans != null) {
                    LogUtil.debug("索引表长度 :" + mLocalContactBeans.length);
                } else {
                    LogUtil.debug("索引表为空");
                }
                return true;
            }
        }
        return false;
    }

    /**
     * 重新初始化表非阻塞
     */
    public void reInitLocalContactIndexTableUnBlock() {
        initExecutor();
        mExecutorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    mDataBaseHelper.recreateContactTable();
                    if (initLocalSearchIndexDb()) {
                        synchronized (mLocalContactBeanLocker) {
                            mLocalContactBeans = loadLocalContactBeans();
                        }
                        if (mLocalContactBeans != null) {
                            LogUtil.debug("索引表长度 :" + mLocalContactBeans.length);
                        } else {
                            LogUtil.debug("索引表为空");
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    /**
     * 重新从系统中获取联系人信息初始化索引表(阻塞)
     *
     * @return
     */
    private boolean reInitLocalContactIndexTableBlock() {
        initExecutor();
        Future<Boolean> future = mExecutorService.submit(new Callable() {
            @Override
            public Boolean call() throws Exception {
                try {
                    mDataBaseHelper.recreateContactTable();
                    return initLocalSearchIndexDb();
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
            }
        });
        try {
            Boolean result = future.get(EXECUTOR_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            if (result != null && result) {
                return true;
            } else {
                return false;
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
            return false;
        } catch (ExecutionException e) {
            e.printStackTrace();
            return false;
        } catch (TimeoutException e) {
            e.printStackTrace();
            LogUtil.error("初始化表超时或手机联系人过多");
            return false;
        }
    }

    /**
     * 获得最新的通讯录rawVersion
     *
     * @return {@code int[rawId]=rawVersion}
     */
    public int[] loadRawVersionFromProvider() {
        long start = System.currentTimeMillis();
        initContentResolver();
        Cursor cursor = mContentResolver.query(RAWCONTACT_CONTENT_URI, Raw_VersionProjection, null, null, null);
        if (cursor == null) {
            return new int[0];
        }
        //int[0]为空值.
        int columnIndex_rawId = cursor.getColumnIndex(Raw_VersionProjection[RawcontactsProjectionId_Id]);
        int columnIndex_dataVersion = cursor.getColumnIndex(Raw_VersionProjection[RawcontactsProjectionId_Version]);
        int[] rawVersionArray = new int[0];
        int max = -1;
        try {
            if (!cursor.moveToFirst()) {
                return new int[0];
            }
            int current;
            //有的手机获得不到最大的rawcount所以获取最大的rawId
            do {
                current = cursor.getInt(columnIndex_rawId);
                if (current > max) {
                    max = current;
                }
            } while (cursor.moveToNext());
            cursor.moveToFirst();
            rawVersionArray = new int[max + 1];
            do {
                rawVersionArray[cursor.getInt(columnIndex_rawId)] = cursor.getInt(columnIndex_dataVersion);
            } while (cursor.moveToNext());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
                cursor = null;
            }
        }
        return rawVersionArray;
    }

    /**
     * 从系统provider中返回最新的Contact表
     *
     * @return {@code 返回ContactBean[rawId] = ContactBean()} 如果系统中存在联系人,<br>
     * {@code 返回null} 如果系统中没有联系人,或者返回结果集为空
     */
    public ContactBean[] loadDetailFromProvider() {
        long start = System.currentTimeMillis();
        initContentResolver();
        ContactBean[] contactBeanArray;
        Cursor cursor = mContentResolver.query(PHONE_CONTENT_URI, PhonedetailProjection, null, null, null);
        if (cursor == null) {
            return null;
        }
        int[] rawVersionArray = loadRawVersionFromProvider();
        if (rawVersionArray.length <= 1) {
            LogUtil.debug("手机中没有联系人");
            return new ContactBean[0];
        } else {
            LogUtil.debug("手机中联系人的数量 : " + rawVersionArray.length);
        }
        //columnIndex
        int columnIndex_RawId = cursor.getColumnIndex(PhonedetailProjection[PhoneDetailProjection_RawId]);
        int columndIndex_ContactId = cursor.getColumnIndex(PhonedetailProjection[PhoneDetailProjection_ContactId]);
        int columnIndex_LookUpkey = cursor.getColumnIndex(PhonedetailProjection[PhoneDetailProjection_LookUpKey]);
        int columnIndex_DisplayName = cursor.getColumnIndex(PhonedetailProjection[PhoneDetailProjection_Display_Name]);
        int columnIndex_Number = cursor.getColumnIndex(PhonedetailProjection[PhoneDetailProjection_Number]);
        //get rawIdSize;
        contactBeanArray = new ContactBean[rawVersionArray.length];
        //make ContactBeanArray
        try {
            if (!cursor.moveToFirst()) {
                return new ContactBean[0];
            }
            do {
                int rawId = cursor.getInt(columnIndex_RawId);
                String displayName = cursor.getString(columnIndex_DisplayName);
                contactBeanArray[rawId] = new ContactBean(
                        rawId,
                        cursor.getInt(columndIndex_ContactId),
                        rawVersionArray[rawId],
                        displayName,
                        cursor.getString(columnIndex_LookUpkey),
                        cursor.getString(columnIndex_Number).replace("-", " ").replace(" ", "")
                );
            } while (cursor.moveToNext());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
                cursor = null;
            }
        }
        LogUtil.debug("从手机中获取联系人用时: " + (System.currentTimeMillis() - start));
        return contactBeanArray;
    }

    /**
     * 比较本地表和provider表中的不同项
     *
     * @return
     */
    public HashMap<Integer, List<ContactBean>> diffAndSyncLocalContact() {
        long start = System.currentTimeMillis();
        long end = 0;
        HashMap<Integer, List<ContactBean>> diffMap = new HashMap<Integer, List<ContactBean>>();
        diffMap.put(DIFFTYPE_ADD, new ArrayList<ContactBean>());
        diffMap.put(DIFFTYPE_MODIFY, new ArrayList<ContactBean>());
        diffMap.put(DIFFTYPE_REMOVE, new ArrayList<ContactBean>());
        start = System.currentTimeMillis();
        LogUtil.debug("从系统中获取联系人信息...");
        ContactBean[] contactBeanProvider = loadDetailFromProvider();
        if (contactBeanProvider == null) {
            //系统联系人里面啥都没有,重新创建表
            mDataBaseHelper.recreateContactTable();
            return null;
        }
        LogUtil.debug("从本地索引表中获取联系人信息...");
        getLocalContactBeans(true);
        if (mLocalContactBeans == null) {
            //本地表中没有东西,重新从系统中初始化表
            reInitLocalContactIndexTableUnBlock();
            return null;
        }
        int contactBeanLocalLength = mLocalContactBeans.length;
        int contactBeanProviderLength = contactBeanProvider.length;
        Log.d("main", " 本地表长度: " + contactBeanLocalLength + " 系统表长度: " + contactBeanProviderLength);
        int differenceLength = contactBeanProviderLength - contactBeanLocalLength;

        if (differenceLength < 0) {
            //此种情况应该只有重置整个表或者人为修改本地表的时候才有可能发生
            //重新初始化整个表
            reinitLocalContactIndex();
            return null;
        } else {
            //先比较相同rawId的部分
            for (int i = 1; i < contactBeanLocalLength; i++) {
                if (contactBeanProvider[i] == null && mLocalContactBeans[i] != null) {
                    //provider中删除了的但是本地没删除了的部分
                    diffMap.get(DIFFTYPE_REMOVE).add(mLocalContactBeans[i]);
                } else if (mLocalContactBeans[i] == null && contactBeanProvider[i] != null) {
                    //本地表异常,重新初始化
                    reInitLocalContactIndexTableUnBlock();
                    return null;
                } else if (mLocalContactBeans[i] != null && contactBeanProvider[i] != null
                        && contactBeanProvider[i].getRawDataVersion() != mLocalContactBeans[i].getRawDataVersion()) {
                    //provider中更改了的部分
                    diffMap.get(DIFFTYPE_MODIFY).add(contactBeanProvider[i]);
                }
            }
            //再比较provider中新增的部分
            for (int i = contactBeanLocalLength; i < contactBeanProviderLength; i++) {
                //如果添加联系人时没有加电话号,contactbeanprovider的长度也会增加,但是很多数据却不完全
                if (contactBeanProvider[i] != null) {
                    diffMap.get(DIFFTYPE_ADD).add(contactBeanProvider[i]);
                }
            }
        }
        return diffMap;
    }

    /**
     * 精确同步通讯录
     */
    public void syncContactAccurate() {
        initExecutor();
        HashMap<Integer, List<ContactBean>> diffMap = diffAndSyncLocalContact();
        if (diffMap == null) {
            return;
        }
        List<ContactBean> removeList = diffMap.get(DIFFTYPE_REMOVE);
        List<ContactBean> addList = diffMap.get(DIFFTYPE_ADD);
        List<ContactBean> modifyList = diffMap.get(DIFFTYPE_MODIFY);
        int removeListSize = removeList.size();
        int addListSize = addList.size();
        int modifyListSize = modifyList.size();
        LogUtil.debug("删除的联系人数量: " + removeListSize + "\n添加的联系人的数量: " + addListSize + "\n修改的联系人的数量: " + modifyListSize);
        //只要有这个后面就不用处理removelist了
        boolean reload = true;
        if (removeListSize > 0 && (addListSize > 0 || modifyListSize > 0)) {
            reInitLocalContactIndexTableUnBlock();
        } else if (removeListSize > 0) {
            removeItems(removeList, removeListSize);
        } else if (addListSize > 0 && modifyListSize > 0) {
            addItems(addList, addListSize);
            modifyItems(modifyList, modifyListSize);
        } else if (addListSize > 0) {
            addItems(addList, addListSize);
        } else if (modifyListSize > 0) {
            modifyItems(modifyList, modifyListSize);
        }
        getLocalContactBeans(reload);
        if (mMainActivity!=null) {
            mMainActivity.getMainHandler().sendEmptyMessage(SearchMainActivity.MSG_REFRESHRESULT);
        }
    }

    public void syncContact() {
        int[] rawVersionFromProvider = loadRawVersionFromProvider();
        int[] rawVersionFromLocal = extractRawVersionFromLocalbean();
        int providerLength = rawVersionFromProvider.length;
        int localLength = rawVersionFromLocal.length;
        int diffLength = providerLength - localLength;
        if (diffLength != 0) {
            LogUtil.debug("联系人有增加或删除,重新初始化索引表并更新索引数组");
            reInitLocalContactIndexTableUnBlock();
        } else {
            for (int i = 0; i < providerLength; i++) {
                if (rawVersionFromLocal[i] != -1 && rawVersionFromLocal[i] != rawVersionFromProvider[i]) {
                    LogUtil.debug("联系人有改变,重新初始化索引表并更新索引数组");
                    reInitLocalContactIndexTableUnBlock();
                    break;
                }
            }
        }
    }

    private void removeItems(List<ContactBean> removeList, int size) {
        ContactBean[] contactBeen = new ContactBean[0];
        contactBeen = removeList.toArray(contactBeen);
        ContentValues[] contentValues;
        contentValues = parseContactBeanToContentValues(contactBeen);
        final String[][] removeWhereArgs = new String[size][];
        for (int i = 0; i < removeWhereArgs.length; i++) {
            removeWhereArgs[i] = new String[]{removeList.get(i).getRawId() + ""};
        }
        initExecutor();
        mExecutorService.execute(new Runnable() {
            @Override
            public void run() {
                mDataBaseHelper.delete(mTableName, ContactSearchIndexTable.COLUMN_ID + "=?", removeWhereArgs);
            }
        });
    }

    private void addItems(List<ContactBean> addList, int size) {
        ContactBean[] contactBeen = new ContactBean[0];
        contactBeen = addList.toArray(contactBeen);
        final ContentValues[] contentValues;
        contentValues = parseContactBeanToContentValues(contactBeen);
        initExecutor();
        mExecutorService.execute(new Runnable() {
            @Override
            public void run() {
                mDataBaseHelper.insert(mTableName, contentValues);
            }
        });
    }

    private void modifyItems(List<ContactBean> modifyList, int size) {
        ContactBean[] contactBeen = new ContactBean[0];
        contactBeen = modifyList.toArray(contactBeen);
        final ContentValues[] contentValues;
        contentValues = parseContactBeanToContentValues(contactBeen);
        final String[][] updateWhereArgs = new String[size][];
        for (int i = 0; i < updateWhereArgs.length; i++) {
            updateWhereArgs[i] = new String[]{modifyList.get(i).getRawId() + ""};
        }
        initExecutor();
        mExecutorService.execute(new Runnable() {
            @Override
            public void run() {
                mDataBaseHelper.update(mTableName, contentValues, ContactSearchIndexTable.COLUMN_CONTACT_ID + "=?", updateWhereArgs);
            }
        });
    }

    public void showDiffContactMap(HashMap<Integer, List<ContactBean>> diffMap) {
        for (Integer diffType : diffMap.keySet()) {
            Log.d("amy", "----------------------beanlist: difftype " + diffType + "----------------------");
            for (ContactBean contactBean : diffMap.get(diffType)) {
                Log.d("amy", contactBean.getDisplayname() + contactBean.getNumber());
            }
        }
    }

    @Deprecated
    public int getProviderContactRawSize() {
        initContentResolver();
        Cursor cursor = mContentResolver.query(RAWCONTACT_CONTENT_URI, Raw_IdProjection, null, null, null);
        int count = -1;
        try {
            count = cursor.getCount();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
                cursor = null;
            }
        }
        return count;
    }

    /**
     * 初始化整个索引表 和本地的索引数组
     */
    private boolean initLocalSearchIndexDb() {
        LogUtil.debug("开始初始化索引表...");
        long start = System.currentTimeMillis();
        ContactBean[] contactBeanArray = loadDetailFromProvider();
        if (contactBeanArray != null) {
            if (contactBeanArray.length == 0) {
                return true;
            }
            LogUtil.debug("初始化应用联系人索引表ing");
            ContentValues[] contentValues = parseContactBeanToContentValues(contactBeanArray);
            if (null == insertBulk(contentValues)) {
                LogUtil.error("初始化应用联系人索引表失败");
                return false;
            } else {
                LogUtil.debug("初始化索引表总用时 : " + (System.currentTimeMillis() - start));
                return true;
            }
        } else {
            LogUtil.error("初始化应用联系人索引表失败");
            return false;
        }
    }

    /**
     * @param contactBean if contactBean == null return null , else return ContactBean
     * @return
     */
    private ContentValues parseContactBeanToContentValues(ContactBean contactBean) {
        ContentValues contentValues = new ContentValues(9);
        if (contactBean != null) {
            String[] searchIndex = IndexUtil.parsePinYinUnit(contactBean.getPinyinSearchUnit());
            contentValues = new ContentValues(9);
            contentValues.put(ContactSearchIndexTable.COLUMN_ID, contactBean.getRawId());
            contentValues.put(ContactSearchIndexTable.COLUMN_CONTACT_ID, contactBean.getContactId());
            contentValues.put(ContactSearchIndexTable.COLUMN_DATAVERSION, contactBean.getRawDataVersion());
            contentValues.put(ContactSearchIndexTable.COLUMN_LOOKUPKEY, contactBean.getLookupkey());
            contentValues.put(ContactSearchIndexTable.COLUMN_DISPLAYNAME, contactBean.getDisplayname());
            contentValues.put(ContactSearchIndexTable.COLUMN_NUMBER, contactBean.getNumber());
            contentValues.put(ContactSearchIndexTable.COLUMN_ORIGININDEX, searchIndex[2]);
            contentValues.put(ContactSearchIndexTable.COLUMN_QWERTYINDEX, searchIndex[0]);
            contentValues.put(ContactSearchIndexTable.COLUMN_T9INDEX, searchIndex[1]);
            return contentValues;
        } else {
            return null;
        }
    }

    /**
     * @param contactBeans
     * @return
     */
    private ContentValues[] parseContactBeanToContentValues(ContactBean[] contactBeans) {
        int contactBeanArrayLength = contactBeans.length;
        ContentValues[] contentValues = new ContentValues[contactBeanArrayLength];
        for (int i = 0; i < contactBeanArrayLength; i++) {
            contentValues[i] = parseContactBeanToContentValues(contactBeans[i]);
        }
        return contentValues;
    }

    /**
     * load local rawVersion
     *
     * @return int[rawId] = rawVersion
     */
    public int[] loadRawVersion(String selection, String[] selectionArgs, String orderBy) {
        int versionResult[];
        Cursor cursor = mDataBaseHelper.query(mTableName, Raw_VersionProjection, selection, selectionArgs, orderBy);
        if (cursor == null) {
            return new int[0];
        }
        versionResult = new int[getLocalContactMaxRawId()];
        //cursorIndex
        int columnIndex_rawId = cursor.getColumnIndex(ContactSearchIndexTable.COLUMN_ID);
        int columnIndex_version = cursor.getColumnIndex(ContactSearchIndexTable.COLUMN_DATAVERSION);
        if (!cursor.moveToFirst()) {
            return new int[0];
        }
        do {
            versionResult[cursor.getInt(columnIndex_rawId)] = cursor.getInt(columnIndex_version);
        } while (cursor.moveToNext());
        if (cursor != null) {
            cursor.close();
            cursor = null;
        }
        return versionResult;
    }

    //获取表中的最大的rawId,也就是数组的长度
    private int getLocalContactMaxRawId() {
        Cursor cursor = mDataBaseHelper.query(mTableName, new String[]{ContactSearchIndexTable.COLUMN_ID}, null, null, null);
        int columnIndex_rawId = cursor.getColumnIndex(ContactSearchIndexTable.COLUMN_ID);
        int max = cursor.getCount();
        if (max == 0) {
            return -1;
        }
        int temp;
        try {
            cursor.moveToLast();
            do {
                temp = cursor.getInt(columnIndex_rawId);
                if (temp > max) {
                    max = temp;
                }
            } while (cursor.moveToPrevious());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
                cursor = null;
            }
        }
        return max;
    }

    /**
     * 获取app的联系人索引表
     *
     * @return ContactBean[] contactBeans
     */
    private ContactBean[] loadLocalContactBeans() {
        ContactBean[] contactBeanArray;
        String[] searchIndex = new String[3];
        Cursor cursor = mDataBaseHelper.query(mTableName, null, null, null, null);
        if (cursor == null) {
            return null;
        }
        long start = System.currentTimeMillis();
        int length = getLocalContactMaxRawId();
        if (length == -1) {
            return null;
        }
        contactBeanArray = new ContactBean[length + 1];
        //columnIndexes
        int columnIndex_rawId = cursor.getColumnIndex(ContactSearchIndexTable.COLUMN_ID);
        int columnIndex_contactId = cursor.getColumnIndex(ContactSearchIndexTable.COLUMN_CONTACT_ID);
        int columnIndex_version = cursor.getColumnIndex(ContactSearchIndexTable.COLUMN_DATAVERSION);
        int columnIndex_lookupkey = cursor.getColumnIndex(ContactSearchIndexTable.COLUMN_LOOKUPKEY);
        int columnIndex_displayname = cursor.getColumnIndex(ContactSearchIndexTable.COLUMN_DISPLAYNAME);
        int columnIndex_number = cursor.getColumnIndex(ContactSearchIndexTable.COLUMN_NUMBER);
        int columnIndex_originindex = cursor.getColumnIndex(ContactSearchIndexTable.COLUMN_ORIGININDEX);
        int columnIndex_qwetryindex = cursor.getColumnIndex(ContactSearchIndexTable.COLUMN_QWERTYINDEX);
        int columnIndex_t9index = cursor.getColumnIndex(ContactSearchIndexTable.COLUMN_T9INDEX);
        try {
            if (!cursor.moveToFirst()) {
                return null;
            }
            do {
                int rawId = cursor.getInt(columnIndex_rawId);
                String displayName = cursor.getString(columnIndex_displayname);
                searchIndex[0] = cursor.getString(columnIndex_originindex);
                searchIndex[1] = cursor.getString(columnIndex_qwetryindex);
                searchIndex[2] = cursor.getString(columnIndex_t9index);
                contactBeanArray[rawId] = new ContactBean(rawId,
                        cursor.getInt(columnIndex_contactId),
                        cursor.getInt(columnIndex_version),
                        displayName,
                        cursor.getString(columnIndex_lookupkey),
                        cursor.getString(columnIndex_number),
                        IndexUtil.unParsePinyinUnit(displayName, searchIndex)
                        //new PinyinSearchUnit(displayName)
                );
            } while (cursor.moveToNext());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
                cursor = null;
            }
        }
        return contactBeanArray;
    }

    public List<ContactBean> qwertySearch(String keyWord) {
        List<ContactBean> resultList;
        if (keyWord == null) {
            throw new NullPointerException("keyWord is null");
        }
        if (mLocalContactBeans == null) {
            getLocalContactBeans(true);
        }
        /**
         * search process:
         * 1:Search by phone number
         * 2:Search by name
         * (1)Search by original name
         * (2)Search* by name pinyin characters(original name->name pinyin characters)
         */
        synchronized (mLocalContactBeanLocker) {
            int mLocalContactBeansLength = mLocalContactBeans.length;
            if (mLocalContactBeansLength <= 0) {
                return null;
            } else {
                resultList = new ArrayList<ContactBean>();
            }
            for (int i = 0; i < mLocalContactBeansLength; i++) {
                ContactBean contactBean = mLocalContactBeans[i];
                if (contactBean == null) {
                    continue;
                }
                //号码搜索
                if (TextUtils.isDigitsOnly(keyWord) && contactBean.getNumber().contains(keyWord)) {
                    //只有数字
                    resultList.add(contactBean);
                    continue;
                }
                //名字搜索
                if (QwertyUtil.match(contactBean.getPinyinSearchUnit(), keyWord)) {
                    resultList.add(contactBean);
                    continue;
                }
            }
        }
        return resultList;
    }

    public List<ContactBean> t9Search(String keyWord) {
        List<ContactBean> resultList;
        if (keyWord == null) {
            throw new NullPointerException("keyWord is null");
        }
        if (mLocalContactBeans == null) {
            getLocalContactBeans(true);
        }
        /**
         * search process:
         * 1:Search by phone number
         * 2:Search by name
         * (1)Search by original name
         * (2)Search* by name pinyin characters(original name->name pinyin characters)
         */
        synchronized (mLocalContactBeanLocker) {
            int mLocalContactBeansLength = mLocalContactBeans.length;
            if (mLocalContactBeansLength <= 0) {
                return null;
            } else {
                resultList = new ArrayList<ContactBean>();
            }
            for (int i = 0; i < mLocalContactBeansLength; i++) {
                ContactBean contactBean = mLocalContactBeans[i];
                if (contactBean == null) {
                    continue;
                }
                //号码搜索
                if (TextUtils.isDigitsOnly(keyWord) && contactBean.getNumber().contains(keyWord)) {
                    //只有数字
                    resultList.add(contactBean);
                    continue;
                }
                //名字搜索
                if (T9Util.match(contactBean.getPinyinSearchUnit(), keyWord)) {
                    resultList.add(contactBean);
                    continue;
                }
            }
        }
        return resultList;
    }
}
