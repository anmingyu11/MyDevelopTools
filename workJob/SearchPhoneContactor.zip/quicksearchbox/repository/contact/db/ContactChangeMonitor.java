package com.smartisanos.quicksearchbox.repository.contact.db;

import android.content.Context;
import android.database.ContentObserver;
import android.os.Handler;
import android.provider.ContactsContract;

import com.smartisanos.quicksearchbox.repository.contact.db.helper.ContactSearchIndexHelper;
import com.smartisanos.quicksearchbox.util.LogUtil;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Created by anmingyu on 16-9-21.
 */
public class ContactChangeMonitor {
    //global
    private Context mContext;
    private static ContactChangeMonitor mInstance;
    private ContentObserver mContentObserver = null;
    //counter
    private int newTaskCount = 0;
    private int oldTaskCount = 0;
    //Timer
    private ScheduledExecutorService executorService;
    private static final short executorInitTime = 3;
    private static final short executorPeroid = 3;

    private ContactChangeMonitor(Context context) {
        mContext = context;
    }

    private void initTimer() {
        if (executorService == null) {
            executorService = Executors.newSingleThreadScheduledExecutor();
            executorService.scheduleAtFixedRate(new Runnable() {
                @Override
                public void run() {
                    LogUtil.debug("newTaskCount : " + newTaskCount + " | oldTaskCount : " + oldTaskCount);
                    if (oldTaskCount != 0 && newTaskCount != 0 && oldTaskCount == newTaskCount) {
                        //ToDO diffjob
                        ContactSearchIndexHelper contactSearchIndexHelper = ContactSearchIndexHelper.getInstance(mContext);
                        contactSearchIndexHelper.syncContactAccurate();
                        //contactSearchIndexHelper.syncContact();
                        newTaskCount = 0;
                        oldTaskCount = 0;
                    } else if (oldTaskCount != newTaskCount) {
                        oldTaskCount = newTaskCount;
                    }
                }
            }, executorInitTime, executorPeroid, TimeUnit.SECONDS);
        }
    }

    private void destroyTimer() {
        if (executorService == null){
            return;
        }
        executorService.shutdownNow();
        try {
            if (executorService.awaitTermination(3, TimeUnit.SECONDS)) {
                executorService = null;
            } else {
                executorService = null;
                throw new TimeoutException();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (TimeoutException e) {
            e.printStackTrace();
        }
    }

    public static ContactChangeMonitor getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new ContactChangeMonitor(context);
        }
        return mInstance;
    }

    public void registMonitor() {
        LogUtil.debug("注册Monitor....");
        if (mContentObserver == null) {
            mContentObserver = new ContentObserver(new Handler()) {
                @Override
                public void onChange(boolean selfChange) {
                    super.onChange(selfChange);
                    newTaskCount++;
                }
            };
        }
        mContext.getContentResolver().registerContentObserver(ContactsContract.RawContacts.CONTENT_URI, true, mContentObserver);
        initTimer();
    }

    public void unRegistMonitor() {
        if (mContentObserver != null) {
            mContext.getContentResolver().unregisterContentObserver(mContentObserver);
        }
        mContentObserver = null;
        destroyTimer();
        //it can be null in here
        mInstance = null;
    }
}
