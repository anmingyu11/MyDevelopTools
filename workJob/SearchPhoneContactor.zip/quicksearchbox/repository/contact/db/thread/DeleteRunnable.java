package com.smartisanos.quicksearchbox.repository.contact.db.thread;

import android.util.Log;

import com.smartisanos.quicksearchbox.repository.contact.bean.ContactBean;
import com.smartisanos.quicksearchbox.repository.contact.db.helper.ContactSearchIndexHelper;
import com.smartisanos.quicksearchbox.repository.contact.db.table.ContactSearchIndexTable;


/**
 * Created by anmingyu on 16-9-18.
 */
public class DeleteRunnable implements Runnable {
    private ContactSearchIndexHelper mContactSearchIndexHelper;
    private ContactBean[] mContactBeans;

    public DeleteRunnable(ContactSearchIndexHelper contactSearchIndexHelper, ContactBean[] contactBeans) {
        mContactSearchIndexHelper = contactSearchIndexHelper;
        mContactBeans = contactBeans;
    }

    @Override
    public void run() {
        try {
            String[][] whereClause = new String[mContactBeans.length][];
            for (int i = 0; i < mContactBeans.length; i++) {
                whereClause[i] = new String[]{mContactBeans[i].getRawId() + ""};
            }
            int[] deleted = mContactSearchIndexHelper.deleteBulk(ContactSearchIndexTable.COLUMN_ID + "=?", whereClause);
            Log.d("amy", "deleted: " + deleted.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
