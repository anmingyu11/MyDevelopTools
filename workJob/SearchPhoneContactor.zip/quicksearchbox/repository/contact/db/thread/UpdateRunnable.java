package com.smartisanos.quicksearchbox.repository.contact.db.thread;

import android.content.ContentValues;
import android.util.Log;

import com.smartisanos.quicksearchbox.repository.contact.bean.ContactBean;
import com.smartisanos.quicksearchbox.repository.contact.db.helper.ContactSearchIndexHelper;
import com.smartisanos.quicksearchbox.repository.contact.db.table.ContactSearchIndexTable;


/**
 * Created by anmingyu on 16-9-18.
 */
public class UpdateRunnable implements Runnable {
    private ContactSearchIndexHelper mContactSearchIndexHelper;
    private ContentValues[] mContentValues;
    private ContactBean[] mContactBeans;

    public UpdateRunnable(ContactSearchIndexHelper contactSearchIndexHelper, ContentValues[] contentValues, ContactBean[] contactBeans) {
        mContactSearchIndexHelper = contactSearchIndexHelper;
        mContentValues = contentValues;
        mContactBeans = contactBeans;
    }

    @Override
    public void run() {
        try {
            String[][] whereArgs = new String[mContentValues.length][];
            for (int i = 0; i < whereArgs.length; i++) {
                whereArgs[i] = new String[]{mContactBeans[i].getRawId() + ""};
            }
            int[] updated = mContactSearchIndexHelper.updateBulk(mContentValues, ContactSearchIndexTable.COLUMN_ID + "=?", whereArgs);
            Log.d("amy", "updated : " + updated.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
