package com.smartisanos.quicksearchbox.repository.contact.db.thread;

import android.content.ContentValues;
import android.util.Log;

import com.smartisanos.quicksearchbox.repository.contact.db.helper.ContactSearchIndexHelper;


/**
 * Created by anmingyu on 16-9-18.
 */
public class InsertRunnable implements Runnable {
    private ContactSearchIndexHelper mContactSearchIndexHelper;
    private ContentValues[] mContentValues;

    public InsertRunnable(ContactSearchIndexHelper contactSearchIndexHelper, ContentValues[] contentValues) {
        mContactSearchIndexHelper = contactSearchIndexHelper;
        mContentValues = contentValues;
    }

    @Override
    public void run() {
        try {
            long[] inserted = mContactSearchIndexHelper.insertBulk(mContentValues);
            Log.d("amy", "inserted : " + inserted.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
