package com.smartisanos.quicksearchbox.repository.contact.db.table;

import android.provider.ContactsContract;

/**
 * Created by anmingyu on 16-9-9.
 */
public class ContactSearchIndexTable {
    public static final String TABLE_NAME = "contact_index";
    public static final String COLUMN_ID = ContactsContract.RawContacts._ID;
    public static final String COLUMN_CONTACT_ID = ContactsContract.RawContacts.CONTACT_ID;
    public static final String COLUMN_DATAVERSION = ContactsContract.RawContacts.VERSION;
    public static final String COLUMN_LOOKUPKEY = "lookupkey";
    public static final String COLUMN_DISPLAYNAME = "displayname";
    public static final String COLUMN_NUMBER = "number";
    public static final String COLUMN_ORIGININDEX = "origin_index";
    public static final String COLUMN_QWERTYINDEX = "qwerty_index";
    public static final String COLUMN_T9INDEX = "t9_index";

    public static final String CREATE_TABLE_SQL = " CREATE TABLE IF NOT EXISTS " + TABLE_NAME + "(" +
            COLUMN_ID + " INTEGER " + " UNIQUE NOT NULL," +
            COLUMN_CONTACT_ID + " INTEGER " + " NOT NULL," +
            COLUMN_DATAVERSION + " INTEGER NOT NULL," +
            COLUMN_LOOKUPKEY + " TEXT " + " NOT NULL," +
            COLUMN_DISPLAYNAME + " TEXT " + "NOT NULL," +
            COLUMN_NUMBER + " TEXT " + "NOT NULL," +
            COLUMN_ORIGININDEX + " TEXT " + "NOT NULL," +
            COLUMN_QWERTYINDEX + " TEXT " + "NOT NULL," +
            COLUMN_T9INDEX + " TEXT " + "NOT NULL" + ");";

    public static final String DROP_TABLE_SQL = "drop TABLE IF EXISTS " + TABLE_NAME + ";";
}
