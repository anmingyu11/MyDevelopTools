package com.smartisanos.quicksearchbox.repository.contact.bean;

/**
 * Created by anmingyu on 16-9-7.
 */
public class BaseContactBean {
    private int rawId;
    private int contactId;
    private int rawDataVersion;
    private String lookupkey;
    private String displayname;
    private String number;

    public BaseContactBean(int rawId, int contactId, int rawDataVersion, String displayname, String lookupkey, String number) {
        this.rawId = rawId;
        this.contactId = contactId;
        this.rawDataVersion = rawDataVersion;
        this.lookupkey = lookupkey;
        this.displayname = displayname;
        this.number = number;
    }

    public int getRawId() {
        return rawId;
    }

    public int getRawDataVersion() {
        return rawDataVersion;
    }

    public void setRawDataVersion(int rawDataVersion) {
        this.rawDataVersion = rawDataVersion;
    }

    public String getDisplayname() {
        return displayname;
    }

    public String getLookupkey() {
        return lookupkey;
    }

    public String getNumber() {
        return number;
    }

    public int getContactId() {
        return contactId;
    }

    @Override
    public String toString() {
        return "{" + rawId + " : " +
                rawDataVersion + " : " +
                displayname + " : " +
                lookupkey + " : " +
                number + " : " +
                '}';
    }
}
