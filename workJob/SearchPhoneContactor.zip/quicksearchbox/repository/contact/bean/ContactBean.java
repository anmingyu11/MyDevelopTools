package com.smartisanos.quicksearchbox.repository.contact.bean;

import android.util.Log;

import com.smartisanos.quicksearchbox.pinyinsearch.model.PinyinBaseUnit;
import com.smartisanos.quicksearchbox.pinyinsearch.model.PinyinSearchUnit;
import com.smartisanos.quicksearchbox.pinyinsearch.model.PinyinUnit;


/**
 * Created by anmingyu on 16-9-9.
 */
public class ContactBean extends BaseContactBean {

    private PinyinSearchUnit mPinyinSearchUnit;// save the mName converted to Pinyin characters.

    public ContactBean(int rawId, int contactId, int rawDataVersion, String displayname, String lookupkey, String number) {
        super(rawId, contactId, rawDataVersion, displayname, lookupkey, number);
        this.mPinyinSearchUnit = new PinyinSearchUnit(displayname);
    }

    public ContactBean(int rawId, int contactId, int rawDataVersion, String displayname, String lookupkey, String number, PinyinSearchUnit pinyinSearchUnit) {
        super(rawId, contactId, rawDataVersion, displayname, lookupkey, number);
        this.mPinyinSearchUnit = pinyinSearchUnit;
    }

    public ContactBean(ContactBean contactBean) {
        super(contactBean.getRawId(), contactBean.getContactId(), contactBean.getRawDataVersion(),
                contactBean.getDisplayname(), contactBean.getLookupkey(), contactBean.getNumber());
        //super(rawId, rawDataVersion, displayname, lookupkey, number);
        this.mPinyinSearchUnit = new PinyinSearchUnit(contactBean.getDisplayname());
    }

    public void show() {
        Log.d("amy","show : " + mPinyinSearchUnit.getPinyinUnits().size());
        for (PinyinUnit pinyinUnit : mPinyinSearchUnit.getPinyinUnits()) {
            for (PinyinBaseUnit pinyinBaseUnit : pinyinUnit.getPinyinBaseUnitIndex()) {
                Log.d("amy", "startposition : " + pinyinUnit.getStartPosition());
                Log.d("amy", "origin : " + pinyinBaseUnit.getOriginalString() + " pinyin : " + pinyinBaseUnit.getPinyin() + " number " +
                        pinyinBaseUnit.getNumber());
            }
        }
    }

    public PinyinSearchUnit getPinyinSearchUnit() {
        return mPinyinSearchUnit;
    }
}
