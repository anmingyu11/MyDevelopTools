package com.smartisanos.quicksearchbox.repository.contact.bean;

/**
 * Created by anmingyu on 16-9-12.
 */
public class ContactIndexBean {
}
