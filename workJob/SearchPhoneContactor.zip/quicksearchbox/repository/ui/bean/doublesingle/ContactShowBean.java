package com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.ContactsContract;

import com.smartisanos.home.R;
import com.smartisanos.quicksearchbox.ibase.BaseItemOnClikcListener;
import com.smartisanos.quicksearchbox.repository.contact.bean.ContactBean;

/**
 * Created by anmingyu on 16-9-5.
 */
public class ContactShowBean extends DoubleSingleItemBean {
    private static Intent makeContactIntent(Context context, ContactBean contactBean) {
        /*
        return new Intent(Intent.ACTION_VIEW, Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI,
                contactBean.getContactId() + ""));
                */
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI,
                contactBean.getContactId() + ""));
        //在nexus6 android7.0的手机上需要加extra,否则系统联系人会崩溃,空指针
        intent.putExtra(ContactsContract.Intents.Insert.NAME, contactBean.getDisplayname());
        return intent;
    }

    public ContactShowBean(final Context context, final ContactBean contactBean) {
        super(
                TYPE_ITEM_CONTACT,
                context.getResources().getDrawable(R.drawable.source_contactcommon_icon),
                contactBean.getDisplayname(),
                new BaseItemOnClikcListener() {
                    @Override
                    public boolean longClick() {
                        return false;
                    }

                    @Override
                    public void onClick() {
                        context.startActivity(makeContactIntent(context, contactBean));
                    }
                });
    }

}
