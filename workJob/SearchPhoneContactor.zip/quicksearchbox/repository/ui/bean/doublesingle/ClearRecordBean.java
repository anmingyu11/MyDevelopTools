package com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle;

import android.graphics.drawable.Drawable;

import com.smartisanos.quicksearchbox.ibase.BaseItemOnClikcListener;

/**
 * Created by anmingyu on 16-9-5.
 */
public class ClearRecordBean extends DoubleSingleItemBean {
    public ClearRecordBean(int type, Drawable icon, String text, BaseItemOnClikcListener baseItemOnClikcListener) {
        super(type, icon, text, baseItemOnClikcListener);
    }
}
