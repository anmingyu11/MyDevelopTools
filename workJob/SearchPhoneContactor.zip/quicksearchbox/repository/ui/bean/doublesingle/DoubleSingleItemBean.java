package com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle;

import android.graphics.drawable.Drawable;

import com.smartisanos.quicksearchbox.ibase.BaseItemOnClikcListener;
import com.smartisanos.quicksearchbox.repository.ui.bean.BaseBean;


/**
 * Created by anmingyu on 16-9-1.
 */
public class DoubleSingleItemBean extends BaseBean {

    //fields
    private Drawable mIcon;

    private String mText;

    private BaseItemOnClikcListener mBaseItemOnClikcListener;

    //setter and getters
    public Drawable getIcon() {
        return mIcon;
    }

    public void setIcon(Drawable icon) {
        mIcon = icon;
    }

    public String getText() {
        return mText;
    }

    public void setText(String text) {
        mText = text;
    }

    public BaseItemOnClikcListener getBaseItemOnClikcListener() {
        return mBaseItemOnClikcListener;
    }

    public void setBaseItemOnClikcListener(BaseItemOnClikcListener baseItemOnClikcListener) {
        mBaseItemOnClikcListener = baseItemOnClikcListener;
    }

    //constructors
    public DoubleSingleItemBean(int type, Drawable icon, String text,
                                BaseItemOnClikcListener baseItemOnClikcListener) {
        super(type);
        mIcon = icon;
        mText = text;
        mBaseItemOnClikcListener = baseItemOnClikcListener;
    }
}
