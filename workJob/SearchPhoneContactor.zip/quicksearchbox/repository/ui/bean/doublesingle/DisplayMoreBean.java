package com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle;

import android.content.Context;

import com.smartisanos.home.R;
import com.smartisanos.quicksearchbox.ibase.BaseItemOnClikcListener;

/**
 * Created by anmingyu on 16-9-5.
 */
public class DisplayMoreBean extends DoubleSingleItemBean {
    public DisplayMoreBean(Context context, BaseItemOnClikcListener baseItemOnClikcListener) {
        super(
                TYPE_ITEM_DISPLAYMORE,
                null,
                context.getResources().getString(R.string.singletext_item_displaymore),
                baseItemOnClikcListener);
    }
}
