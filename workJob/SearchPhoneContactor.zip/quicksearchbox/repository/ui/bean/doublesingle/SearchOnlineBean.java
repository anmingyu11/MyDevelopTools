package com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle;

import android.content.Context;

import com.smartisanos.home.R;
import com.smartisanos.quicksearchbox.ibase.BaseItemOnClikcListener;
import com.smartisanos.quicksearchbox.util.EngineUtil;

/**
 * Created by anmingyu on 16-9-5.
 */
public class SearchOnlineBean extends DoubleSingleItemBean {

    public SearchOnlineBean(final Context context, final String keyWord) {
        super(TYPE_ITEM_SEARCHONLINE,
                context.getResources().getDrawable(R.drawable.source_searchonline_icon),
                context.getResources().getString(R.string.singletext_item_searchonline),
                new BaseItemOnClikcListener() {
                    @Override
                    public boolean longClick() {
                        return false;
                    }

                    @Override
                    public void onClick() {
                        try {
                            context.startActivity(EngineUtil.makeSearchIntent(keyWord));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
    }
}
