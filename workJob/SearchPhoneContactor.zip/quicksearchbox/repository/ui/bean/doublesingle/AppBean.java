package com.smartisanos.quicksearchbox.repository.ui.bean.doublesingle;

import android.graphics.drawable.Drawable;

import com.smartisanos.quicksearchbox.ibase.BaseItemOnClikcListener;

/**
 * Created by anmingyu on 16-9-5.
 */
public class AppBean extends DoubleSingleItemBean {
    public AppBean(Drawable icon, String text, BaseItemOnClikcListener baseItemOnClikcListener) {
        super(TYPE_ITEM_APP,
                icon,
                text,
                baseItemOnClikcListener);
    }
}
