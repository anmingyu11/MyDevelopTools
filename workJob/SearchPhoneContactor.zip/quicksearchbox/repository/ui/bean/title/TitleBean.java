package com.smartisanos.quicksearchbox.repository.ui.bean.title;

import com.smartisanos.quicksearchbox.repository.ui.bean.BaseBean;

/**
 * Created by anmingyu on 16-9-2.
 */
public class TitleBean extends BaseBean {
    private String Title;

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public TitleBean(String title) {
        super(TYPE_TITLE);
        Title = title;
    }
}
