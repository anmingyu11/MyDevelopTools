package com.smartisanos.quicksearchbox.repository.ui.bean;

/**
 * Created by anmingyu on 16-9-2.
 */
public class BaseBean {

    public static final int TYPE_BASE = 14438;
    public static final int TYPE_TITLE = TYPE_BASE + 1;
    public static final int TYPE_ITEM_APP = TYPE_BASE + 2;
    public static final int TYPE_ITEM_CONTACT = TYPE_BASE + 3;
    public static final int TYPE_ITEM_SEARCHONLINE = TYPE_BASE + 4;
    public static final int TYPE_ITEM_CLEARRECORD = TYPE_BASE + 5;
    public static final int TYPE_ITEM_DISPLAYMORE = TYPE_BASE + 6;

    private int type;

    /**
     * type set
     *
     * @param type
     * {@link BaseBean#TYPE_BASE , }
     */
    public BaseBean(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
