package com.smartisanos.quicksearchbox;


import android.support.v4.app.Fragment;
import android.view.View;

/**
 * Created by anmingyu on 16-8-30.
 */
public class BaseFragment extends Fragment {
    /**
     * new Instance of this fragment
     *
     * @return
     */
    /*
    protected BaseFragment getInstance() {
        Bundle args = new Bundle();

        BaseFragment fragment = new EditBoxFragment();
        fragment.setArguments(args);
        return fragment;
    }
    */
    protected void initView(View root) {
    }
}
