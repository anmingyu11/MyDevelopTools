package com.smartisanos.quicksearchbox.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by anmingyu on 16-8-30.
 */
public class Util {

    public static final String PREF_NAME = "QuickSearchBoxSetting";
    private static boolean isT9Shown = true;
    private static final String spIsT9LastShown = "isT9LastShown";
    private static final String spIsDataInit = "isDataInit";

    /**
     * if param is null<br>
     * return a string of time type like this
     * "hh:mm:ss:SSS"
     *
     * @return "hh:mm:ss:SSS"
     */
    public static String getTimeStamp(String format) {
        //String dateFormatComplicate = "E yyyy.MM.dd 'at' hh:mm:ss a zzz";
        if (format == null) {
            format = "hh:mm:ss:SSS";
        }
        Date date = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        return "Time: " + simpleDateFormat.format(date);
    }

    /**
     * return a time in type long
     *
     * @return
     */
    public static Long getTimeInt() {
        return System.currentTimeMillis();
    }

    public static SharedPreferences.Editor getSharedPreferencesEditor(Context context) {
        return GuavaUtil.checkNotNull(getSharedPreferences(context).edit());
    }

    public static SharedPreferences getSharedPreferences(Context context) {
        return context.getSharedPreferences(PREF_NAME, 0);
    }

    public static boolean isIndexDataInit(Context context) {
        if (getSharedPreferences(context).getBoolean(spIsDataInit, false)) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean indexDataInited(Context context) {
        if (isIndexDataInit(context)) {
            return true;
        } else {
            if (getSharedPreferencesEditor(context).putBoolean(spIsDataInit, true).commit()) {
                return true;
            } else {
                return false;
            }
        }
    }

    public static boolean isT9Shown() {
        return isT9Shown;
    }

    public static boolean isT9LastShown(Context context) {
        if (getSharedPreferences(context).getBoolean(spIsT9LastShown, false)) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean setLastShownKeyBoard(Context context, boolean isT9) {
        isT9Shown = isT9;
        if (getSharedPreferencesEditor(context).putBoolean(spIsT9LastShown, isT9).commit()) {
            return true;
        } else {
            return false;
        }
    }

    public static Drawable byteToDrawable(Context context, byte[] icon) {
        Bitmap bitmap;
        if (icon != null) {
            bitmap = BitmapFactory.decodeByteArray(icon, 0, icon.length);
            Drawable drawable = new BitmapDrawable(bitmap);
            return drawable;
        }
        return null;
    }

    public static Drawable bitmapToDrawable(Context context, Bitmap bitmap) {
        BitmapDrawable bitmapDrawable = new BitmapDrawable(context.getResources(), bitmap);
        return bitmapDrawable;
    }

}
