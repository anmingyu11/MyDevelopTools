package com.smartisanos.quicksearchbox.util;

import android.content.Context;
import android.content.pm.PackageManager;
import android.support.v4.content.ContextCompat;

/**
 * Created by anmingyu on 16-10-10.
 */

public class PermissionChecker {
    private final Context mContext;
    private static PermissionChecker sPermissionChecker;

    public static PermissionChecker getInstance(Context context) {
        if (sPermissionChecker == null) {
            sPermissionChecker = new PermissionChecker(context);
        }
        return sPermissionChecker;
    }

    private PermissionChecker(Context context) {
        this.mContext = context;
    }

    /**
     * 权限检查
     * @param permissions
     * @return
     */
    public boolean lacksPermissions(String... permissions) {
        for (String permission : permissions) {
            if (lacksPermission(permission)) {
                return true;
            }
        }
        return false;
    }

    private boolean lacksPermission(String permission) {
        return ContextCompat.checkSelfPermission(mContext, permission) == PackageManager.PERMISSION_DENIED;
    }

}
