package com.smartisanos.quicksearchbox.util;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;

import com.smartisanos.home.R;

import java.util.HashMap;

/**
 * Created by anmingyu on 16-9-1.
 * <br>生成网页中搜索intent
 * <br>设定默认引擎
 */
public class EngineUtil {
    private static Context mContext;
    private static final String PREF_CURRENTENGINE = "current_engine";
    /**
     * 百度
     */
    public static final int ENGINE_BAIDU = 1101;
    /**
     * 谷歌
     */
    public static final int ENGINE_GOOGLE = 1102;
    /**
     * 必应
     */
    public static final int ENGINE_BING = 1103;
    /**
     * 神马
     */
    public static final int ENGINE_SM = 1104;
    /**
     * Wrong Engine Num
     */
    public static final int ENGINE_ERROR = -123321;

    //default and current
    private static final int ENGINE_DEFAULT = ENGINE_SM;
    private static int ENGINE_CURRENT = ENGINE_SM;

    //Urls
    private static final String BAIDU_URL_FORSEARCH = "http://www.baidu.com/s?word=";
    private static final String GOOGLE_URL_FORSEARCH = "http://www.google.com/#q=";
    private static final String BING_URL_FORSEARCH = "http://cn.bing.com/search?q=";
    private static final String SM_URL_FORSEARCH = "http://m.sm.cn/s?q=";

    private static HashMap<Integer, String> engineUrlMap = null;

    private static void initEnineUrlMap() {
        if (engineUrlMap == null) {
            engineUrlMap = new HashMap<Integer, String>();
        }
        engineUrlMap.put(ENGINE_BAIDU, BAIDU_URL_FORSEARCH);
        engineUrlMap.put(ENGINE_GOOGLE, GOOGLE_URL_FORSEARCH);
        engineUrlMap.put(ENGINE_BING, BING_URL_FORSEARCH);
        engineUrlMap.put(ENGINE_SM, SM_URL_FORSEARCH);
    }

    public static void initEngineSetting(Context context){
        try {
            //EngineInit
            if (EngineUtil.getCurrentEngine(context) == EngineUtil.ENGINE_ERROR)
                EngineUtil.setSearchEngineToDefault(context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 目前有四种引擎可供选择,默认为SM
     *
     * @param engine {@link EngineUtil#ENGINE_BAIDU} ,
     *               {@link EngineUtil#ENGINE_GOOGLE} ,
     *               {@link EngineUtil#ENGINE_BING} ,
     *               {@link EngineUtil#ENGINE_SM} ,
     * @throws Exception
     */
    public static boolean setSearchEngine(Context context, int engine) throws Exception {
        if (!(engine > 1100 && engine < 1105)) {
            Exception e = ThrowExceptionUtil.makeExceptionCustom("illegal engine number");
            throw e;
        }
        //repeat this for three time
        for (int i = 0; i < 3; i++) {
            SharedPreferences.Editor editor = Util.getSharedPreferencesEditor(context);
            editor.putInt(PREF_CURRENTENGINE, engine);
            if (editor.commit()) {
                ENGINE_CURRENT = engine;
                return true;
            } else {
                ENGINE_CURRENT = engine;
            }
        }
        return false;
    }

    /**
     * The default engine is SM
     */
    public static boolean setSearchEngineToDefault(Context context) {
        try {
            if (setSearchEngine(context, ENGINE_DEFAULT)) {
                LogUtil.info("set searchDefaultEngine successful");
                return true;
            } else {
                LogUtil.error("set searchDefaultEngine failed");
                throw ThrowExceptionUtil.makeExceptionCustom("preference commit failed");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * @return {@link EngineUtil#ENGINE_BAIDU} OR
     * {@link EngineUtil#ENGINE_GOOGLE} OR
     * {@link EngineUtil#ENGINE_BING} OR
     * {@link EngineUtil#ENGINE_SM} .
     * <br>if not set engine yet the {@link EngineUtil#ENGINE_SM} is the default search engine
     */
    public static int getCurrentEngine(Context context) {
        ENGINE_CURRENT = Util.getSharedPreferences(context).getInt(PREF_CURRENTENGINE, ENGINE_ERROR);
        LogUtil.info("current engine = " + ENGINE_CURRENT);
        return ENGINE_CURRENT;
    }

    public static String getCurrentEngineText(Context context) {
        int engineIndex = getCurrentEngine(context);
        if (engineIndex == ENGINE_ERROR | engineIndex == ENGINE_SM) {
            ENGINE_CURRENT = ENGINE_SM;
            return context.getResources().getString(R.string.engine_title_sm);
        } else if (engineIndex == ENGINE_BAIDU) {
            ENGINE_CURRENT = ENGINE_BAIDU;
            return context.getResources().getString(R.string.engine_title_baidu);
        } else if (engineIndex == ENGINE_BING) {
            ENGINE_CURRENT = ENGINE_BING;
            return context.getResources().getString(R.string.engine_title_bing);
        } else if (engineIndex == ENGINE_GOOGLE) {
            ENGINE_CURRENT = ENGINE_GOOGLE;
            return context.getResources().getString(R.string.engine_title_google);
        } else {
            throw new RuntimeException("无法获得搜索引擎");
        }
    }

    public static int getCurrentEngineTrackType(Context context) {
        int engineIndex = getCurrentEngine(context);
        if (engineIndex == ENGINE_ERROR | engineIndex == ENGINE_SM) {
            return 0;
        } else if (engineIndex == ENGINE_BAIDU) {
            return 3;
        } else if (engineIndex == ENGINE_BING) {
            return 1;
        } else if (engineIndex == ENGINE_GOOGLE) {
            return 2;
        } else {
            return -1;
        }
    }

    private static String makeSearchUrl(String keyWord) throws Exception {
        if (!(ENGINE_CURRENT > 1100 && ENGINE_CURRENT < 1105)) {
            Exception e = ThrowExceptionUtil.makeExceptionCustom("illegal engine number");
            throw e;
        }
        if (engineUrlMap == null) {
            initEnineUrlMap();
        }
        return engineUrlMap.get(ENGINE_CURRENT) + keyWord;
    }

    /**
     * make一个Intent 根据当前设定的搜索引擎
     *
     * @param keyWord
     * @return
     * @throws Exception
     */
    public static Intent makeSearchIntent(String keyWord) throws Exception {
        Intent intentSearchOnline = new Intent();
        String url = null;
        try {
            url = makeSearchUrl(keyWord);
            LogUtil.info("SearchUrl is " + url);
            if (url == null) {
                Exception e = ThrowExceptionUtil.makeExceptionCustom("make Search url Failed");
                throw e;
            }
            intentSearchOnline.setAction(Intent.ACTION_VIEW);
            intentSearchOnline.setData(Uri.parse(url));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return intentSearchOnline;
    }

    public static boolean changeEngineToBaidu() {
        return changeEngineTo(EngineUtil.ENGINE_BAIDU);
    }

    public static boolean changeEngineToGoogle() {
        return changeEngineTo(EngineUtil.ENGINE_GOOGLE);
    }

    public static boolean changeEngineToBing() {
        return changeEngineTo(EngineUtil.ENGINE_BING);
    }

    public static boolean changeEngineToSM() {
        return changeEngineTo(EngineUtil.ENGINE_SM);
    }

    private static boolean changeEngineTo(int engine) {
        try {
            if (engine == EngineUtil.getCurrentEngine(mContext)) {
                return true;
            } else {
                return EngineUtil.setSearchEngine(mContext, engine);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
