package com.smartisanos.quicksearchbox.util;

import com.smartisanos.quicksearchbox.pinyinsearch.model.PinyinBaseUnit;
import com.smartisanos.quicksearchbox.pinyinsearch.model.PinyinSearchUnit;
import com.smartisanos.quicksearchbox.pinyinsearch.model.PinyinUnit;
import com.smartisanos.quicksearchbox.pinyinsearch.util.PinyinUtil;

import java.util.List;

/**
 * Created by anmingyu on 16-9-22.
 */

public class IndexUtil {

    //splitToken
    private static final int tokens_divide = 0;
    private static final int tokens_pinyinandt9 = 1;
    private static final int tokens_nonpinyin = 2;
    private static final String[] mTokens = PinyinUtil.getTokens();

    /**
     * 将从数据库读取的qwetyIndex t9Index
     * 转换成PinyinSearchUnit
     *
     * @return
     */
    public static PinyinSearchUnit unParsePinyinUnit(String displayName, String[] index) {
        PinyinSearchUnit pinyinSearchUnit = new PinyinSearchUnit(displayName);
        /*
         *index lists
         */
        String[] originIndex = index[0].split(mTokens[tokens_divide]);
        String[] qwertyIndex = index[1].split(mTokens[tokens_divide]);
        String[] t9Index = index[2].split(mTokens[tokens_divide]);
        //pinyinUnits
        List<PinyinUnit> pinyinUnitList = pinyinSearchUnit.getPinyinUnits();
        int startPosition = -1;
        for (int i = 1; i < originIndex.length; i++) {
            /*
             * unparse indexes
             */
            PinyinUnit pinyinUnit = new PinyinUnit();
            if (originIndex[i].startsWith(mTokens[tokens_pinyinandt9])) {
                //拼音部分
                pinyinUnit.setPinyin(true);
                String[] originPinyins = originIndex[i].split(mTokens[tokens_pinyinandt9]);
                String[] qwertypinyins = qwertyIndex[i].split(mTokens[tokens_pinyinandt9]);
                String[] t9pinyins = t9Index[i].split(mTokens[tokens_pinyinandt9]);
                //set start position
                startPosition++;
                pinyinUnit.setStartPosition(startPosition);
                //init PinyinBaseUnit List
                for (int j = 1; j < originPinyins.length; j++) {
                    //Log.d("main", "originPinyins : " + originPinyins[j] + " qwertypinyins : " + qwertypinyins[j] + " t9pinyins : " + t9pinyins[j]);
                    pinyinUnit.getPinyinBaseUnitIndex().add(new PinyinBaseUnit(originPinyins[j], qwertypinyins[j], t9pinyins[j]));
                }
            } else if (originIndex[i].startsWith(mTokens[tokens_nonpinyin])) {
                //不是拼音的部分
                pinyinUnit.setPinyin(false);
                String originNonpinyins = originIndex[i].substring(1);
                String qwertynonpinyins = qwertyIndex[i].substring(1);
                String t9nonpinyins = t9Index[i].substring(1);
                //set start position
                startPosition++;
                pinyinUnit.setStartPosition(startPosition);
                startPosition += originNonpinyins.length() - 1;
                //init NonPinyinBaseUnit List
                //Log.d("main", "originPinyins : " + originNonpinyins + " qwertypinyins : " + qwertynonpinyins + " t9pinyins : " + t9nonpinyins);
                pinyinUnit.getPinyinBaseUnitIndex().add(new PinyinBaseUnit(originNonpinyins, qwertynonpinyins, t9nonpinyins));
            }
            pinyinUnitList.add(pinyinUnit);
        }
        pinyinSearchUnit.setPinyinUnits(pinyinUnitList);
        return pinyinSearchUnit;
    }

    /**
     * 创建分隔后的search index 包括origin qwerty t9三种索引类型
     *
     * @param pinyinSearchUnit
     * @return
     */
    public static String[] parsePinYinUnit(PinyinSearchUnit pinyinSearchUnit) {
        PinyinUtil.parse(pinyinSearchUnit);
        String[] qwertyAndT9AndOrigin = {mTokens[tokens_divide], mTokens[tokens_divide], mTokens[tokens_divide]};
        for (PinyinUnit pinyinUnit : pinyinSearchUnit.getPinyinUnits()) {
            for (PinyinBaseUnit pinyinBaseUnit : pinyinUnit.getPinyinBaseUnitIndex()) {
                qwertyAndT9AndOrigin[0] += pinyinBaseUnit.getPinyin();
                qwertyAndT9AndOrigin[1] += pinyinBaseUnit.getNumber();
                qwertyAndT9AndOrigin[2] += pinyinBaseUnit.getOriginalString();
            }
            qwertyAndT9AndOrigin[0] += mTokens[tokens_divide];
            qwertyAndT9AndOrigin[1] += mTokens[tokens_divide];
            qwertyAndT9AndOrigin[2] += mTokens[tokens_divide];
        }
        return qwertyAndT9AndOrigin;
    }
}
