package com.smartisanos.quicksearchbox.util;

/**
 * Created by anmingyu on 16-9-1.
 */
public class ThrowExceptionUtil {
    public static Exception makeExceptionCustom(String message) {
        return new Exception(message);
    }

    /**
     * 打印函数调用栈
     */
    public static void printStack() {
        Exception e = new Exception();
        e.printStackTrace();
    }
}
