package com.smartisanos.quicksearchbox.util;

import android.util.Log;

/**
 * Created by anmingyu on 16-8-30.
 * 只能打出本项目中的log,无法在系统接口中打log
 */
public class LogUtil {
    //Enable Log or Not
    private static boolean ENABLE_DEBUG = false;

    //app tag
    //private static String TAG = "SmartisanQuickSearchBox";

    //log levels
    private static int LOG_LEVEL_DISABLE = -1;
    public static int LOG_LEVEL_VERBOSE = 0;
    public static int LOG_LEVEL_DEBUG = 1;
    public static int LOG_LEVEL_INFO = 2;
    public static int LOG_LEVEL_WARNING = 3;
    public static int LOG_LEVEL_ERROR = 4;

    //fist init loglevel
    private static int LOG_LEVEL = LOG_LEVEL_VERBOSE;
    //mypacagename
    //private static String PACKAGE_NAME = "com.smartisanos.release.quicksearchbox";

    /**
     * 将Log_Level设定为 level参数指定的等级
     *
     * @param level {@link LogUtil#LOG_LEVEL_VERBOSE} ,
     *              {@link LogUtil#LOG_LEVEL_DEBUG} ,
     *              {@link LogUtil#LOG_LEVEL_INFO} ,
     *              {@link LogUtil#LOG_LEVEL_WARNING} ,
     *              {@link LogUtil#LOG_LEVEL_ERROR}
     */
    public static void setLogLevel(int level) {
        LOG_LEVEL = level;
    }

    public static void setLogLevelDisable() {
        LOG_LEVEL = LOG_LEVEL_DISABLE;
    }

    /**
     * 应用将在logcat中输出,LOG_VEVEL默认为verbose
     */
    public static void enableLog() {
        ENABLE_DEBUG = true;
        setLogLevel(LOG_LEVEL_VERBOSE);
    }

    /**
     * 应用将在logcat中输出,LOG_VEVEL设定为 level参数指定的等级
     *
     * @param level {@link LogUtil#LOG_LEVEL_VERBOSE} ,
     *              {@link LogUtil#LOG_LEVEL_DEBUG} ,
     *              {@link LogUtil#LOG_LEVEL_INFO} ,
     *              {@link LogUtil#LOG_LEVEL_WARNING} ,
     *              {@link LogUtil#LOG_LEVEL_ERROR}
     */
    public static void enableLog(int level) {
        ENABLE_DEBUG = true;
        setLogLevel(level);
    }

    public static void disableLog() {
        ENABLE_DEBUG = false;
    }

    /**
     * 获取调用者的类名和方法体,可能
     *
     * @return
     */
    public static String getCaller() {
        StackTraceElement stack[] = (new Throwable()).getStackTrace();
        String className = null;
        StackTraceElement element = null;
        for (int i = 0; i < stack.length; i++) {
            element = stack[i];
            className = element.getClassName();
            if (!className.contains("com.smartisanos")) {
                continue;
            }
            if (className.contains("LogUtil") || className.contains("$")) {
                continue;
            }
            int SimpleClassNamePoing = className.lastIndexOf(".");
            return className.substring(SimpleClassNamePoing + 1, className.length()) + "." + element.getMethodName() + ":";
        }
        return null;
    }

    public static void error(String info) {
        if (!ENABLE_DEBUG || LOG_LEVEL == LOG_LEVEL_DISABLE) {
            return;
        }

        Log.e(getCaller(), info);
    }

    public static void warn(String info) {
        if (!ENABLE_DEBUG || LOG_LEVEL == LOG_LEVEL_DISABLE) {
            return;
        }

        Log.w(getCaller(), info);
    }

    public static void info(String info) {
        if (!ENABLE_DEBUG || LOG_LEVEL == LOG_LEVEL_DISABLE) {
            return;
        }

        Log.i(getCaller(), info);
    }

    public static void debug(String info) {
        if (!ENABLE_DEBUG || LOG_LEVEL == LOG_LEVEL_DISABLE) {
            return;
        }

        Log.d(getCaller(), info);
    }

    public static void verbose(String MethodTag, String info) {
        if (!ENABLE_DEBUG || LOG_LEVEL == LOG_LEVEL_DISABLE) {
            return;
        }

        Log.v(getCaller(), info);
    }
}
