package com.smartisanos.quicksearchbox;

import android.support.v4.app.FragmentActivity;

/**
 * Created by anmingyu on 16-8-30.
 */
public class BaseActivity extends FragmentActivity {
}
