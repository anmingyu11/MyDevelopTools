package xyz.skybox.statistic.helper;

import android.content.Context;
import com.crashlytics.android.Crashlytics;
import com.crashlytics.android.answers.Answers;
import com.crashlytics.android.answers.CustomEvent;
import io.fabric.sdk.android.Fabric;

public class FabricHelper {
    private static boolean isEnableFabric = false;

    public static void enableFabric(boolean enable) {
        isEnableFabric = enable;
    }

    private static boolean isNotEnableFabric() {
        return !isEnableFabric;
    }

    public static void init(Context context) {
        if (isNotEnableFabric()) return;
        Fabric.with(context, new Crashlytics(), new Answers());
    }

    public static void logException(Exception e) {
        if (isNotEnableFabric()) return;
        Crashlytics.getInstance().logException(e);
    }

    public static void logException(String exception) {
        if (isNotEnableFabric()) return;
        Crashlytics.getInstance().log(exception);
    }

    public static void logCustomEvent(String ev) {
        if (isNotEnableFabric()) return;
        Answers.getInstance().logCustom(new CustomEvent("ev"));
    }

    public static void logCustomEvent(CustomEvent customEvent) {
        if (isNotEnableFabric()) return;
        Answers.getInstance().logCustom(customEvent);
    }

}
