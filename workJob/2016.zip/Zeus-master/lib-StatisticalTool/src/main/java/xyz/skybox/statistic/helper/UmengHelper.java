package xyz.skybox.statistic.helper;

public class UmengHelper {
   /*
    private static boolean isEnableUmeng = false;

    public static void enableUmeng(boolean enable) {
        isEnableUmeng = enable;
    }

    private static boolean isNotEnableUmeng() {
        return !isEnableUmeng;
    }

    public static void setDebugMode(boolean debugOpen) {
        if (isNotEnableUmeng()) return;
        MobclickAgent.setDebugMode(debugOpen);
    }

    public static void enableEncrypt(boolean enable) {
        if (isNotEnableUmeng()) return;
        MobclickAgent.enableEncrypt(enable);
    }

    public static void pause(Context context) {
        if (isNotEnableUmeng()) return;
        MobclickAgent.onPause(context);
    }

    public static void resume(Context context) {
        if (isNotEnableUmeng()) return;
        MobclickAgent.onResume(context);
    }
*/
}
