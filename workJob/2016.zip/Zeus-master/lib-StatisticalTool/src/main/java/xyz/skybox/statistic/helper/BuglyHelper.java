package xyz.skybox.statistic.helper;

public class BuglyHelper {
   /* private static boolean isEnableBugly = false;

    public static void enableBugly(boolean enable) {
        isEnableBugly = enable;
    }

    private static boolean isNotEnableBugly() {
        return !isEnableBugly;
    }

    public static void init(Context context) {
        if (isNotEnableBugly()) return;
        CrashReport.initCrashReport(context);
    }
*/
}
