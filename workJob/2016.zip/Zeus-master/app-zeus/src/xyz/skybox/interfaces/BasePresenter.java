//Todo copyright
package xyz.skybox.interfaces;

public interface BasePresenter {

    void start();

}
