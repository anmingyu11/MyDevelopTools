// TODO: Copyright
package xyz.skybox.interfaces;

public interface BaseView<T> {

    void setPresenter(T presenter);

}
