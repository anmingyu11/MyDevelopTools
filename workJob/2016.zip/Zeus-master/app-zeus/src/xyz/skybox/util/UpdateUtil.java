package xyz.skybox.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;

import java.io.File;

import xyz.skybox.R;
import xyz.skybox.statistic.helper.FabricHelper;

public class UpdateUtil {

    public static void installApk(Context context, File file) {
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setAction(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(file),
                "application/vnd.android.package-archive");
        context.startActivity(intent);
    }

    public static String packageName(Context context) {
        return context.getPackageName();
    }

    public static void removeDownloadedApk(){

    }

    public static int versionCode(Context context) {
        try {
            PackageInfo pi = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return pi.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            FabricHelper.logException(e);
            e.printStackTrace();
            return -1;
        }
    }

    public static String versionName(Context context) {
        try {
            PackageInfo pi = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return pi.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            FabricHelper.logException(e);
            e.printStackTrace();
            return context.getString(R.string.setting_version_unknown);
        }
    }

}
