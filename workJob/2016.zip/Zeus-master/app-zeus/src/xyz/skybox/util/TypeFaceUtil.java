package xyz.skybox.util;

import android.graphics.Typeface;

import xyz.skybox.SkyboxApplication;

public class TypeFaceUtil {
    public static Typeface mTypeFaceNormal;
    public static Typeface mTypeFaceFat;
    public static Typeface mTypeFaceThin;
    public static Typeface mTypeFaceSourceSansPro_Light;

    public static void initTypeFace() {
        mTypeFaceFat = Typeface.createFromAsset(SkyboxApplication.getAppContext().getAssets(), "fonts/calibrib.ttf");
        mTypeFaceNormal = Typeface.createFromAsset(SkyboxApplication.getAppContext().getAssets(), "fonts/calibri.ttf");
        mTypeFaceThin = Typeface.createFromAsset(SkyboxApplication.getAppContext().getAssets(), "fonts/calibril.ttf");
        mTypeFaceSourceSansPro_Light = Typeface.createFromAsset(SkyboxApplication.getAppContext().getAssets(), "fonts/SourceSansProLight.otf");
    }

}
