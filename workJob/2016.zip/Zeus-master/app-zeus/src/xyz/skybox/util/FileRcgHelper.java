package xyz.skybox.util;

import android.os.Environment;
import android.text.TextUtils;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

import xyz.skybox.SkyboxApplication;
import xyz.skybox.common.util.LogUtil;

import static xyz.skybox.util.Util.printExceptionLog;


public class FileRcgHelper {

    private static FileRcgHelper mInstance;

    private boolean hasSD = false;

    private static String LOG_FILE_PATH;
    private static String LOG_FILE_NAME = ".SKYBOX_log.txt";
    private static final String LOG_FILE_NAME_PREFIX = "SKYBOX_recognition_log_";

    private static String INVALID_FILE_PATH;
    private static final String INVALID_FILE_NAME = ".SKYBOX_recognition_invalid_files.txt";
    private static final String INVALID_FILE_COMMENTS =
            "# SKYBOX STUDIO \n" +
            "# These are invalid files. \n" +
            "# DO NOT delete this file or modify the contents of this file.";

    public static final String START_TAG = "-------------------------------";
    public static final String RECOGNIZE_PREFIX = "Recognize file: ";
    public static final String SUCCESS_TAG = "Successfully recognize file: ";

    public synchronized static FileRcgHelper getInstance() {
        if (mInstance == null)
            mInstance = new FileRcgHelper();
        return mInstance;
    }

    public FileRcgHelper() {

        mInstance = this;

        hasSD = Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);

        try {
            LOG_FILE_PATH = SkyboxApplication.getAppContext().getExternalFilesDir(null).getPath();

        } catch (Exception e) {
            LOG_FILE_PATH = Environment.getExternalStorageDirectory().getPath();
            LOG_FILE_PATH += "/SKYBOX";
        }

        INVALID_FILE_PATH = Environment.getExternalStorageDirectory().getPath();
        INVALID_FILE_PATH += "/SKYBOX";

        // Check weather create ".SKYBOX_invalid_files.txt" file.
        File invalidFile = new File(INVALID_FILE_PATH, INVALID_FILE_NAME);
        if (invalidFile == null || !invalidFile.exists()) {
            createInvalidFileOnSdcard();
            writeToFile(INVALID_FILE_PATH, INVALID_FILE_NAME, INVALID_FILE_COMMENTS);
        }

    }

    public boolean isLogFileExists() {
        return LOG_FILE_NAME.startsWith(LOG_FILE_NAME_PREFIX);
    }

    public File createLogFileOnSdcard() {
        Date currentTime = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US);
        String dateString = formatter.format(currentTime);
        LOG_FILE_NAME = LOG_FILE_NAME_PREFIX + dateString + ".txt";
        return createFile(LOG_FILE_PATH, LOG_FILE_NAME);
    }

    public File createInvalidFileOnSdcard() {
        return createFile(INVALID_FILE_PATH, INVALID_FILE_NAME);
    }

    public File createFile(String path, String fileName) {
        try {
            File dir = new File(path);
            if (dir == null || !dir.exists() || !dir.isDirectory()) {
                dir.mkdirs();
            }
            File file = new File(path, fileName);
            if (!file.exists()) {
                boolean result = file.createNewFile();
                LogUtil.e("create file, " + result + ": " + file.getAbsolutePath());
            }
            return file;

        } catch (Exception e) {
            LogUtil.e("readLine:" + e.getMessage());
            return null;
        }
    }

    public boolean deleteFile(String path, String fileName) {
        File file = new File(path, fileName);
        if (file == null || !file.exists() || file.isDirectory())
            return false;
        boolean result = file.delete();
        LogUtil.e("delete file, " + result + ": " + file.getAbsolutePath());
        return result;
    }

    public void deleteAllLogFiles() {
        File dir = new File(LOG_FILE_PATH);
        if (dir == null || !dir.exists() || !dir.isDirectory()) {
            return;
        }
        File files[] = dir.listFiles();
        for (File file : files) {
            if (file == null || !file.exists()) {
                return;
            }
//            LogUtil.e("check file, " + file.getName().startsWith(LOG_FILE_NAME_PREFIX) + ": " + file.getName());

            if (file.getName().startsWith(LOG_FILE_NAME_PREFIX)) {
                deleteFile(LOG_FILE_PATH, file.getName());
            }
        }
    }

    public void writeToLogFile(String text) {
        writeToFile(LOG_FILE_PATH, LOG_FILE_NAME, text);
    }

    public void writeToLogFileByUri(String locationUri) {

        ArrayList<String> content = readFromFile(LOG_FILE_PATH, LOG_FILE_NAME);

        if (content == null || content.size() <= 0) {
            LogUtil.e("log file no result");
            return;
        }

        for (String line : content) {
//            LogUtil.i("write line:" + line);
//            LogUtil.i("write line startsWith (SUCCESS_TAG):" + line.startsWith(SUCCESS_TAG));

            if (line.startsWith(SUCCESS_TAG)) {
//                LogUtil.i("Successfully: " + line);

            } else if (line.startsWith("/") && line.equals(locationUri)) {

                replaceToFile(LOG_FILE_PATH, LOG_FILE_NAME, line, SUCCESS_TAG + line);
            }
        }
    }


    public void replaceToFile(String path, String fileName, String oriText, String newText) {
        try {
            File file = new File(path, fileName);
            if (!file.exists()) {
                LogUtil.e("log file '" + file + "' not found");
                return;
            }
            if (!file.canWrite()) {
                LogUtil.e("log file '" + file + "' not write able");
                return;
            }

            String newContent = new String();
            String line;
            BufferedReader reader = new BufferedReader(new FileReader(file));
            while ((line = reader.readLine()) != null) {
                if (line.equals(oriText)) {
                    // Replace to new text
                    newContent += newText + "\n";
                } else {
                    newContent += line + "\n";
                }
            }
            reader.close();

            if (TextUtils.isEmpty(newContent)) {
                return;
            }

            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(newContent);
            writer.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * no overwrite
     *
     * @param text
     */
    public void writeToInvalidFile(String text) {

        // Check weather create ".SKYBOX_invalid_files.txt" file.
        File invalidFile = new File(INVALID_FILE_PATH, INVALID_FILE_NAME);
        if (invalidFile == null || !invalidFile.exists()) {
            createInvalidFileOnSdcard();
            writeToFile(INVALID_FILE_PATH, INVALID_FILE_NAME, INVALID_FILE_COMMENTS);
        }

        writeToFile(INVALID_FILE_PATH, INVALID_FILE_NAME, text);
    }

    public void writeToFile(String path, String fileName, String text) {
        File file = new File(path, fileName);
        try {
            FileWriter fw = new FileWriter(file, true); //后面这个参数代表是不是要接上文件中原来的数据，不进行覆盖
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(text);
            bw.newLine();
            bw.close();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void checkAndReadLogFile() {
        File dir = new File(LOG_FILE_PATH);
        if (dir == null || !dir.exists() || !dir.isDirectory()) {
            return;
        }

        ArrayList<String> invalidFiles = readFromInvalidFile();

        File files[] = dir.listFiles();
        for (File file : files) {
            if (file == null || !file.exists()) {
                return;
            }
//            LogUtil.e("check file, " + file.getName().startsWith(LOG_FILE_NAME_PREFIX) + ": " + file.getName());

            if (file.getName().startsWith(LOG_FILE_NAME_PREFIX)) {

                ArrayList<String> content = readFromFile(file);
                if (content == null || content.size() <= 0) {
                    LogUtil.e("log file no result");
                    return;
                }

//                for (String line : content) {
//                    LogUtil.e("line:" + line);
//                }

                for (String line : content) {
//                    LogUtil.i("check line:" + line);
//                    LogUtil.e("check line startsWith (SUCCESS_TAG):" + line.startsWith(SUCCESS_TAG));

                    if (line.startsWith(SUCCESS_TAG)) {
//                        LogUtil.i("Successfully: " + line);

                    } else if (line.startsWith("/")) {
                        // There is invalid file in last time scan.
                        String invalidPath = line;

                        if (invalidFiles != null && invalidFiles.size() > 0
                                && invalidFiles.contains(invalidPath)) {
                            continue;
                        }

                        // Send log to server.
                        String name = "Id:"+AndroidDevices.userId.substring(15);
                        String reason = "RCG X:"+invalidPath;
                        String stackTraceString = LogUtil.getStackTrace();
                        printExceptionLog(name, reason, stackTraceString);

                        // Send umeng
                        HashMap<String, String> map = new HashMap<String,String>();
                        map.put("userId", AndroidDevices.userId);
                        map.put("path", AndroidDevices.userId+invalidPath);
                        //MobclickAgent.onEvent(SkyboxApplication.getAppContext(), "rcg_file_e", map);

                        // Save to invalid files
                        writeToInvalidFile(invalidPath);
                    }
                }
            }
        }
    }

    public ArrayList<String> readFromInvalidFile() {
        ArrayList<String> content = readFromFile(INVALID_FILE_PATH, INVALID_FILE_NAME);
        if (content == null || content.size() <= 0) {
            return null;
        }
        ArrayList<String> result = new ArrayList<String>();
        for (String line : content) {
            if (line.startsWith("/")) {
                result.add(line);
            }
        }
        return result;
    }

    public ArrayList<String> readFromFile(String path, String fileName) {
        try {
            File root = Environment.getExternalStorageDirectory();
            if (root == null) {
                LogUtil.e("external storage dir not found");
                return null;
            }
            File file = new File(path, fileName);
            if (!file.exists()) {
                LogUtil.e("log file '" + file + "' not found");
                return null;
            }
            if (!file.canRead()) {
                LogUtil.e("log file '" + file + "' not readable");
                return null;
            }
            return readFromFile(file);

        } catch (Exception e) {
            LogUtil.e("read file exception:" + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    public ArrayList<String> readFromFile(File file) {
        try {
            ArrayList<String> result = new ArrayList<String>();

            if (file == null || !file.exists()) {
                LogUtil.e("logfile '" + file + "' not found");
                return null;
            }
            if (!file.canRead()) {
                LogUtil.e("logfile '" + file + "' not readable");
                return null;
            }

            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);

            String line = br.readLine();
            while (line != null) {
                result.add(line);
                line = br.readLine();
            }
            fr.close();
            br.close();
            return result;

        } catch (Exception e) {
            LogUtil.e("read file exception:" + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

}