package xyz.skybox.util;


public class LogEvent {

    String name;
    String reason;
    String stackTraceString;

    public LogEvent(String name, String reason, String stackTraceString) {
        this.name = name;
        this.reason = reason;
        this.stackTraceString = stackTraceString;
    }

}
