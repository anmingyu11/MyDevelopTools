// TODO copyright
package xyz.skybox.util;


import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Environment;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import xyz.skybox.common.util.LogUtil;
import xyz.skybox.media.MediaDatabase;
import xyz.skybox.repository.airscreen.AirScreenMediaWrapper;
import xyz.skybox.statistic.helper.FabricHelper;

public class LaunchHelper {

    private static final String VR_APK_NAME = "SKYBOXR.apk";
    private static final String VR_PACKAGE_NAME = AndroidDevices.VR_PACKAGE_NAME;

    private Activity mActivity;

    public LaunchHelper(Activity mActivity) {
        this.mActivity = mActivity;
    }

    public void launchVR(Uri uri, String tab) {
        if (isVRAppInstalled()) {
            launchActivity(uri, tab);
        } else {
            // Need install vr app.
            loadAndroidApk();
            launchInstallApk();
        }
    }

    private void launchActivity(Uri uri, String tab) {
        try {
            MediaDatabase mediaDatabase = MediaDatabase.getInstance();
            mediaDatabase.removeExternalPlay();
            if (uri != null) {
                mediaDatabase.setExternalPlay(uri, tab);
            }

            Intent intent = new Intent();
            intent.setComponent(new ComponentName(AndroidDevices.VR_PACKAGE_NAME, AndroidDevices.VR_CLASS_NAME));
            mActivity.startActivity(intent);

        } catch (ActivityNotFoundException e) {
            String err ="ActivityNotFoundException: " + e.getMessage();
            FabricHelper.logException(err);
            LogUtil.e(err);
        }
    }

    public void launchVrFromAir(AirScreenMediaWrapper amw, String tab) {
        if (isVRAppInstalled()) {
            launchActivity(amw, tab);
        } else {
            // Need install vr app.
            loadAndroidApk();
            launchInstallApk();
        }
    }

    private void launchActivity(AirScreenMediaWrapper amw, String tab) {
        try {
            MediaDatabase mediaDatabase = MediaDatabase.getInstance();
            mediaDatabase.removeExternalPlay();
            mediaDatabase.setExternalPlayRemoteVideo(amw);
            mediaDatabase.addRemoteHistoryItem(amw);

            Intent intent = new Intent();
            intent.setComponent(new ComponentName(AndroidDevices.VR_PACKAGE_NAME, AndroidDevices.VR_CLASS_NAME));
            mActivity.startActivity(intent);

        } catch (ActivityNotFoundException e) {
            FabricHelper.logException(e);
            LogUtil.e("ActivityNotFoundException: " + e.getMessage());
        }
    }

    private boolean isVRAppInstalled() {
        return isAppInstalled(mActivity, VR_PACKAGE_NAME);
    }


    private boolean isAppInstalled(Context context, String packageName) {
        PackageInfo packageInfo;
        try {
            packageInfo = context.getPackageManager().getPackageInfo(packageName, 0);
        } catch (PackageManager.NameNotFoundException e) {
            FabricHelper.logException(e);
            packageInfo = null;
        }
        if (packageInfo == null) {
            return false;
        } else {
            return true;
        }
    }

    private boolean loadAndroidApk() {
        return copyApkFromAssets(mActivity, VR_APK_NAME,
                Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + VR_APK_NAME);
    }

    private boolean copyApkFromAssets(Context context, String fileName, String path) {

        boolean copyIsFinish = false;
        try {

            InputStream is = context.getAssets().open(fileName);
            File file = new File(path);
            file.createNewFile();
            FileOutputStream fos = new FileOutputStream(file);
            byte[] temp = new byte[1024];
            int i = 0;
            while ((i = is.read(temp)) > 0) {
                fos.write(temp, 0, i);
            }
            fos.close();
            is.close();
            copyIsFinish = true;
        } catch (IOException e) {
            FabricHelper.logException(e);
            e.printStackTrace();
        }
        return copyIsFinish;
    }

    private void launchInstallApk() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setDataAndType(Uri.parse("file://" + Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + VR_APK_NAME),
                "application/vnd.android.package-archive");
        mActivity.startActivity(intent);
    }

}
