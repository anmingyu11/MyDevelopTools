package xyz.skybox.util;

import android.os.Environment;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

import xyz.skybox.SkyboxApplication;
import xyz.skybox.common.util.LogUtil;

import static xyz.skybox.util.Util.printExceptionLog;


public class FileHelper {

    private static FileHelper mInstance;

    private boolean hasSD = false;

    private static String LOG_FILE_PATH;
    private static String LOG_FILE_NAME = ".SKYBOX_log.txt";
    private static final String LOG_FILE_NAME_PREFIX = "SKYBOX_log_";

    private static String INVALID_FILE_PATH;
    private static final String INVALID_FILE_NAME = ".SKYBOX_invalid_files.txt";
    private static final String INVALID_FILE_COMMENTS =
            "# SKYBOX STUDIO \n" +
            "# These are invalid files. \n" +
            "# DO NOT delete this file or modify the contents of this file.";

    public static final String START_TAG = "-------------------------------";
    public static final String READ_PREFIX = "Read file: ";
    public static final String SUCCESS_TAG = "Successfully read this file!";

    public synchronized static FileHelper getInstance() {
        if (mInstance == null)
            mInstance = new FileHelper();
        return mInstance;
    }

    public FileHelper() {

        mInstance = this;

        hasSD = Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);

        try {
            LOG_FILE_PATH = SkyboxApplication.getAppContext().getExternalFilesDir(null).getPath();

        } catch (Exception e) {
            LOG_FILE_PATH = Environment.getExternalStorageDirectory().getPath();
            LOG_FILE_PATH += "/SKYBOX";
        }

        INVALID_FILE_PATH = Environment.getExternalStorageDirectory().getPath();
        INVALID_FILE_PATH += "/SKYBOX";

        // Check weather create ".SKYBOX_invalid_files.txt" file.
        File invalidFile = new File(INVALID_FILE_PATH, INVALID_FILE_NAME);
        if (invalidFile == null || !invalidFile.exists()) {
            createInvalidFileOnSdcard();
            writeToFile(INVALID_FILE_PATH, INVALID_FILE_NAME, INVALID_FILE_COMMENTS);
        }

    }

    public File createLogFileOnSdcard() {
        Date currentTime = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US);
        String dateString = formatter.format(currentTime);
        LOG_FILE_NAME = LOG_FILE_NAME_PREFIX + dateString + ".txt";
        return createFile(LOG_FILE_PATH, LOG_FILE_NAME);
    }

    public File createInvalidFileOnSdcard() {
        return createFile(INVALID_FILE_PATH, INVALID_FILE_NAME);
    }

    public File createFile(String path, String fileName) {
        try {
            File dir = new File(path);
            if (dir == null || !dir.exists() || !dir.isDirectory()) {
                dir.mkdirs();
            }
            File file = new File(path, fileName);
            if (!file.exists()) {
                boolean result = file.createNewFile();
                LogUtil.e("create file, " + result + ": " + file.getAbsolutePath());
            }
            return file;

        } catch (Exception e) {
            LogUtil.e("readLine:" + e.getMessage());
            return null;
        }
    }

    public boolean deleteFile(String path, String fileName) {
        File file = new File(path, fileName);
        if (file == null || !file.exists() || file.isDirectory())
            return false;
        boolean result = file.delete();
        LogUtil.e("delete file, " + result + ": " + file.getAbsolutePath());
        return result;
    }

    public void deleteAllLogFiles() {
        File dir = new File(LOG_FILE_PATH);
        if (dir == null || !dir.exists() || !dir.isDirectory()) {
            return;
        }
        File files[] = dir.listFiles();
        for (File file : files) {
            if (file == null || !file.exists()) {
                return;
            }
//            LogUtil.e("check file, " + file.getName().startsWith(LOG_FILE_NAME_PREFIX) + ": " + file.getName());

            if (file.getName().startsWith(LOG_FILE_NAME_PREFIX)) {
                deleteFile(LOG_FILE_PATH, file.getName());
            }
        }
    }

    public void writeToLogFile(String text) {
        writeToFile(LOG_FILE_PATH, LOG_FILE_NAME, text);
    }

    /**
     * no overwrite
     *
     * @param text
     */
    public void writeToInvalidFile(String text) {

        // Check weather create ".SKYBOX_invalid_files.txt" file.
        File invalidFile = new File(INVALID_FILE_PATH, INVALID_FILE_NAME);
        if (invalidFile == null || !invalidFile.exists()) {
            createInvalidFileOnSdcard();
            writeToFile(INVALID_FILE_PATH, INVALID_FILE_NAME, INVALID_FILE_COMMENTS);
        }

        writeToFile(INVALID_FILE_PATH, INVALID_FILE_NAME, text);
    }

    public void writeToFile(String path, String fileName, String text) {
        File file = new File(path, fileName);
        try {
            FileWriter fw = new FileWriter(file, true); //后面这个参数代表是不是要接上文件中原来的数据，不进行覆盖
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(text);
            bw.newLine();
            bw.close();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void checkAndReadLogFile() {
        File dir = new File(LOG_FILE_PATH);
        if (dir == null || !dir.exists() || !dir.isDirectory()) {
            return;
        }

        ArrayList<String> invalidFiles = readFromInvalidFile();

        File files[] = dir.listFiles();
        for (File file : files) {
            if (file == null || !file.exists()) {
                return;
            }
//            LogUtil.e("check file, " + file.getName().startsWith(LOG_FILE_NAME_PREFIX) + ": " + file.getName());

            if (file.getName().startsWith(LOG_FILE_NAME_PREFIX)) {

                ArrayList<String> content = readFromFile(file);
                if (content == null || content.size() <= 0) {
                    LogUtil.e("log file no result");
                    return;
                }

//                for (String line : content) {
//                    LogUtil.e("line:" + line);
//                }

                String lastLine = content.get(content.size() - 1);
                LogUtil.e("lastLine startsWith (READ_PREFIX):" + lastLine.startsWith(READ_PREFIX));

                if (SUCCESS_TAG.equals(lastLine)) {
//                    LogUtil.e("Successfully :" + lastLine);

                } else if (lastLine.startsWith(READ_PREFIX)) {
                    // There is invalid file in last time scan.
                    String invalidPath = lastLine.substring(READ_PREFIX.length());

                    if (invalidFiles != null && invalidFiles.size() > 0
                            && invalidFiles.contains(invalidPath)) {
                        continue;
                    }

                    // Send log to server.
                    String name = "Id:"+ AndroidDevices.userId.substring(15);
                    String reason = "X:"+invalidPath;
                    String stackTraceString = LogUtil.getStackTrace();
                    printExceptionLog(name, reason, stackTraceString);

                    // Send umeng
                    HashMap<String, String> map = new HashMap<String,String>();
                    map.put("userId", AndroidDevices.userId);
                    map.put("path", AndroidDevices.userId+invalidPath);
                    //MobclickAgent.onEvent(SkyboxApplication.getAppContext(), "scan_file_e", map);

                    // Save to invalid files
                    writeToInvalidFile(invalidPath);
                }
            }
        }
    }

    public ArrayList<String> readFromInvalidFile() {
        ArrayList<String> content = readFromFile(INVALID_FILE_PATH, INVALID_FILE_NAME);
        if (content == null || content.size() <= 0) {
            return null;
        }
        ArrayList<String> result = new ArrayList<String>();
        for (String line : content) {
            if (line.startsWith("/")) {
                result.add(line);
            }
        }
        return result;
    }

    public ArrayList<String> readFromFile(String path, String fileName) {
        try {
            File root = Environment.getExternalStorageDirectory();
            if (root == null) {
                LogUtil.e("external storage dir not found");
                return null;
            }
            File file = new File(path, fileName);
            if (!file.exists()) {
                LogUtil.e("log file '" + file + "' not found");
                return null;
            }
            if (!file.canRead()) {
                LogUtil.e("log file '" + file + "' not readable");
                return null;
            }
            return readFromFile(file);

        } catch (Exception e) {
            LogUtil.e("read file exception:" + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    public ArrayList<String> readFromFile(File file) {
        try {
            ArrayList<String> result = new ArrayList<String>();

            if (file == null || !file.exists()) {
                LogUtil.e("logfile '" + file + "' not found");
                return null;
            }
            if (!file.canRead()) {
                LogUtil.e("logfile '" + file + "' not readable");
                return null;
            }

            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);

            String line = br.readLine();
            while (line != null) {
                result.add(line);
                line = br.readLine();
            }
            fr.close();
            br.close();
            return result;

        } catch (Exception e) {
            LogUtil.e("read file exception:" + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

}