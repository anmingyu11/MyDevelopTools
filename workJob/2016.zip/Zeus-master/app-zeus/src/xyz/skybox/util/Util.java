/*****************************************************************************
 * UiTools.java
 *****************************************************************************
 * Copyright © 2011-2014 VLC authors and VideoLAN
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

package xyz.skybox.util;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.unity3d.player.UnityPlayer;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.List;
import java.util.Random;

import xyz.skybox.SkyboxApplication;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.statistic.helper.FabricHelper;

public class Util {
    public final static String TAG = "Util";

    public static String readAsset(String assetName, String defaultS) {
        InputStream is = null;
        BufferedReader r = null;
        try {
            is = SkyboxApplication.getAppResources().getAssets().open(assetName);
            r = new BufferedReader(new InputStreamReader(is, "UTF8"));
            StringBuilder sb = new StringBuilder();
            String line = r.readLine();
            if(line != null) {
                sb.append(line);
                line = r.readLine();
                while(line != null) {
                    sb.append('\n');
                    sb.append(line);
                    line = r.readLine();
                }
            }
            return sb.toString();
        } catch (IOException e) {
            FabricHelper.logException(e);
            return defaultS;
        } finally {
            close(is);
            close(r);
        }
    }

    public static boolean close(Closeable closeable) {
        if (closeable != null)
            try {
                closeable.close();
                return true;
            } catch (IOException e) {
                FabricHelper.logException(e);
            }
        return false;
    }

    public static boolean isListEmpty(@Nullable Collection collection) {
        return collection == null || collection.isEmpty();
    }

    public static int getRandomNumber(int start, int end) throws IllegalAccessException {
        if (end - start < 0) {
            throw new IllegalArgumentException(" end - start must > 0");
        }
        return new Random().nextInt((end - start) + 1) + start;
    }

    public static boolean isCallable(Intent intent) {
        List<ResolveInfo> list = SkyboxApplication.getAppContext().getPackageManager().queryIntentActivities(intent,
                PackageManager.MATCH_DEFAULT_ONLY);
        return list.size() > 0;
    }

    public static String formatTitle(String title) {
        String formatTitle = "";
        if (!TextUtils.isEmpty(title)) {
            formatTitle = title;
            if (formatTitle.contains(".mp4")) {
                formatTitle = formatTitle.replace(".mp4","");
            }
            if (formatTitle.contains(".mkv")) {
                formatTitle = formatTitle.replace(".mkv","");
            }
            if (formatTitle.contains(".avi")) {
                formatTitle = formatTitle.replace(".avi","");
            }
            formatTitle = formatTitle.replace("_"," ");
        }
        return formatTitle;
    }

    public static void printExceptionLog(String name, String reason, String stackTraceString) {

        LogEvent event = new LogEvent(name, reason, "stackTraceString");
        Gson gson = new Gson();
        String gsonMsg = gson.toJson(event);
        UnityPlayer.UnitySendMessage("CustomEventManager", "RecordCustomException", gsonMsg);

        String msg = name +": " +reason;
        LogUtil.e(msg);

        // Send umeng
        //MobclickAgent.reportError(SkyboxApplication.getAppContext(), msg);
    }

}
