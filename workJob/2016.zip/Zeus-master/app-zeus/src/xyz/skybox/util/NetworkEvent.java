package xyz.skybox.util;

public class NetworkEvent {

    String ipAddress;
    String netmask;
    String gateway;
    String serverAddress;
    String dns1;
    String dns2;
    String leaseDuration;
    String wifiIpAddress;
    String wifiMacAddress;

    public NetworkEvent(String ipAddress, String netmask,
                        String gateway, String serverAddress,
                        String dns1, String dns2, String leaseDuration,
                        String wifiIpAddress, String wifiMacAddress) {
        this.ipAddress = ipAddress;
        this.netmask = netmask;
        this.gateway = gateway;
        this.serverAddress = serverAddress;
        this.dns1 = dns1;
        this.dns2 = dns2;
        this.leaseDuration = leaseDuration;
        this.wifiIpAddress = wifiIpAddress;
        this.wifiMacAddress = wifiMacAddress;
    }

}
