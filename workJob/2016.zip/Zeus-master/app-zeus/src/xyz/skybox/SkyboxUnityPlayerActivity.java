package xyz.skybox;

import android.os.Bundle;
import android.view.View;

import com.unity3d.player.UnityPlayerActivity;

import xyz.skybox.common.util.LogUtil;

import static xyz.skybox.util.Util.printExceptionLog;

public class SkyboxUnityPlayerActivity extends UnityPlayerActivity {

    protected void onCreate(Bundle paramBundle) {
        super.onCreate(paramBundle);

        hideNavigation();

        // Bugly report plugin, app id                        7b02d33a52
        //                                               GEAR 6eafc3d907
        //CrashReport.initCrashReport(getApplicationContext());

        // Umeng
        //MobclickAgent.setDebugMode(true);
        //MobclickAgent.enableEncrypt(true);
    }

    protected void onDestroy() {
        try {
            super.onDestroy();
            //MobclickAgent.onPause(this);
        } catch (Exception e) {
            String name = "SkyboxUnityPlayerActivity Exception";
            printExceptionLog(name, e.getMessage(), LogUtil.getStackTrace());
        }
    }

    public void onPause() {
        super.onPause();
        //MobclickAgent.onPause(this);
    }

    public void onResume() {
        super.onResume();
        //MobclickAgent.onResume(this);
        hideNavigation();
    }

    public void onWindowFocusChanged(boolean paramBoolean) {
        super.onWindowFocusChanged(paramBoolean);
        hideNavigation();
    }

    public void onBackPressed() {
        super.onBackPressed();
        //MobclickAgent.onPause(this);
    }

    private void hideNavigation() {
        View decorView = getWindow().getDecorView();
        // Hide both the navigation bar and the status bar.
        // SYSTEM_UI_FLAG_FULLSCREEN is only available on Android 4.1 and higher, but as
        // a general rule, you should design your app to hide the status bar whenever you
        // hide the navigation bar.
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
    }

}
