/*****************************************************************************
 * VLCApplication.java
 * ****************************************************************************
 * Copyright © 2010-2013 VLC authors and VideoLAN
 * <p>
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * <p>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * <p>
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/
package xyz.skybox;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Process;
import android.preference.PreferenceManager;
import android.support.v4.util.SimpleArrayMap;
import android.util.Log;

import java.util.Locale;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import xyz.skybox.common.SkyboxApplicationProxy;
import xyz.skybox.common.util.BitmapCache;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.statistic.helper.FabricHelper;
import xyz.skybox.gui.airscreen.AirScreenNetwork;
import xyz.skybox.media.MediaDatabase;
import xyz.skybox.util.TypeFaceUtil;

public class SkyboxApplication extends Application {

    private static SkyboxApplication instance;

    private static SharedPreferences mSettings;

    private static SimpleArrayMap<String, Object> sDataMap = new SimpleArrayMap<>();

    private ThreadPoolExecutor mThreadPool = new ThreadPoolExecutor(0, 2, 2, TimeUnit.SECONDS,
            new LinkedBlockingQueue<Runnable>(), THREAD_FACTORY);
    public static final ThreadFactory THREAD_FACTORY = new ThreadFactory() {
        @Override
        public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable);
            thread.setPriority(Process.THREAD_PRIORITY_DEFAULT + Process.THREAD_PRIORITY_LESS_FAVORABLE);
            return thread;
        }
    };

    static {

        System.loadLibrary("skyboxstl");

    }

    @Override
    public void onCreate() {
        super.onCreate();

        SkyboxApplicationProxy.setAppContext(this);

        if (getResources().getBoolean(R.bool.isEnableFabric)) {
            FabricHelper.enableFabric(true);
            FabricHelper.init(this);
        }

        /*
        if (getResources().getBoolean(R.bool.isCompiledByFreeLine)) {
            FreelineCore.init(this);
        }
        */

        //LogUtil init
        boolean enableLog = getResources().getBoolean(R.bool.enable_log);
        String tag = getResources().getString(R.string.log_tag);
        Log.e("SKYBOX", "enableLog : " + enableLog + " tag : " + tag);
        LogUtil.enableDebug(enableLog);
        LogUtil.TAG = tag;
        //Todo LogUtil.Tag = "what ever you want"

        // Are we using advanced debugging - locale?
        mSettings = PreferenceManager.getDefaultSharedPreferences(this);
        String p = mSettings.getString("set_locale", "");
        if (!p.equals("")) {
            Locale locale;
            // workaround due to region code
            if (p.equals("zh-TW")) {
                locale = Locale.TRADITIONAL_CHINESE;
            } else if (p.startsWith("zh")) {
                locale = Locale.CHINA;
            } else if (p.equals("pt-BR")) {
                locale = new Locale("pt", "BR");
            } else if (p.equals("bn-IN") || p.startsWith("bn")) {
                locale = new Locale("bn", "IN");
            } else {
                /**
                 * Avoid a crash of
                 * java.lang.AssertionError: couldn't initialize LocaleData for locale
                 * if the user enters nonsensical region codes.
                 */
                if (p.contains("-"))
                    p = p.substring(0, p.indexOf('-'));
                locale = new Locale(p);
            }
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getResources().updateConfiguration(config,
                    getResources().getDisplayMetrics());
        }

        instance = this;
        TypeFaceUtil.initTypeFace();

        // Initialize the database soon enough to avoid any race condition and crash
        MediaDatabase.getInstance();

    }

    /**
     * Called when the overall system is running low on memory
     */
    @Override
    public void onLowMemory() {
        super.onLowMemory();

        BitmapCache.getInstance().clear();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);

        BitmapCache.getInstance().clear();
    }

    @Override
    public void onTerminate() {
        super.onTerminate();

        AirScreenNetwork.getInstance().destroy();
    }

    /**
     * @return the main context of the Application
     */
    public static Context getAppContext() {
        return instance;
    }

    /**
     * @return the main resources from the Application
     */
    public static Resources getAppResources() {
        return instance.getResources();
    }

    public static void runBackground(Runnable runnable) {
        instance.mThreadPool.execute(runnable);
    }

    public static boolean removeTask(Runnable runnable) {
        return instance.mThreadPool.remove(runnable);
    }

    public static void storeData(String key, Object data) {
        sDataMap.put(key, data);
    }

    public static Object getData(String key) {
        return sDataMap.remove(key);
    }

}
