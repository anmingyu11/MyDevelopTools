package xyz.skybox.imageloader;

import android.graphics.Bitmap;
import android.net.Uri;
import android.text.TextUtils;

import com.EasyMovieTexture.EasyMovieTexture;
import com.unity3d.player.UnityPlayer;

import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import xyz.skybox.common.util.LogUtil;
import xyz.skybox.media.MediaWrapper;
import xyz.skybox.util.BitmapUtil;

public class ImageLoader {

    public static void loadLocalPicture(final EasyMovieTexture.VideoInfo videoInfo, final MediaWrapper mediaWrapper) {

        Bitmap bitmap = BitmapUtil.getPicture(mediaWrapper);

        if (bitmap != null) {
            //第一步获取成功， 加载缩略图
//            target.onBitmapLoaded(bitmap, null);

            LogUtil.d("--- From cache 1 mediaWrapper: "+decode(mediaWrapper.getLocation()));
            if (bitmap != null) {
                LogUtil.d("w,h: "+bitmap.getWidth()+","+bitmap.getHeight());
            } else {
                // Get thumbnail failed
                LogUtil.w("--- From cache 1 result get thumbnail failed, RcgType: "+ videoInfo.getMediaRcgType()
                        +", Picture: "+ videoInfo.getMediaPicture().length);
                return;
            }

            videoInfo.setMediaRcgType(mediaWrapper.getRcgType());
            videoInfo.setMediaPicture(BitmapUtil.bitmapToByteArray(bitmap));
            UnityPlayer.UnitySendMessage("MediaPlayerCtrl", "UpdateLocalFileInfo", decode(mediaWrapper.getLocation()));

            LogUtil.d("--- From cache 1 result RcgType: "+ videoInfo.getMediaRcgType()
                    +", Picture: "+ videoInfo.getMediaPicture().length);

        } else {
            //第二步： 没有获取到， 添加local thumbnail listener到executor中，等待执行
            LocalThumbnailExecutor.addLocalThumbnailListener(
                    mediaWrapper,

                    new LocalThumbnailRunnable.ThumbnailListener() {
                        @Override
                        public void setThumbnail(final Bitmap bitmap) {

                            LogUtil.d("--- Load 2 mediaWrapper: "+decode(mediaWrapper.getLocation()));
                            if (bitmap != null) {
                                LogUtil.d("bitmap w, h: "+bitmap.getWidth()+","+bitmap.getHeight());
                            } else {
                                // Get thumbnail failed
                                LogUtil.w("--- Load 2 result get thumbnail failed, RcgType: "+ videoInfo.getMediaRcgType()
                                        +", Picture: "+ videoInfo.getMediaPicture().length);
                                return;
                            }

                            videoInfo.setMediaRcgType(mediaWrapper.getRcgType());
                            videoInfo.setMediaPicture(BitmapUtil.bitmapToByteArray(bitmap));
                            UnityPlayer.UnitySendMessage("MediaPlayerCtrl", "UpdateLocalFileInfo", decode(mediaWrapper.getLocation()));

                            LogUtil.d("--- Load 2 result RcgType: "+ videoInfo.getMediaRcgType()
                                    +", Picture: "+ videoInfo.getMediaPicture().length);
                        }
                    }
            );

            //第三步： 开始加载
            LocalThumbnailExecutorController.execute();
        }
    }

    public static void createLocalPicture(final EasyMovieTexture.VideoInfo videoInfo, final MediaWrapper mediaWrapper) {

        LocalThumbnailExecutor.addLocalThumbnailListener(
                mediaWrapper,
                new LocalThumbnailRunnable.ThumbnailListener() {
                    @Override
                    public void setThumbnail(final Bitmap bitmap) {

                        mediaWrapper.DO_HIGH_RCG = false;

                        LogUtil.d("--- Create mediaWrapper: "+mediaWrapper.getLocation());
                        if (bitmap != null) {
                            LogUtil.d("bitmap w, h: "+bitmap.getWidth()+","+bitmap.getHeight());
                        } else {
                            // Get thumbnail failed
                            LogUtil.w("create get thumbnail failed, getMediaRcgType: "+ videoInfo.getMediaRcgType()
                                    +", getMediaPicture: "+ videoInfo.getMediaPicture().length);
                            return;
                        }

                        videoInfo.setMediaRcgType(mediaWrapper.getRcgType());
                        videoInfo.setMediaPicture(BitmapUtil.bitmapToByteArray(bitmap));
                        UnityPlayer.UnitySendMessage("MediaPlayerCtrl", "UpdateLocalFileInfo", decode(mediaWrapper.getLocation()));

                        LogUtil.d("create getMediaRcgType: "+ videoInfo.getMediaRcgType()
                                +", getMediaPicture: "+ videoInfo.getMediaPicture().length);
                    }
                }
        );

        LocalThumbnailExecutorController.execute();
    }

    private static String decode(String string) {
        if (TextUtils.isEmpty(string)) {
            return "";
        }
        return Uri.decode(string);
    }

    /**
     * --------------------------------
     * LocalThumbnailExecutorController
     * --------------------------------
     */
    public static class LocalThumbnailExecutorController {

        public static void execute() {
            LocalThumbnailExecutor.execute();
        }

        public static void destroy() {
            LocalThumbnailExecutor.destroy();
        }

        public static void removeExistLocalThumbnail(LocalThumbnailRunnable localThumbnailRunnable) {
            LocalThumbnailExecutor.removeExistLocalThumbnail(localThumbnailRunnable);
        }
    }

    /**
     * --------------------------------
     * LocalThumbnailExecutor
     * --------------------------------
     */
    private static class LocalThumbnailExecutor {
        /**
         * 存储将要execute的 local thumbnail
         */
        private static final ConcurrentHashMap<String, LocalThumbnailRunnable> LOCAL_THUMBNAIL_MAP = new ConcurrentHashMap<String, LocalThumbnailRunnable>();
        //读写锁
        private static final ReadWriteLock READ_WRITE_LOCK = new ReentrantReadWriteLock();

        //缩略图加载线程线程池
        private static ThreadPoolExecutor sExecutor = null;
        private static final ThreadFactory THREAD_FACTORY = new ThreadFactory() {
            @Override
            public Thread newThread(Runnable runnable) {
                Thread thread = new Thread(runnable);
                return thread;
            }
        };

        private static final int CORE_POOL_SIZE = 3;
        private static final int MAXIMUM_POOL_SIZE = 3;
        private static final int KEEP_ALIVE_TIME = 2;

        private static void addLocalThumbnailListener(MediaWrapper mediaWrapper, LocalThumbnailRunnable.ThumbnailListener thumbnailListener) {
            READ_WRITE_LOCK.writeLock().lock();

            //未获取缩略图或未成功
            if (mapContains(mediaWrapper)) {
                //如果已经添加了对应的localThumbnail，在已有的thumbnail value中添加新的listener
                LogUtil.d(mediaWrapper.getLocation() + " exists ");
                LOCAL_THUMBNAIL_MAP.get(mediaWrapper.getLocation()).addThumbnailListener(thumbnailListener);

            } else {
                //如果没有添加对应的localThumbnail，创建的thumbnail对象
                LogUtil.d(mediaWrapper.getLocation() + " not exists create a new Thumbnail");
                LocalThumbnailRunnable localThumbnailRunnable = new LocalThumbnailRunnable(mediaWrapper);
                localThumbnailRunnable.addThumbnailListener(thumbnailListener);
                LOCAL_THUMBNAIL_MAP.put(mediaWrapper.getLocation(), localThumbnailRunnable);
            }

            READ_WRITE_LOCK.writeLock().unlock();
        }

        private static void removeExistLocalThumbnail(LocalThumbnailRunnable localThumbnailRunnable) {
            LOCAL_THUMBNAIL_MAP.remove(localThumbnailRunnable.getTAG());
        }

        /**
         * @param mediaWrapper
         * @return 执行哈希表sLocalThumbnail中是否存在
         */
        private static boolean mapContains(MediaWrapper mediaWrapper) {
            return LOCAL_THUMBNAIL_MAP.containsKey(mediaWrapper.getLocation());
        }

        private static void createExecutor() {
            sExecutor = new ThreadPoolExecutor(
                    CORE_POOL_SIZE, MAXIMUM_POOL_SIZE,
                    KEEP_ALIVE_TIME, TimeUnit.SECONDS,
                    new LinkedBlockingQueue<Runnable>(),
                    THREAD_FACTORY);
        }

        private static void execute() {

            if (sExecutor == null) {
                LogUtil.d("Thumbnail executor is null create");
                createExecutor();
            }
            if (sExecutor.isShutdown() || sExecutor.isTerminated()) {
                LogUtil.d("Thumbnail executor is terminated");
                createExecutor();
            } else if (sExecutor.isTerminating()) {
                try {
                    if (sExecutor.awaitTermination(2, TimeUnit.SECONDS)) {
                        LogUtil.d("Thumbnail executor is awaited and then terminated");
                        createExecutor();
                    } else {
                        throw new InterruptedException("await termination failed");
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    destroy();
                }
            }

            Set<String> keySet = LOCAL_THUMBNAIL_MAP.keySet();
            LogUtil.d("LocalThumbnailExecutor Start , Task Size : " + keySet.size());

            for (String key : LOCAL_THUMBNAIL_MAP.keySet()) {
                LocalThumbnailRunnable thumbnailRunnable = LOCAL_THUMBNAIL_MAP.get(key);
                LogUtil.d("ImageLoader: " + key
                        + " isRunning: " + thumbnailRunnable.isRunning()
                        + " isDone: " + thumbnailRunnable.isDone());

                // 去掉正在BlockQueue中等待的任务, 或者正在执行中的任务．
                if (!sExecutor.getQueue().contains(thumbnailRunnable)
                        && !thumbnailRunnable.isRunning()) {
                    sExecutor.execute(LOCAL_THUMBNAIL_MAP.get(key));
                }
            }
        }

        private static void destroy() {
            BlockingQueue<Runnable> blockingDeque = sExecutor.getQueue();
            blockingDeque.clear();
            LOCAL_THUMBNAIL_MAP.clear();
            sExecutor.shutdownNow();
            LogUtil.d("------ destroy end ------");
        }
    }

}
