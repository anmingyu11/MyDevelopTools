package xyz.skybox;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.PermissionChecker;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import xyz.skybox.common.util.LogUtil;
import xyz.skybox.gui.MainActivity;
import xyz.skybox.media.MediaLibrary;
import xyz.skybox.repository.networkservice.NetworkService;

public class StartActivity extends AppCompatActivity {

    private Context mContext;
    private MediaLibrary mMediaLibrary;

    private static final int RC_EXIT_VR = 777;
    private static final int RC_ASK_PERMISSION = 778;
    private boolean allPermissionsGranted = false;

    private String[] permissionArray = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mContext = this;

        super.onCreate(savedInstanceState);

        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.activity_start);

        startNetWorkService();

        startSKYBOX();

        ViewGroup contentFrameLayout = (ViewGroup) findViewById(Window.ID_ANDROID_CONTENT);
        View parentView = contentFrameLayout.getChildAt(0);
        if (parentView != null && Build.VERSION.SDK_INT >= 14) {
            parentView.setFitsSystemWindows(true);
        }

    }

    private void startSKYBOX() {
        if (checkPermissions()) {
            // has permission
            //launchVR();
            launchZeus();
        } else {
            requestPermissions();
        }
    }

    public void startNetWorkService() {
        Intent intent = new Intent(this, NetworkService.class);
        startService(intent);
    }

    public void onPause() {
        super.onPause();
        //MobclickAgent.onPause(this);
    }

    public void onResume() {
        super.onResume();
        //MobclickAgent.onResume(this);
    }

    public void onWindowFocusChanged(boolean paramBoolean) {
        super.onWindowFocusChanged(paramBoolean);
        //hideNavigation();
    }

    public void onBackPressed() {
        //super.onBackPressed();
    }

/*
    private void hideNavigation() {
        View decorView = getWindow().getDecorView();
        // Hide both the navigation bar and the status bar.
        // SYSTEM_UI_FLAG_FULLSCREEN is only available on Android 4.1 and higher, but as
        // a general rule, you should design your app to hide the status bar whenever you
        // hide the navigation bar.
        int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
    }
*/

//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if (requestCode == RC_EXIT_VR) {
//            if (resultCode == -1) {
//                requestPermissions(this.permissionArray, 778);
//            } else {
//                Log.w("TransitionVRActivity", "exitFromVR returned " + resultCode + ", finishing");
//                PermissionsFragment.setPermissionResult(false);
//                finish();
//            }
//        }
//        else super.onActivityResult(requestCode, resultCode, data);
//    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == RC_ASK_PERMISSION) {
            this.allPermissionsGranted = true;
            for (int result : grantResults) {
                if (result != 0) {
                    this.allPermissionsGranted = false;
                    break;
                }
            }

            if (allPermissionsGranted) {
                //launchVR();
                launchZeus();
            } else {
                requestPermissions();
            }

        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void launchVR() {
        runOnUiThread(new Runnable() {
            public void run() {
                launchVrByDaydreamApi();
            }
        });
    }

    private void launchZeus() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent();
                intent.setClass(mContext, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void launchVrByDaydreamApi() {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(
                "com.west.player.cardboard",
                "xyz.skybox.SkyboxUnityPlayerActivity"));
//        intent.setAction(Intent.ACTION_MAIN);
//        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
//                | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
//        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        startActivity(intent);
        finish();
    }

    private boolean checkPermissions() {
        boolean[] grantResults = hasPermissions(permissionArray);
        for (boolean grant : grantResults) {
            if (!grant) {
                return false;
            }
        }
        return true;
    }

    private boolean hasPermission(String permission) {
        if (Build.VERSION.SDK_INT >= 23) {
            LogUtil.d("Checking permission " + permission);

            return ContextCompat.checkSelfPermission(this, permission) == PermissionChecker.PERMISSION_GRANTED;
        }
        return true;
    }

    private boolean[] hasPermissions(String[] permissions) {
        if (permissions == null) {
            LogUtil.d("No permission asked, no permissions returned");
            return new boolean[0];
        }

        int length = permissions.length;
        boolean[] grantResults = new boolean[length];
        for (int i = 0; i < length; i++) {
            LogUtil.d("Checking permission for " + permissions[i]);
            grantResults[i] = hasPermission(permissions[i]);
        }

        return grantResults;
    }

    private void requestPermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(this.permissionArray, RC_ASK_PERMISSION);
        }
    }

}
