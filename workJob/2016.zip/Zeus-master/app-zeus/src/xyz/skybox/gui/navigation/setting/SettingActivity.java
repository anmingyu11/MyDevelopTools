//Todo copyright
package xyz.skybox.gui.navigation.setting;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v4.app.Fragment;
import android.view.View;

import xyz.skybox.R;
import xyz.skybox.gui.navigation.NavigationActivity;
import xyz.skybox.gui.navigation.NavigationMainUiParams;

public class SettingActivity extends NavigationActivity {

    private boolean isPushUp;

    private SettingFragment mSettingFragment;

    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
    }

    @Override
    public Fragment injectFragment() {
        return mSettingFragment = new SettingFragment();
    }

    @Override

    protected NavigationMainUiParams injectNavigationMainUiParams() {
        isPushUp = false;
        return new NavigationMainUiParams(
                null,
                getDrawableFromId(R.drawable.home_titlebar_back_white),
                null,
                getDrawableFromId(R.drawable.home_titlebar_back_black),
                isPushUp,
                getStringFromId(R.string.title_setting)) {
            @Override
            public void rightOnClick(View view) {
            }

            @Override
            public void leftOnclick(View view) {
                onBackPressed();
            }
        };
    }
}
