package xyz.skybox.gui.airscreen;

import android.content.Context;
import android.os.Message;

import com.crashlytics.android.answers.CustomEvent;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import xyz.skybox.R;
import xyz.skybox.SkyboxApplication;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.statistic.helper.FabricHelper;
import xyz.skybox.gui.MainActivity;
import xyz.skybox.media.MediaDatabase;
import xyz.skybox.media.MediaUtils;
import xyz.skybox.media.Recognition;
import xyz.skybox.repository.airscreen.AirScreenMediaWrapper;
import xyz.skybox.repository.airscreen.CallbackThread;
import xyz.skybox.repository.airscreen.Command;
import xyz.skybox.repository.airscreen.ServerInfo;
import xyz.skybox.repository.airscreen.ServerInfoManager;
import xyz.skybox.repository.airscreen.ServerItemBean;
import xyz.skybox.util.AndroidDevices;

import static xyz.skybox.gui.airscreen.AirScreenNetwork.State.AddedDevice;
import static xyz.skybox.gui.airscreen.AirScreenNetwork.State.AddingDevice;
import static xyz.skybox.gui.airscreen.AirScreenNetwork.State.ConnectReady;
import static xyz.skybox.gui.airscreen.AirScreenNetwork.State.Init;
import static xyz.skybox.gui.airscreen.AirScreenNetwork.State.LoggedIn;
import static xyz.skybox.gui.airscreen.AirScreenNetwork.State.LoggingIn;
import static xyz.skybox.gui.airscreen.AirScreenNetwork.State.SearchedServer;
import static xyz.skybox.gui.airscreen.AirScreenNetwork.State.SocketConnected;
import static xyz.skybox.gui.airscreen.AirScreenNetwork.State.StartConnect;
import static xyz.skybox.gui.airscreen.AirScreenNetwork.State.StartConnectReady;

public class AirScreenNetwork {

    private native void nativeInitSKYBOX(String ThirdPartyLibPath);

    private native void nativeStartupSocketIO();

    private native void nativeShutdownSocketIO();

    private native boolean nativeListenOnPort(int ListenPort);

    private native boolean nativeIsListening();

    private native void nativeDisListen();

    private native void nativeSetLoggerCallback(String Callback);

    private native void nativeSetEventCallback(String Callback);

    private native void nativeTickSocketIOMainThread();

    private native int nativeUdpSendTo(byte[] Data, int Count, String Destination);

    private native void nativeEmitEvent(String Event);

    private native int nativeWebSocketGetCurrentState();

    private native boolean nativeWebSocketConnect(String ip, int port);

    private native boolean nativeWebSocketBuildConnection();

    private native void nativeWebSocketDisConnect();

    private static final int WEB_SOCKET_STATE_DISCONNECTED = 0;
    private static final int WEB_SOCKET_STATE_CONNECTED = 1;
    private static final int WEB_SOCKET_STATE_READY = 2;

    private static void loadLibraries() {
        if (sLoaded)
            return;
        sLoaded = true;

        Recognition.startupRecognition();

    }

    private String mSendIpInfo;
    private boolean isNeedSearching = true;
    private static boolean sLoaded = false;
    private static AirScreenNetwork sAirScreenNetwork;
    private static CallbackThread sCallbackThread;
    private State mConnectState = Init;
    private final static String DEVICE_TYPE = "android";
    private final static String UDP_PORT = "6880";
    public final static int OVER_TIME = 8000;

    private Context mContext;
    private MainActivity mMainActivity;
    private int mVideoNum;

    // TODO for test ----
    String mDeviceId = null;
    String mDeviceName = null;
    String mPcName = null;
    //----

    public enum State {
        Init,
        SearchingServer,
        SearchedServer,
        StartConnectReady,
        StartConnect,
        SocketConnected,
        ConnectReady,
        AddingDevice,
        AddedDevice,
        LoggingIn,
        LoggedIn
    }

    public static String[] sStateArray = new String[]{
            "Init",
            "SearchingServer",
            "SearchedServer",
            "StartConnectReady",
            "StartConnect",
            "SocketConnected",
            "ConnectReady",
            "AddingDevice",
            "AddedDevice",
            "LoggingIn",
            "LoggedIn"
    };

    private AirScreenNetwork() {
        mContext = SkyboxApplication.getAppContext();

        loadLibraries();

        mSendIpInfo = "255.255.255.255:6879";

        Recognition.startupRecognition();
        nativeInitSKYBOX("tmp");
        nativeStartupSocketIO();
        nativeSetEventCallback("NetworkCallback");
        // TODO use this
        //        nativeListenOnPort(Integer.parseInt(UDP_PORT));

        //Init
        //Todo if this device is pad
        mDeviceId = AndroidDevices.getUniversalID(mContext);
        mDeviceName = android.os.Build.MODEL;
        mPcName = "DESKTOP-FONICH6";

        LogUtil.logStackTrace();
        LogUtil.d("  " + Thread.currentThread().toString());
        LogUtil.d(" mSendIpInfo: " + mSendIpInfo);
        LogUtil.d("nativeListenOnPort: " + nativeListenOnPort(Integer.parseInt(UDP_PORT)));
    }

    public void setMainActivity(MainActivity mainActivity) {
        mMainActivity = mainActivity;
    }

    public void startThread() {
        sCallbackThread = new CallbackThread(sAirScreenNetwork);
        sCallbackThread.start();
    }

    public boolean isThreadRunning() {
        return sCallbackThread != null;
    }

    public static AirScreenNetwork getInstance() {
        if (sAirScreenNetwork == null) {
            sAirScreenNetwork = new AirScreenNetwork();
        }
        return sAirScreenNetwork;
    }

    public State getConnectState() {
        return mConnectState;
    }

    public void destroy() {
        sAirScreenNetwork = null;
        sCallbackThread.stopLoop();
        sCallbackThread = null;

        nativeDisListen();
        nativeWebSocketDisConnect();
        nativeShutdownSocketIO();

        // TODO need destroy
        LogUtil.d(" destroy!!! ");
    }

    public void searchServer() {
        FabricHelper.logCustomEvent("start search server");

        isNeedSearching = true;

        Command.CmdSearch search = new Command.CmdSearch("direwolf", mDeviceId, DEVICE_TYPE, UDP_PORT);
        Gson gson = new Gson();
        String jsonStr = gson.toJson(search);

        LogUtil.d(" jsonStr: " + jsonStr);
        LogUtil.d("nativeUdpSendTo: " + nativeUdpSendTo(jsonStr.getBytes(), jsonStr.length(), mSendIpInfo));

//        nativeUdpSendTo(jsonStr.getBytes(), jsonStr.length(), byteSend, mSendIpInfo);
        mConnectState = State.SearchingServer;
    }

    //Todo will do thread terminate logic in future
    public void connectServerByIpSync(final String ip) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                connectServerByIp(ip);
            }
        });
        t.start();
    }

    public void connectServerByIp(String ip) {
        FabricHelper.logCustomEvent("connect server by ip : " + ip);
        ServerInfoManager serverInfoManager = ServerInfoManager.getInstance();

        //Todo the only identifer
        ServerInfo serverInfo = serverInfoManager.getServerInfoByIp(ip);
        serverInfoManager.setCurrentServerInfo(serverInfo);

        int port = Integer.parseInt(serverInfo.port);

        nativeWebSocketDisConnect();

        mConnectState = StartConnectReady;

//        boolean flag = nativeWebSocketConnect(serverInfo.ip, port);

        LogUtil.d("connectServer serverInfo: " + serverInfo.toString());

    }

    public boolean connectServerByIndex(int index) {
        ServerInfoManager serverInfoManager = ServerInfoManager.getInstance();

        if (index < 0 || index >= serverInfoManager.getServerNum()) {
            return false;
        }
        if (index < 0 || index >= serverInfoManager.getServerNum()) {
            return false;
        }

        ServerInfo serverInfo = serverInfoManager.getServerInfoByIndex(index);
        serverInfoManager.setCurrentServerInfoIndex(index);

        int port = Integer.parseInt(serverInfo.port);

        nativeWebSocketDisConnect();

        LogUtil.d("connectServer serverInfo: " + serverInfo.toString());
        LogUtil.d("connectServer nativeWebSocketConnect: " + nativeWebSocketConnect(serverInfo.ip, port));
        return true;
    }


    public void tryAddDevice() {
        Command.CmdAddDevice addDevice = new Command.CmdAddDevice(mDeviceId, mDeviceName, DEVICE_TYPE);
        Gson gson = new Gson();
        String addDeviceStr = gson.toJson(addDevice);

        LogUtil.d("[AddDevice] addDeviceStr: " + addDeviceStr);
        nativeEmitEvent(addDeviceStr);
        mConnectState = AddingDevice;
    }

    public void tryLogin(String loginCode) {
        Command.CmdLogin login = new Command.CmdLogin(loginCode);
        Gson gson = new Gson();
        String loginStr = gson.toJson(login);

        LogUtil.d("[Login] loginStr: " + loginStr);
        nativeEmitEvent(loginStr);
        mConnectState = LoggingIn;
    }

    public void notifyDisconnect() {
        Command.CmdDisconnect disconnect = new Command.CmdDisconnect();
        Gson gson = new Gson();
        String disconnectStr = gson.toJson(disconnect);

        LogUtil.d("[Disconnect] disconnectStr: " + disconnectStr);
        nativeEmitEvent(disconnectStr);
        mConnectState = Init;
        mMainActivity.getZeusHandler().removeMessages(MainActivity.ZeusHandler.AIR_SCREEN_CONNECT_OVER_TIME);
    }

    public void notifyDownloadMediaStarted(String id) {
        Command.CmdDownloadMediaStarted command = new Command.CmdDownloadMediaStarted(id);
        Gson gson = new Gson();
        String commandStr = gson.toJson(command);

        LogUtil.d("[DownloadMediaStarted] commandStr: " + commandStr);
        nativeEmitEvent(commandStr);
    }

    public void notifyDownloadMediaFinished(String id) {
        Command.CmdDownloadMediaFinished command = new Command.CmdDownloadMediaFinished(id);
        Gson gson = new Gson();
        String commandStr = gson.toJson(command);

        LogUtil.d("[DownloadMediaFinished] commandStr: " + commandStr);
        nativeEmitEvent(commandStr);
    }

    public void notifyDownloadMediaCancelled(String id) {
        Command.CmdDownloadMediaCancelled command = new Command.CmdDownloadMediaCancelled(id);
        Gson gson = new Gson();
        String commandStr = gson.toJson(command);

        LogUtil.d("[DownloadMediaCancelled] commandStr: " + commandStr);
        nativeEmitEvent(commandStr);
    }

    public void getMediaList() {

        if (mConnectState != LoggedIn
                || nativeWebSocketGetCurrentState() != WEB_SOCKET_STATE_READY) {
            return;
        }

        Command.CmdBase getMediaList = new Command.CmdBase("getMediaList");
        Gson gson = new Gson();
        String getMediaListStr = gson.toJson(getMediaList);

        LogUtil.d("[getMediaList] getMediaListStr: " + getMediaListStr);

        nativeEmitEvent(getMediaListStr);
    }

    private void updateUIDeviceFound(List<ServerItemBean> deviceItemBeen) {
        Message msg = new Message();
        msg.what = MainActivity.ZeusHandler.SHOW_DEVICE_FOUNDED;
        msg.obj = deviceItemBeen;
        mMainActivity.getZeusHandler().sendMessage(msg);
    }

    private void showCodeDialog() {
        Message msg = new Message();
        msg.what = MainActivity.ZeusHandler.SHOW_CODE_DIALOG;
        mMainActivity.getZeusHandler().sendMessage(msg);
    }

    private void showAirScreenVideoGridFragment(ServerInfo serverInfo) {

        mMainActivity.getZeusHandler().sendEmptyMessage(MainActivity.ZeusHandler.SHOW_SEARCH_TIPS);

        dismissLoadingDialog();
        Message msg = new Message();
        msg.what = MainActivity.ZeusHandler.SHOW_AIRSCREEN_GRID_FRAGMENT;
        msg.obj = new Object[]{serverInfo.computerName};
        mMainActivity.getZeusHandler().sendMessage(msg);

        // Save connected server info.
        MediaDatabase mediaDatabase = MediaDatabase.getInstance();
        mediaDatabase.saveConnectedServer(serverInfo.computerId, serverInfo.computerName, serverInfo.ip, serverInfo.port);
    }

    private void showCodeDialogCodeInvalid() {
        Boolean isTitleNormal = false;
        Message msg = new Message();
        msg.what = MainActivity.ZeusHandler.CHANGE_CODE_DIALOG_TITLE;
        msg.obj = isTitleNormal;
        mMainActivity.getZeusHandler().sendMessage(msg);
    }

    private void dismissCodeDialog() {
        Message msg = new Message();
        msg.what = MainActivity.ZeusHandler.DISMISS_CODE_DIALOG;
        mMainActivity.getZeusHandler().sendMessage(msg);
    }

    private void updateAirScreenVideoGridItemList(List<AirScreenMediaWrapper> airScreenMediaWrappers) {
        LogUtil.d("getMediaList step 3 updateAirScreenVideoGridItemList ");
        Message msg = new Message();
        MediaUtils.actionRemoteScanStop();
        msg.what = MainActivity.ZeusHandler.UPDATE_AIRSCREEN_GRID_ITEM_LIST;
        msg.obj = airScreenMediaWrappers;
        //mAirScreenMediaWrapperList = airScreenMediaWrappers;
        mMainActivity.getZeusHandler().sendMessage(msg);
    }

    private List<AirScreenMediaWrapper> mAirScreenMediaWrapperList;

    public List<AirScreenMediaWrapper> getAirScreenMediaWrapperList() {
        return mAirScreenMediaWrapperList;
    }

    private void disconnect() {
        mMainActivity.getZeusHandler().sendEmptyMessage(MainActivity.ZeusHandler.DISCONNECT_BUTTON_CLICKED);
    }

    private void startMediaDownload(String id) {
        Message msg = new Message();
        msg.what = MainActivity.ZeusHandler.START_MEDIA_DOWNLOAD;
        msg.obj = new Object[]{id};
        mMainActivity.getZeusHandler().sendMessage(msg);
    }

    private void cancelMediaDownload(String id) {
        Message msg = new Message();
        msg.what = MainActivity.ZeusHandler.CANCEL_MEDIA_DOWNLOAD;
        msg.obj = new Object[]{id};
        mMainActivity.getZeusHandler().sendMessage(msg);
    }

    private void deleteAllMediaItems() {
        mMainActivity.getZeusHandler().sendEmptyMessage(MainActivity.ZeusHandler.DELETE_ALL_AIRSCREEN_MEDIA_ITEM);
    }

    private void deleteMediaItem(String id) {
        Message msg = new Message();
        msg.obj = new Object[]{id};
        msg.what = MainActivity.ZeusHandler.DELETE_AIRSCREEN_MEDIA_ITEM;
        mMainActivity.getZeusHandler().sendMessage(msg);
    }

    public void showLoadingDialog() {
        Message msg = new Message();
        msg.obj = null;
        msg.what = MainActivity.ZeusHandler.SHOW_LOADING_DIALOG;
        mMainActivity.getZeusHandler().
                sendMessage(msg);
    }

    public void showLoadingDialog(int y) {
        Message msg = new Message();
        msg.obj = Integer.valueOf(
                mContext.getResources().getDimensionPixelSize(R.dimen.loading_dialog_margin_top)
                        - y);
        msg.what = MainActivity.ZeusHandler.SHOW_LOADING_DIALOG;
        mMainActivity.getZeusHandler().sendMessage(msg);
    }

    private void dismissLoadingDialog() {
        mMainActivity.getZeusHandler().
                sendEmptyMessage(MainActivity.ZeusHandler.DISSMISS_LOADING_DIALOG);
    }

    /**
     * Network callback from PC server, which send a message to client.
     *
     * @param jsonMessage
     */
    private void NetworkCallback(String jsonMessage) {
        if (jsonMessage.contains("Büro")) {
            return;
        }

        Gson gson = new Gson();
        Command.CmdBase cmdObj = gson.fromJson(jsonMessage, Command.CmdBase.class);

        LogUtil.d(" NetworkCallback: " + Thread.currentThread().toString());
        LogUtil.d(" jsonMessage: " + jsonMessage);
        LogUtil.d(" cmdObj: " + cmdObj.toString());
        LogUtil.d(" cmdObj.command: " + cmdObj.command);

        if (isNeedSearching && "searchResult".equals(cmdObj.command)) {
            // 1. Search server result.
            Command.CmdSearchResult cmd = gson.fromJson(jsonMessage, Command.CmdSearchResult.class);
            LogUtil.d("searchResult  cmdObj.command: " + cmdObj.command);

            String deviceId = cmd.deviceId;
            String computerId = cmd.computerId;
            String computerName = cmd.computerName;
            String ip = cmd.ip;
            String port = cmd.port;

            LogUtil.d("     deviceId: " + deviceId);
            LogUtil.d("   computerId: " + computerId);
            LogUtil.d(" computerName: " + computerName);
            LogUtil.d("           ip: " + ip);
            LogUtil.d("         port: " + port);

            ServerInfo serverInfo = new ServerInfo(deviceId, computerId, computerName, ip, port);
            ServerInfoManager.getInstance().addServerInfo(serverInfo);
            mConnectState = SearchedServer;

            updateUIDeviceFound(ServerInfoManager.getInstance().parseServerInfoToDeviceItemBean());

        } else if ("addDeviceResult".equals(cmdObj.command)) {
            // 2. Add device result.
            Command.CmdAddDeviceResult cmd = gson.fromJson(jsonMessage, Command.CmdAddDeviceResult.class);

            LogUtil.d("addDeviceResult success: " + cmd.success + ", isLoggedIn: " + cmd.isLoggedIn);

            if (cmd.isLoggedIn == 1) {

                mConnectState = LoggedIn;

                showAirScreenVideoGridFragment(ServerInfoManager.getInstance().getCurrentServerInfo());

            } else if (cmd.success == 1) {
                mConnectState = AddedDevice;

                dismissLoadingDialog();

                //Show dialog
                showCodeDialog();

            } else {
                LogUtil.d("addDeviceResult false.");
            }

        } else if ("loginResult".equals(cmdObj.command)) {
            // 3. Login result.
            Command.CmdLoginResult cmd = gson.fromJson(jsonMessage, Command.CmdLoginResult.class);

            LogUtil.d("loginResult success: " + cmd.success);

            if (cmd.success == 1) {
                mConnectState = LoggedIn;

                dismissCodeDialog();

                showAirScreenVideoGridFragment(ServerInfoManager.getInstance().getCurrentServerInfo());

            } else {
                mConnectState = AddedDevice;

                showCodeDialogCodeInvalid();
            }

        } else if ("getMediaListResult".equals(cmdObj.command)) {
            // 4. Get media list.
            Command.CmdGetMediaListResult cmd = gson.fromJson(jsonMessage, Command.CmdGetMediaListResult.class);
            LogUtil.d("getMediaList step 2 getMediaList from json: " + cmd.toString());

            List<Command.CmdMediaInfo> cmdMediaInfos = cmd.list;
            List<AirScreenMediaWrapper> airScreenMediaWrapperList = new ArrayList<AirScreenMediaWrapper>(cmdMediaInfos.size());

            for (Command.CmdMediaInfo cmdMediaInfo : cmdMediaInfos) {

                LogUtil.d("              id: " + cmdMediaInfo.id);
                LogUtil.d("            name: " + cmdMediaInfo.name);
                LogUtil.d("        duration: " + cmdMediaInfo.duration);
                LogUtil.d("             url: " + cmdMediaInfo.url);
                LogUtil.d("    thumbnailUrl: " + cmdMediaInfo.thumbnail);
                LogUtil.d("  thumbnailWidth: " + cmdMediaInfo.thumbnailWidth);
                LogUtil.d(" thumbnailHeight: " + cmdMediaInfo.thumbnailHeight);

                AirScreenMediaWrapper airScreenMediaWrapper =
                        new AirScreenMediaWrapper(
                                mMainActivity,
                                cmdMediaInfo.id,
                                cmdMediaInfo.name,
                                cmdMediaInfo.duration,
                                cmdMediaInfo.size,
                                cmdMediaInfo.url,
                                cmdMediaInfo.thumbnail,
                                cmdMediaInfo.thumbnailWidth,
                                cmdMediaInfo.thumbnailHeight,
                                cmdMediaInfo.lastModified,
                                cmdMediaInfo.defaultVRSetting,
                                cmdMediaInfo.userVRSetting);
                airScreenMediaWrapperList.add(airScreenMediaWrapper);
            }

            // Update RemoteMediaList.
            updateAirScreenVideoGridItemList(airScreenMediaWrapperList);

        } else if ("activeDisconnect".equals(cmdObj.command)) {
            // 5. PC server active disconnect.
            Command.CmdActiveDisconnect cmd = gson.fromJson(jsonMessage, Command.CmdActiveDisconnect.class);

            //Disconnect
            disconnect();

        } else if ("error".equals(cmdObj.command)) {
            // 6. PC server return a error message.
            Command.CmdError cmd = gson.fromJson(jsonMessage, Command.CmdError.class);
            // TODO:
            LogUtil.e("Server error: " + cmd.message);

        } else if ("needDownloadMedia".equals(cmdObj.command)) {
            // 14. PC server notify client to download a video.
            Command.CmdNeedDownloadMedia cmd = gson.fromJson(jsonMessage, Command.CmdNeedDownloadMedia.class);

            startMediaDownload(cmd.id);

        } else if ("cancelDownloadMedia".equals(cmdObj.command)) {
            // 15. PC server notify client to cancel download a video.
            Command.CmdCancelDownloadMedia cmd = gson.fromJson(jsonMessage, Command.CmdCancelDownloadMedia.class);

            cancelMediaDownload(cmd.id);

        } else if ("deleteMedia".equals(cmdObj.command)) {
            // 16. PC server notify client has deleted a video.
            Command.CmdDeleteMedia cmd = gson.fromJson(jsonMessage, Command.CmdDeleteMedia.class);

            deleteMediaItem(cmd.id);

        } else if ("deleteAllMedias".equals(cmdObj.command)) {
            // 17. PC server notify client has deleted all video.
            Command.CmdDeleteAllMedias cmd = gson.fromJson(jsonMessage, Command.CmdDeleteAllMedias.class);

            deleteAllMediaItems();

        } else if ("startBlocking".equals(cmdObj.command)) {
            // 19. Notify all clients that the server is in a blocked state.
            Command.CmdStartBlocking cmd = gson.fromJson(jsonMessage, Command.CmdStartBlocking.class);

            MediaUtils.actionRemoteScanStart();

        } else if ("stopBlocking".equals(cmdObj.command)) {
            // 20. Notify all clients that the server is in a non-blocked state.
            Command.CmdStopBlocking cmd = gson.fromJson(jsonMessage, Command.CmdStopBlocking.class);

            MediaUtils.actionRemoteScanStop();

        } else if ("updateNewMediasToClients".equals(cmdObj.command)) {
            // 21. Update newly added videos.
            Command.CmdUpdateNewMediasToClients cmd = gson.fromJson(jsonMessage, Command.CmdUpdateNewMediasToClients.class);
            LogUtil.d("updateNewMediasToClients json: " + cmd.toString());

            List<Command.CmdMediaInfo> cmdMediaInfos = cmd.list;
            List<AirScreenMediaWrapper> airScreenMediaWrapperList = new ArrayList<AirScreenMediaWrapper>(cmdMediaInfos.size());
            mVideoNum = cmd.list.size();
            getMediaList();

        } else if ("updateReadyMediaToClients".equals(cmdObj.command)) {
            // 22. Update the processed video.
            Command.CmdUpdateReadyMediaToClients cmd = gson.fromJson(jsonMessage, Command.CmdUpdateReadyMediaToClients.class);
            mVideoNum--;
            if (mVideoNum == 0) {
                // When load completed, get videos list.
                getMediaList();
            }
        } else if ("getChannelPlayList".equals(cmdObj.command)) {

            // TODO send play list
        }

    }

    public void tick() {
//        LogUtil.d(" tick mConnectState: " + mConnectState + ", nativeWebSocketGetCurrentState(): " + nativeWebSocketGetCurrentState());
        nativeTickSocketIOMainThread();

        if (mConnectState == StartConnectReady
                && nativeWebSocketGetCurrentState() == WEB_SOCKET_STATE_DISCONNECTED) {
            ServerInfo serverInfo = ServerInfoManager.getInstance().getCurrentServerInfo();
            if (serverInfo != null) {
                int port = Integer.parseInt(serverInfo.port);
                boolean flag = nativeWebSocketConnect(serverInfo.ip, port);
//                LogUtil.D(" nativeWebSocketConnect: " + flag);
                mConnectState = StartConnect;

            } else {
                // TODO disconnect
            }

        } else if (mConnectState == StartConnect
                && nativeWebSocketGetCurrentState() == WEB_SOCKET_STATE_CONNECTED) {
            boolean done = nativeWebSocketBuildConnection();
//            LogUtil.d(" nativeWebSocketBuildConnection(): " + done);
            if (done) {
                mConnectState = SocketConnected;
            } else {
                // TODO disconnect
            }

        } else if (mConnectState == SocketConnected
                && nativeWebSocketGetCurrentState() == WEB_SOCKET_STATE_READY) {
            mConnectState = ConnectReady;
            tryAddDevice();
        }
    }

}
