//Todo copyright
package xyz.skybox.gui.navigation.history;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v4.app.Fragment;
import android.view.View;

import xyz.skybox.R;
import xyz.skybox.gui.navigation.NavigationActivity;
import xyz.skybox.gui.navigation.NavigationMainUiParams;
import xyz.skybox.media.MediaDatabase;

public class HistoryActivity extends NavigationActivity {

    private HistoryGridFragment mHistoryGridFragment;

    private boolean isPushUp;
    private boolean isListMode;

    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
    }

    @Override
    public Fragment injectFragment() {
        return mHistoryGridFragment = new HistoryGridFragment();
    }

    @Override
    protected NavigationMainUiParams injectNavigationMainUiParams() {
        isPushUp = mHistoryGridFragment.isPushUp();
        isListMode = mHistoryGridFragment.isListMode();

        return new NavigationMainUiParams(
                getDrawableFromId(R.drawable.home_titlebar_clear_white),
                getDrawableFromId(R.drawable.home_titlebar_back_white),
                getDrawableFromId(R.drawable.home_titlebar_clear_black),
                getDrawableFromId(R.drawable.home_titlebar_back_black),
                isPushUp,
                getStringFromId(R.string.title_history)) {

            @Override
            public void rightOnClick(View view) {
                MediaDatabase.getInstance().clearHistory();
                mHistoryGridFragment.updateList();
            }

            @Override
            public void leftOnclick(View view) {
                onBackPressed();
            }
        };
    }
}
