//Todo Copyright
package xyz.skybox.gui.airscreen.connect;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import xyz.skybox.R;
import xyz.skybox.common.util.GuavaUtil;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.gui.MainActivity;
import xyz.skybox.gui.airscreen.connect.devicefound.AirScreenFoundListAdapter;
import xyz.skybox.gui.airscreen.connect.devicefound.AirScreenFoundListItemDecoration;
import xyz.skybox.gui.view.DividerItemDecoration;
import xyz.skybox.repository.airscreen.ServerInfoManager;
import xyz.skybox.repository.airscreen.ServerItemBean;

public class AirScreenConnectFragment extends Fragment implements AirScreenConnectContract.View {

    private AirScreenConnectContract.Presenter mPresenter;

    private MainActivity mMainActivity;

    //Backgrounds
    private View mPcImg;
    private View mPcImgShadow;
    private RelativeLayout mConnectContent;

    //Search tips
    private boolean isSearchTipsShown = true;
    private ViewGroup mSearchTips;

    //Searching for devices
    private boolean isSearchingShown = false;
    private ViewGroup mSearchingGroup;
    private ImageView mSearchingIcon;
    private RotateAnimation mSearchIconRotateAnimation;

    //Devices found
    private boolean isDeviceFoundedShown = false;
    private ViewGroup mDeviceFoundGroup;
    private TextView mDeviceFoundTitle;
    private RecyclerView mDeviceFoundList;
    private AirScreenFoundListAdapter mAirScreenFoundListAdapter;
    private RecyclerView.ItemAnimator mAirScreenFoundListItemAnimator;
    private List<ServerItemBean> mDevicesFounded;

    //No devices found
    private boolean isNoDevicesFoundShown = false;

    //SearchDevice button
    private TextView mSearchDeviceButton;

    //Code Dialog
    private AirScreenCodeDialog mAirScreenCodeDialog;

    public AirScreenConnectFragment() {
        super();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mMainActivity = (MainActivity) getActivity();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.air_screen_connect, container, false);

        initView(view);

        return view;
    }

    private void initView(View view) {
        // Backgrounds
        mPcImg = view.findViewById(R.id.air_screen_connect_pc_img);
        mPcImgShadow = view.findViewById(R.id.air_screen_connect_pc_img_shadow);
        mConnectContent = (RelativeLayout) view.findViewById(R.id.airscreen_connect_contents);

        // SearchTips
        mSearchTips = (ViewGroup) view.findViewById(R.id.air_screen_connect_search_tip);

        // Searching
        mSearchingGroup = (ViewGroup) view.findViewById(R.id.air_screen_connect_searching_devices);
        mSearchingIcon = (ImageView) view.findViewById(R.id.air_screen_searching_icon);

        // Device found
        mDeviceFoundGroup = (ViewGroup) view.findViewById(R.id.air_screen_connect_device_found);
        mDeviceFoundList = (RecyclerView) view.findViewById(R.id.air_screen_connect_device_found_list);
        mDeviceFoundTitle = (TextView) view.findViewById(R.id.air_screen_connect_device_found_title);
        initDeviceFoundList();

        // Search device
        mSearchDeviceButton = (TextView) view.findViewById(R.id.air_screen_connect_search_device_button);
        mSearchDeviceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isSearchTipsShown) {
                    mPresenter.startSearching();
                    return;
                }
                if (isSearchingShown) {
                    showSearchTips();
                    return;
                }
                if (isDeviceFoundedShown) {
                    ServerInfoManager.getInstance().clearList();
                    showSearchTips();
                    return;
                }
                if (isNoDevicesFoundShown) {
                    //NodeviceFound
                    showSearchTips();
                    return;
                }
            }
        });
    }

    private void initViewsState() {
        if (isSearchTipsShown) {
            showSearchTips();
        }
        if (isSearchingShown) {
            showSearching();
            return;
        }
        if (isDeviceFoundedShown) {
            showFoundDevices(mDevicesFounded);
            return;
        }
        if (isNoDevicesFoundShown) {
            showNotFoundDevice();
            return;
        }
    }

    private void initDeviceFoundList() {
        if (mDevicesFounded == null) {
            mDevicesFounded = new ArrayList<ServerItemBean>();
        }
        mAirScreenFoundListAdapter = new AirScreenFoundListAdapter(getActivity(), mDevicesFounded);
        mAirScreenFoundListItemAnimator = null;
        mDeviceFoundList.setLayoutManager(new LinearLayoutManager(getActivity()));
        mDeviceFoundList.setAdapter(mAirScreenFoundListAdapter);
        mDeviceFoundList.setItemAnimator(mAirScreenFoundListItemAnimator);
        mDeviceFoundList.addItemDecoration(new AirScreenFoundListItemDecoration(getActivity(), DividerItemDecoration.VERTICAL_LIST));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onResume() {
        super.onResume();
        initViewsState();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        stopSearchingIconRotate();
        super.onDestroy();
    }

    @Override
    public void setPresenter(AirScreenConnectContract.Presenter presenter) {
        this.mPresenter = presenter;
    }

    private void changeAllMargin(int pcTopMargin, int pcShadowTopMargin, int bottomMargin, int foundListHeight) {
        changePcImgShadowTopMargin(pcTopMargin, pcShadowTopMargin);
        changeContentBottomMargin(bottomMargin);
        changeFoundListHeight(foundListHeight);
    }

    private void changePcImgShadowTopMargin(int pcTopMargin, int pcShadowTopMargin) {
        GuavaUtil.checkNotNull(mPcImg);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) mPcImg.getLayoutParams();
        FrameLayout.LayoutParams layoutParamsShadow = (FrameLayout.LayoutParams) mPcImgShadow.getLayoutParams();
        layoutParams.topMargin = pcTopMargin;
        layoutParamsShadow.topMargin = pcShadowTopMargin;
        mPcImg.setLayoutParams(layoutParams);
        mPcImgShadow.setLayoutParams(layoutParamsShadow);
    }

    private void changeContentBottomMargin(int bottomMargin) {
        GuavaUtil.checkNotNull(mConnectContent);
        ViewGroup.MarginLayoutParams layoutParams = (ViewGroup.MarginLayoutParams) mConnectContent.getLayoutParams();
        layoutParams.bottomMargin = bottomMargin;
        mConnectContent.setLayoutParams(layoutParams);
    }

    private void changeFoundListHeight(int height) {
        GuavaUtil.checkNotNull(mDeviceFoundList);
        ViewGroup.LayoutParams layoutParams = mDeviceFoundList.getLayoutParams();
        layoutParams.height = height;
        mDeviceFoundList.setLayoutParams(layoutParams);
    }

    private void startSearchingIconRotate() {
        GuavaUtil.checkNotNull(mSearchingIcon);

        int fromRotate = 0;
        int toRotate = 360;
        float pivotX = 0.5f;
        float pivotY = 0.5f;
        int rotateDuration = 2500;

        mSearchIconRotateAnimation = new RotateAnimation(fromRotate, toRotate, Animation.RELATIVE_TO_SELF,
                pivotX, Animation.RELATIVE_TO_SELF, pivotY);
        mSearchIconRotateAnimation.setDuration(rotateDuration);
        mSearchIconRotateAnimation.setInterpolator(new LinearInterpolator());
        mSearchIconRotateAnimation.setRepeatCount(Animation.INFINITE);
        mSearchIconRotateAnimation.setRepeatMode(Animation.RESTART);

        mSearchingIcon.startAnimation(mSearchIconRotateAnimation);
    }

    private void stopSearchingIconRotate() {
        if (mSearchIconRotateAnimation != null) {
            mSearchIconRotateAnimation.cancel();
            mSearchingIcon.clearAnimation();
            mSearchIconRotateAnimation = null;
        }
    }

    private void changeSearchTipsState() {
        if (isSearchingShown || isNoDevicesFoundShown || isDeviceFoundedShown) {
            mSearchTips.setVisibility(View.GONE);
            return;
        }
        if (isSearchTipsShown) {
            mSearchTips.setVisibility(View.VISIBLE);
            return;
        }
    }

    private void changeSearchingState() {
        if (isSearchTipsShown || isNoDevicesFoundShown || isDeviceFoundedShown) {
            mSearchingGroup.setVisibility(View.GONE);
            stopSearchingIconRotate();
            return;
        }
        if (isSearchingShown) {
            mSearchingGroup.setVisibility(View.VISIBLE);
            startSearchingIconRotate();
            return;
        }
    }

    private void changeDeviceFoundState() {
        if (isSearchingShown || isNoDevicesFoundShown || isSearchTipsShown) {
            mDeviceFoundGroup.setVisibility(View.GONE);
            return;
        }
        if (isDeviceFoundedShown) {
            mDeviceFoundGroup.setVisibility(View.VISIBLE);
            int itemCount = mDeviceFoundList.getAdapter().getItemCount();
            LogUtil.d("Devices found : " + itemCount);
            if (mMainActivity == null) {
                throw new NullPointerException("mContext main activity is null");
            }
            Resources res = mMainActivity.getResources();
            if (itemCount <= 0) {
                //Todo catch error
            } else if (itemCount > 0 && itemCount <= 3) {
                switch (itemCount) {
                    case 1: {
                        changeAllMargin(
                                res.getDimensionPixelSize(R.dimen.air_screen_connect_pc_device_found_1_margin_top),
                                res.getDimensionPixelSize(R.dimen.air_screen_connect_pc_device_found_1_shadow_margin_top),
                                res.getDimensionPixelSize(R.dimen.air_screen_connect_content_device_found_1_margin_bottom),
                                res.getDimensionPixelSize(R.dimen.air_screen_connect_device_found_1_list_height)
                        );
                        break;
                    }
                    case 2: {
                        changeAllMargin(
                                res.getDimensionPixelSize(R.dimen.air_screen_connect_pc_device_found_2_margin_top),
                                res.getDimensionPixelSize(R.dimen.air_screen_connect_pc_device_found_2_shadow_margin_top),
                                res.getDimensionPixelSize(R.dimen.air_screen_connect_content_device_found_2_margin_bottom),
                                res.getDimensionPixelSize(R.dimen.air_screen_connect_device_found_2_list_height)
                        );
                        break;
                    }
                    case 3: {
                        changeAllMargin(
                                res.getDimensionPixelSize(R.dimen.air_screen_connect_pc_device_found_3_margin_top),
                                res.getDimensionPixelSize(R.dimen.air_screen_connect_pc_device_found_3_shadow_margin_top),
                                res.getDimensionPixelSize(R.dimen.air_screen_connect_content_device_found_3_margin_bottom),
                                res.getDimensionPixelSize(R.dimen.air_screen_connect_device_found_3_list_height)
                        );
                        break;
                    }
                }
            } else if (itemCount > 3) {
                changeAllMargin(
                        res.getDimensionPixelSize(R.dimen.air_screen_connect_pc_device_found_max_margin_top),
                        res.getDimensionPixelSize(R.dimen.air_screen_connect_pc_device_found_max_shadow_margin_top),
                        res.getDimensionPixelSize(R.dimen.air_screen_connect_content_device_found_max_margin_bottom),
                        res.getDimensionPixelSize(R.dimen.air_screen_connect_device_found_list_max_height)
                );
            }
            return;
        }
    }

    private void resumeAllMarginToOrigin() {
        if (mMainActivity == null) {
            throw new NullPointerException("mContext main activity is null");
        }
        Resources res = mMainActivity.getResources();
        changeAllMargin(
                res.getDimensionPixelSize(R.dimen.air_screen_connect_pc_device_found_1_margin_top),
                res.getDimensionPixelSize(R.dimen.air_screen_connect_pc_device_found_1_shadow_margin_top),
                res.getDimensionPixelSize(R.dimen.air_screen_connect_content_device_found_1_margin_bottom),
                res.getDimensionPixelSize(R.dimen.air_screen_connect_device_found_1_list_height));
    }

    private void changeNoDeviceState() {
        if (isSearchingShown || isSearchTipsShown || isDeviceFoundedShown) {
            return;
        }
        if (isNoDevicesFoundShown) {
            return;
        }
    }

    private void changeSearchDeviceButtonState() {
        if (isSearchTipsShown) {
            mSearchDeviceButton.setText(R.string.air_screen_button_search_device);
            mSearchDeviceButton.setTextColor(getResources().getColor(R.color.color_air_screen_connect_button_search_device));
            mSearchDeviceButton.setBackground(getResources().getDrawable(R.drawable.air_screen_search_device_button_1_state));
            return;
        }
        if (isSearchingShown) {
            mSearchDeviceButton.setText(R.string.air_screen_button_cancel);
            ColorStateList csl = getResources().getColorStateList(R.color.color_air_screen_connect_button_cancel);
            mSearchDeviceButton.setTextColor(csl);
            mSearchDeviceButton.setBackground(getResources().getDrawable(R.drawable.air_screen_search_device_button_2_state));
            return;
        }
        if (isDeviceFoundedShown) {
            mSearchDeviceButton.setText(R.string.air_screen_button_cancel);
            ColorStateList csl = getResources().getColorStateList(R.color.color_air_screen_connect_button_cancel);
            mSearchDeviceButton.setTextColor(csl);
            mSearchDeviceButton.setBackground(getResources().getDrawable(R.drawable.air_screen_search_device_button_2_state));
            return;
        }
        if (isNoDevicesFoundShown) {
            mSearchDeviceButton.setText(R.string.air_screen_button_cancel);
            ColorStateList csl = getResources().getColorStateList(R.color.color_air_screen_connect_button_cancel);
            mSearchDeviceButton.setTextColor(csl);
            mSearchDeviceButton.setBackground(getResources().getDrawable(R.drawable.air_screen_search_device_button_2_state));
            return;
        }
    }

    private void changeAllState() {
        changeSearchDeviceButtonState();
        changeSearchTipsState();
        changeSearchingState();
        changeDeviceFoundState();
        changeNoDeviceState();
    }

    @Override
    public void showSearchTips() {
        isSearchTipsShown = true;
        isDeviceFoundedShown = isNoDevicesFoundShown = isSearchingShown = false;
        resumeAllMarginToOrigin();
        changeAllState();
    }

    @Override
    public void showSearching() {
        isSearchingShown = true;
        isDeviceFoundedShown = isNoDevicesFoundShown = isSearchTipsShown = false;
        resumeAllMarginToOrigin();
        changeAllState();
    }

    @Override
    public void showFoundDevices(List<ServerItemBean> foundDevices) {
        isDeviceFoundedShown = true;
        isSearchTipsShown = isNoDevicesFoundShown = isSearchingShown = false;
        mDevicesFounded = foundDevices;
        if (foundDevices == null || foundDevices.size() == 0) {
            //Todo : if size == 0;
            LogUtil.e("No found devices");
            mAirScreenFoundListAdapter.clearData();
        } else if (foundDevices.size() > 0) {
            LogUtil.e("Found device size " + foundDevices.size());
            mAirScreenFoundListAdapter.changeData(mDevicesFounded);
            int size = mDevicesFounded.size();
            if (size == 1) {
                mDeviceFoundTitle.setText("1 DEVICES FOUND");
            } else {
                mDeviceFoundTitle.setText(size + " DEVICES FOUND");
            }
        }
        changeAllState();
    }

    @Override
    public void showNotFoundDevice() {
        isNoDevicesFoundShown = true;
        isDeviceFoundedShown = isSearchTipsShown = isSearchingShown = false;
        resumeAllMarginToOrigin();
        changeAllState();
    }

    @Override
    public void showCodeCheckDialog(int code) {
        mAirScreenCodeDialog = new AirScreenCodeDialog();
        mAirScreenCodeDialog.setAirScreenConnectView(this);
        mAirScreenCodeDialog.show(mMainActivity.getSupportFragmentManager(), "code_dialog");
    }

    @Override
    public void changeCodeDialogTitle(boolean isTitleNormal) {
        GuavaUtil.checkNotNull(mAirScreenCodeDialog);
        mAirScreenCodeDialog.setTitleNormal(isTitleNormal);
        mAirScreenCodeDialog.changeTitle();
    }

    @Override
    public void dissmissCodeCheckDialog() {
        GuavaUtil.checkNotNull(mAirScreenCodeDialog);
        mAirScreenCodeDialog.dismiss();
        mAirScreenCodeDialog = null;
    }

    @Override
    public void clearCodeDialogText() {
        if (mAirScreenCodeDialog != null) {
            mAirScreenCodeDialog.clearCode();
        }
    }


}
