//Todo copyRight
package xyz.skybox.gui.base.view;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v7.widget.GridLayoutManager;
import android.util.AttributeSet;

import com.amy.inertia.view.ARecyclerView;

import xyz.skybox.gui.view.NpaGridLayoutManager;

public class VideoRecyclerView extends ARecyclerView {

    private NpaGridLayoutManager mGridLayoutManager;
    private int mSpanCount = -1;

    public VideoRecyclerView(Context context) {
        super(context);
        init();
    }

    public VideoRecyclerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public VideoRecyclerView(Context context, @Nullable AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        mGridLayoutManager = new NpaGridLayoutManager(getContext(), 1);
        setLayoutManager(mGridLayoutManager);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        super.onMeasure(widthSpec, heightSpec);

        if (mSpanCount <= 0) {
            throw new IllegalArgumentException("Please assign a span count");
        } else {
            mGridLayoutManager.setSpanCount(mSpanCount);
        }

    }

    public void setScrollEnabled(boolean enabled) {
        mGridLayoutManager.setScrollEnabled(enabled);
    }

    public void setNumColumns(int spanCount) {
        mSpanCount = spanCount;
        mGridLayoutManager.setSpanCount(mSpanCount);
    }

    public void setSpanSizeLookup(GridLayoutManager.SpanSizeLookup spanSizeLookup) {
        mGridLayoutManager.setSpanSizeLookup(spanSizeLookup);
    }

}
