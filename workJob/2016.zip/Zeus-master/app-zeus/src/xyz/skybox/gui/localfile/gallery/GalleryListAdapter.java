package xyz.skybox.gui.localfile.gallery;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.preference.PreferenceManager;
import android.support.annotation.MainThread;
import android.support.annotation.Nullable;
import android.support.v7.util.SortedList;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Locale;

import xyz.skybox.BR;
import xyz.skybox.R;
import xyz.skybox.SkyboxApplication;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.statistic.helper.FabricHelper;
import xyz.skybox.media.MediaDatabase;
import xyz.skybox.media.MediaGroup;
import xyz.skybox.media.MediaWrapper;
import xyz.skybox.util.LaunchHelper;

public class GalleryListAdapter extends RecyclerView.Adapter<GalleryListAdapter.MyViewHolder> {

    // Global
    private Context mContext;

    public static final int SORT_BY_TITLE = 0;
    public static final int SORT_BY_LENGTH = 1;
    public static final int SORT_BY_DATE = 2;

    private boolean isListMode = false;
    private boolean isClickable = true;

    private static final int INFLATE_LAYOUTS_LIST_MODE = R.layout.video_list_item_gallery;
    private static final int INFLATE_LAYOUTS_GRID_MODE = R.layout.video_grid_item_gallery;

    private GalleryListAdapter.VideoComparator mVideoComparator = new GalleryListAdapter.VideoComparator();
    private volatile SortedList<MediaWrapper> mVideos = new SortedList<>(MediaWrapper.class, mVideoComparator);

    private LaunchHelper mLaunchHelper;

    public GalleryListAdapter(boolean isListMode) {
        this.isListMode = isListMode;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        mContext = parent.getContext();
        mLaunchHelper = new LaunchHelper((Activity) mContext);

        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View v = null;

        if (isListMode) {
            v = inflater.inflate(INFLATE_LAYOUTS_LIST_MODE, parent, false);
        } else {
            v = inflater.inflate(INFLATE_LAYOUTS_GRID_MODE, parent, false);
        }

        return new MyViewHolder(v, mContext);
    }

    @Override
    public void onBindViewHolder(GalleryListAdapter.MyViewHolder holder, int position) {
        MediaWrapper media = getItem(position);
        if (media == null) {
            return;
        }

        holder.mFavourButton.setSelected(MediaDatabase.getInstance().favourExists(media.getUri()));
        holder.binding.setVariable(BR.media, media);
        holder.binding.executePendingBindings();
    }

    @MainThread
    public void update(MediaWrapper item) {
        int position = mVideos.indexOf(item);
        if (position != -1) {
            if (!(mVideos.get(position) instanceof MediaGroup))
                mVideos.updateItemAt(position, item);
            notifyItemChanged(position);
        } else {
            position = mVideos.add(item);
            notifyItemRangeChanged(position, mVideos.size() - position);
        }
    }

    public void setClickable(boolean clickable) {
        isClickable = clickable;
    }

    public void clear() {
        mVideos.clear();
    }

    public boolean isEmpty() {
        return mVideos.size() == 0;
    }

    @Nullable
    public MediaWrapper getItem(int position) {
        if (position < 0 || position >= mVideos.size())
            return null;
        else
            return mVideos.get(position);
    }

    public void add(MediaWrapper item) {
        notifyItemInserted(mVideos.add(item));
    }

    @MainThread
    public void remove(int position) {
        if (position == -1)
            return;
        mVideos.removeItemAt(position);
        notifyItemRemoved(position);
    }

    public void addAll(Collection<MediaWrapper> items) {
        mVideos.addAll(items);
    }

    public boolean contains(MediaWrapper mw) {
        return mVideos.indexOf(mw) != -1;
    }

    @Override
    public int getItemCount() {
        return mVideos.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        private ImageView mFavourButton;
        private ImageView mFavourAnim;
        private ViewGroup mCardView;
        private ImageView mShadow;
        private ImageView mThumbnail;

        private Context mContext;
        public ViewDataBinding binding;

        float mScalePressX = 0.95f;
        float mScalePressY = 0.95f;
        Interpolator mPressInterpolator = new LinearInterpolator();
        long mPressTime;
        int mPressDuration = 20;

        final float mScaleReleaseX = 1f;
        final float mScaleReleaseY = 1f;
        Interpolator mReleaseInterpolator = new LinearInterpolator();
        long mReleaseTime;
        long mReleaseDuration;
        final long RELEASE_MAX = 120;

        final AnimatorSet favourAnimatorSet = new AnimatorSet();

        public void setSelected(boolean select) {
            mFavourButton.setSelected(select);
            mFavourAnim.setSelected(select);
        }

        public MyViewHolder(View itemView, Context context) {
            super(itemView);

            mContext = context;
            binding = DataBindingUtil.bind(itemView);
            binding.setVariable(BR.holder, this);
            mFavourButton = (ImageView) itemView.findViewById(R.id.ml_item_favour);
            mFavourAnim = (ImageView) itemView.findViewById(R.id.ml_item_favour_anim);
            mCardView = (ViewGroup) itemView.findViewById(R.id.card_view);
            mShadow = (ImageView) itemView.findViewById(R.id.video_item_shadow);
            mThumbnail = (ImageView) itemView.findViewById(R.id.ml_item_thumbnail);
            initFavourAnimator();
            if (isListMode) {
                mScalePressX = 0.98f;
                mScalePressY = 0.98f;
                mCardView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        switch (event.getAction()) {
                            case MotionEvent.ACTION_DOWN: {
                                LogUtil.d("action down");
                                mPressTime = System.currentTimeMillis();
                                animateOnPress();
                                break;
                            }
                            case MotionEvent.ACTION_UP:
                            case MotionEvent.ACTION_CANCEL: {
                                LogUtil.d("action up");
                                mReleaseTime = System.currentTimeMillis();
                                animateOnRelease();
                                break;
                            }
                        }
                        return false;
                    }
                });
            } else {
                mScalePressX = 0.96f;
                mScalePressY = 0.96f;
                mThumbnail.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        switch (event.getAction()) {
                            case MotionEvent.ACTION_DOWN: {
                                LogUtil.d("action down");
                                mPressTime = System.currentTimeMillis();
                                animateOnPress();
                                break;
                            }
                            case MotionEvent.ACTION_UP:
                            case MotionEvent.ACTION_CANCEL: {
                                LogUtil.d("action up");
                                mReleaseTime = System.currentTimeMillis();
                                animateOnRelease();
                                break;
                            }
                        }
                        return false;
                    }
                });
            }

        }

        private void animateOnPress() {
            mCardView.animate().scaleX(mScalePressX).scaleY(mScalePressY).setDuration(mPressDuration)
                    .setInterpolator(mPressInterpolator)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationCancel(Animator animation) {
                            super.onAnimationCancel(animation);
                            mCardView.setScaleX(mScalePressY);
                            mCardView.setScaleY(mPressDuration);
                        }
                    }).start();
            mShadow
                    .animate().scaleX(mScalePressX).scaleY(mScalePressY).setDuration(mPressDuration)
                    .setInterpolator(mPressInterpolator)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationCancel(Animator animation) {
                            super.onAnimationCancel(animation);
                            mShadow.setScaleX(mScalePressX);
                            mShadow.setScaleY(mScalePressY);
                        }
                    }).start();
        }

        private void animateOnRelease() {
            mReleaseDuration = mReleaseTime - mPressTime;
            if (mReleaseDuration * 2 <= RELEASE_MAX) {
                mReleaseDuration *= 2;
            } else {
                mReleaseDuration = RELEASE_MAX;
            }
            mCardView
                    .animate().scaleX(mScaleReleaseX).scaleY(mScaleReleaseY).setDuration(mReleaseDuration)
                    .setInterpolator(mReleaseInterpolator)
                    .setListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationCancel(Animator animation) {
                            super.onAnimationCancel(animation);
                            mCardView.setScaleX(mScaleReleaseX);
                            mCardView.setScaleY(mScaleReleaseY);
                        }
                    }).start();
            mShadow
                    .animate().scaleX(mScaleReleaseX).scaleY(mScaleReleaseY).setDuration(mReleaseDuration)
                    .setInterpolator(mReleaseInterpolator).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationCancel(Animator animation) {
                    super.onAnimationCancel(animation);
                    mShadow.setScaleX(mScaleReleaseX);
                    mShadow.setScaleY(mScaleReleaseY);
                }
            }).start();
        }

        private void initFavourAnimator() {
            final int duration = 400;
            final float scaleXStart = 1f;
            final float scaleYStart = 1f;
            final float alphaStart = 1f;
            final float scaleXEnd = 2f;
            final float scaleYEnd = 2f;
            final float alphaEnd = 0f;
            ObjectAnimator objectAnimatorScaleX = ObjectAnimator.ofFloat(mFavourAnim, "scaleX", scaleXEnd);
            ObjectAnimator objectAnimatorScaleY = ObjectAnimator.ofFloat(mFavourAnim, "scaleY", scaleYEnd);
            ObjectAnimator objectAnimatorAlpha = ObjectAnimator.ofFloat(mFavourAnim, "alpha", alphaEnd);
            objectAnimatorAlpha.setAutoCancel(true);
            objectAnimatorScaleX.setAutoCancel(true);
            objectAnimatorScaleY.setAutoCancel(true);

            favourAnimatorSet.setDuration(duration);
            favourAnimatorSet.addListener(new AnimatorListenerAdapter() {

                private void start() {
                    boolean selected = mFavourButton.isSelected();
                    final MediaWrapper media = getItem(getAdapterPosition());
                    if (selected) {
                        MediaDatabase.getInstance().deleteFavour(media);
                    } else {
                        MediaDatabase.getInstance().addFavourItem(media);
                    }
                    setSelected(!selected);
                    mFavourAnim.setScaleY(scaleYStart);
                    mFavourAnim.setScaleX(scaleXStart);
                    mFavourAnim.setAlpha(alphaStart);
                    mFavourAnim.setVisibility(View.VISIBLE);
                }

                private void finish() {

                    mFavourAnim.setVisibility(View.GONE);
                    mFavourAnim.setScaleX(scaleXEnd);
                    mFavourAnim.setScaleY(scaleYEnd);
                    mFavourAnim.setAlpha(alphaEnd);

                }

                @Override
                public void onAnimationStart(Animator animation) {
                    super.onAnimationStart(animation);
                    start();
                }

                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    finish();
                }

                @Override
                public void onAnimationCancel(Animator animation) {
                    super.onAnimationCancel(animation);
                    finish();
                }
            });
            favourAnimatorSet.playTogether(objectAnimatorAlpha, objectAnimatorScaleX, objectAnimatorScaleY);
        }

        public void onFavourClick(View v) {
            favourAnimatorSet.start();
        }

        public void onClick(View v) {
            if (isClickable) {
                // Start VR player
                MediaWrapper media = getItem(getAdapterPosition());
                if (media == null) {
                    return;
                }
                mLaunchHelper.launchVR(media.getUri(), "gallery");
            }
        }

    }

    public class VideoComparator extends SortedList.Callback<MediaWrapper> {

        private static final String KEY_SORT_BY = "sort_by";
        private static final String KEY_SORT_DIRECTION = "sort_direction";

        private int mSortDirection;
        private int mSortBy;
        protected SharedPreferences mSettings = PreferenceManager.getDefaultSharedPreferences(SkyboxApplication.getAppContext());

        public VideoComparator() {
            mSortBy = mSettings.getInt(KEY_SORT_BY, SORT_BY_TITLE);
            mSortDirection = mSettings.getInt(KEY_SORT_DIRECTION, 1);
        }

        public int sortDirection(int sortby) {
            if (sortby == mSortBy)
                return mSortDirection;
            else
                return -1;
        }

        public void sortBy(int sortby) {
            switch (sortby) {
                case SORT_BY_TITLE:
                    if (mSortBy == SORT_BY_TITLE)
                        mSortDirection *= -1;
                    else {
                        mSortBy = SORT_BY_TITLE;
                        mSortDirection = 1;
                    }
                    break;
                case SORT_BY_LENGTH:
                    if (mSortBy == SORT_BY_LENGTH)
                        mSortDirection *= -1;
                    else {
                        mSortBy = SORT_BY_LENGTH;
                        mSortDirection *= 1;
                    }
                    break;
                case SORT_BY_DATE:
                    if (mSortBy == SORT_BY_DATE)
                        mSortDirection *= -1;
                    else {
                        mSortBy = SORT_BY_DATE;
                        mSortDirection *= 1;
                    }
                    break;
                default:
                    mSortBy = SORT_BY_TITLE;
                    mSortDirection = 1;
                    break;
            }
            resetSorting();

            SharedPreferences.Editor editor = mSettings.edit();
            editor.putInt(KEY_SORT_BY, mSortBy);
            editor.putInt(KEY_SORT_DIRECTION, mSortDirection);
            editor.apply();
        }

        @Override
        public int compare(MediaWrapper item1, MediaWrapper item2) {
            if (item1 == null)
                return item2 == null ? 0 : -1;
            else if (item2 == null)
                return 1;

            int compare = 0;
            switch (mSortBy) {
                case SORT_BY_TITLE:
                    compare = item1.getTitle().toUpperCase(Locale.ENGLISH).compareTo(
                            item2.getTitle().toUpperCase(Locale.ENGLISH));
                    break;
                case SORT_BY_LENGTH:
                    compare = ((Long) item1.getLength()).compareTo(item2.getLength());
                    break;
                case SORT_BY_DATE:
                    compare = ((Long) item1.getLastModified()).compareTo(item2.getLastModified());
                    break;
            }
            return mSortDirection * compare;
        }

        @Override
        public void onInserted(int position, int count) {
        }

        @Override
        public void onRemoved(int position, int count) {
        }

        @Override
        public void onMoved(int fromPosition, int toPosition) {
        }

        @Override
        public void onChanged(int position, int count) {
        }

        @Override
        public boolean areContentsTheSame(MediaWrapper oldItem, MediaWrapper newItem) {
            return areItemsTheSame(oldItem, newItem);
        }

        @Override
        public boolean areItemsTheSame(MediaWrapper item1, MediaWrapper item2) {
            if (item1 == item2)
                return true;
            if (item1 == null ^ item2 == null)
                return false;
            return item1.equals(item2);
        }
    }

    public int sortDirection(int sortDirection) {
        return mVideoComparator.sortDirection(sortDirection);
    }

    public void sortBy(int sortby) {
        mVideoComparator.sortBy(sortby);
    }

    public void sort() {
        if (!isEmpty())
            try {
                resetSorting();
            } catch (ArrayIndexOutOfBoundsException e) {
                FabricHelper.logException(e);
            } //Exception happening on Android 2.x
    }

    private void resetSorting() {
        ArrayList<MediaWrapper> list = getAll();
        mVideos.clear();
        mVideos.addAll(list);
        notifyItemRangeChanged(0, mVideos.size());
    }

    public ArrayList<MediaWrapper> getAll() {
        int size = mVideos.size();
        ArrayList<MediaWrapper> list = new ArrayList<>(size);
        for (int i = 0; i < size; ++i)
            list.add(mVideos.get(i));
        return list;
    }

    public void setListMode(boolean listMode) {
        isListMode = listMode;
    }

}
