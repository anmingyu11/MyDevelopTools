//Todo copyRight
package xyz.skybox.gui;

import xyz.skybox.interfaces.BasePresenter;
import xyz.skybox.interfaces.BaseView;
import xyz.skybox.gui.airscreen.AirScreenContract;

public interface IMainActivity {

    interface View extends BaseView<AirScreenContract.Presenter> {

        void showSoftInputKeyBoard(final android.view.View view);

        void hideSoftInputKeyBoard(final android.view.View view);

        void setAirScreenUnfoldTitleBar(String deviceName, android.view.View.OnClickListener disconnectListener);

        void changeBottomTabVisual(boolean isVisible);

        void setupFragment(int fragmentId);

    }

    interface Presenter extends BasePresenter {

    }

}
