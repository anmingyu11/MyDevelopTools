//Todo copyright
package xyz.skybox.gui.airscreen.connect;

import android.app.Activity;
import android.app.Dialog;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.ActionMode;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.daimajia.androidanimations.library.BaseViewAnimator;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.nineoldandroids.animation.Animator;
import com.nineoldandroids.animation.AnimatorListenerAdapter;

import xyz.skybox.R;
import xyz.skybox.common.util.GuavaUtil;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.gui.MainActivity;
import xyz.skybox.gui.airscreen.AirScreenNetwork;

public class AirScreenCodeDialog extends DialogFragment {

    private AirScreenConnectContract.View mAirScreenConnectView;

    private MainActivity mMainActivity;

    // The mCode which need to be verified
    private int mCode;
    private boolean isTitleNormal = false;

    private TextView mCancel;
    // Code Group
    private ViewGroup mCodeGroup;
    private TextView mCodeDialogTitle;
    // Code Input controller
    private EditText mInputController;
    private ImageView mCode0;
    private ImageView mCode1;
    private ImageView mCode2;
    private ImageView mCode3;
    private static final int[] CODE_DRAWABLES = new int[]{
            R.drawable.air_screen_code_0, R.drawable.air_screen_code_1,
            R.drawable.air_screen_code_2, R.drawable.air_screen_code_3,
            R.drawable.air_screen_code_4, R.drawable.air_screen_code_5,
            R.drawable.air_screen_code_6, R.drawable.air_screen_code_7,
            R.drawable.air_screen_code_8, R.drawable.air_screen_code_9,
            R.drawable.air_screen_code_dot_hover};

    BaseViewAnimator mShakeAnimator;

    public AirScreenCodeDialog() {
    }

    public void setAirScreenConnectView(AirScreenConnectContract.View view) {
        mAirScreenConnectView = view;
    }

    private boolean hasPostChangeTitleMsg = false;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(STYLE_NO_FRAME, R.style.CodeDialog);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mMainActivity = (MainActivity) activity;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        inflater = getActivity().getLayoutInflater();
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        return inflater.inflate(R.layout.air_screen_code_dialog, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mCodeDialogTitle = (TextView) view.findViewById(R.id.air_screen_code_dialog_title);

        //Code List
        initCodeItems(view);

        // Init input controller
        initInputController(view);

        // Cancel
        initCancel(view);

        mShakeAnimator = Techniques.Shake.getAnimator();
    }

    private void initCancel(View view) {
        mCancel = (TextView) view.findViewById(R.id.air_screen_code_dialog_cancel);
        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    /**
     * This is a literally invisible EditText,
     * so we can use this to control the CodeList drawable show or hide.
     *
     * @param view
     */
    private void initInputController(final View view) {
        mInputController = (EditText) view.findViewById(R.id.air_screen_code_dialog_edit_box_input_control);
        mInputController.setCursorVisible(false);
        mInputController.setInputType(InputType.TYPE_CLASS_NUMBER);
        mInputController.setClickable(false);
        mInputController.setLongClickable(false);
        mInputController.setCustomSelectionActionModeCallback(new ActionMode.Callback() {
            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                return false;
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {

            }
        });
        mInputController.setTextColor(mMainActivity.getResources().getColor(android.R.color.transparent));
        mInputController.addTextChangedListener(new TextWatcher() {
            AirScreenNetwork mNetwork = AirScreenNetwork.getInstance();

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                String codeString = s.toString();
                if (codeString == null) {
                    return;
                }

                int[] codeArray = convertCodeIntToIntArray(codeString);

                // Set code item drawables
                setCodeItemDrawables(codeArray);

                // If code is all inputted then check it.
                // Max length of this EditText is 4, max code is 9999.
                if (codeString.length() == 4) {
                    LogUtil.e("--- amy ---\n" + codeString);

                    //Todo all inputted
                    AirScreenNetwork.State connectState = mNetwork.getConnectState();
                    mNetwork.tryLogin(codeString);
                } else if (codeString.length() >= 0) {
                    // 0 <= code < 1000
                    isTitleNormal = true;
                } else {
                    return;
                }
            }
        });
    }

    public void setTitleNormal(boolean titleNormal) {
        isTitleNormal = titleNormal;
    }

    public void changeTitle() {
        GuavaUtil.checkNotNull(mCodeDialogTitle);
        Resources res = mMainActivity.getResources();
        if (isTitleNormal &&
                mCodeDialogTitle.getText().toString().equals(res.getString(R.string.air_screen_code_dialog_title_wrong))) {
            mCodeDialogTitle.setText(res.getString(R.string.air_screen_code_dialog_title_normal));
            mCodeDialogTitle.setTextColor(mMainActivity.getResources().getColor(R.color.color_air_screen_code_dialog_title_normal));
        } else if (!isTitleNormal) {
            int codeInvalidAnimTime = 600;
            final int changeTitleDelay = 1000;
            mCodeDialogTitle.clearAnimation();
            mCodeDialogTitle.setText(res.getString(R.string.air_screen_code_dialog_title_wrong));
            mCodeDialogTitle.setTextColor(mMainActivity.getResources().getColor(R.color.color_air_screen_code_dialog_title_wrong));
            //For stupid feature if title is normal
            if (!hasPostChangeTitleMsg) {
                YoYo.with(mShakeAnimator)
                        .duration(codeInvalidAnimTime)
                        .interpolate(new AccelerateDecelerateInterpolator())
                        .withListener(new AnimatorListenerAdapter() {
                            @Override
                            public void onAnimationStart(Animator animation) {
                                super.onAnimationStart(animation);
                                clearCode();
                            }

                            @Override
                            public void onAnimationCancel(Animator animation) {
                                super.onAnimationCancel(animation);
                            }

                            @Override
                            public void onAnimationEnd(Animator animation) {
                                super.onAnimationEnd(animation);
                                if (!hasPostChangeTitleMsg) {
                                    mMainActivity.getZeusHandler().postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            changeTitle();
                                            hasPostChangeTitleMsg = false;
                                        }
                                    }, changeTitleDelay);
                                }
                                hasPostChangeTitleMsg = true;
                            }
                        })
                        .playOn(mCodeDialogTitle);
            }
        }
    }

    public void clearCode() {
        mInputController.setText("");
    }

    private void initCodeItems(View view) {
        mCode0 = (ImageView) view.findViewById(R.id.air_screen_code_dialog_code_item1);
        mCode1 = (ImageView) view.findViewById(R.id.air_screen_code_dialog_code_item2);
        mCode2 = (ImageView) view.findViewById(R.id.air_screen_code_dialog_code_item3);
        mCode3 = (ImageView) view.findViewById(R.id.air_screen_code_dialog_code_item4);
        setCodeItemDrawables(new int[]{10, 10, 10, 10});
    }

    @Override
    public void dismiss() {
        mMainActivity.hideSoftInputKeyBoard(mInputController);
        super.dismiss();
    }

    @Override
    public void onDestroy() {
        mMainActivity.hideSoftInputKeyBoard(mInputController);
        super.onDestroy();
    }

    /**
     * Set mCode imageView item to drawable.
     *
     * @param codeArray
     */
    private void setCodeItemDrawables(int[] codeArray) {
        mMainActivity = mMainActivity == null ? mMainActivity = (MainActivity) getActivity() : mMainActivity;
        GuavaUtil.checkNotNull(mMainActivity);

        Resources res = mMainActivity.getResources();
        mCode0.setImageDrawable(res.getDrawable(CODE_DRAWABLES[codeArray[0]]));
        mCode1.setImageDrawable(res.getDrawable(CODE_DRAWABLES[codeArray[1]]));
        mCode2.setImageDrawable(res.getDrawable(CODE_DRAWABLES[codeArray[2]]));
        mCode3.setImageDrawable(res.getDrawable(CODE_DRAWABLES[codeArray[3]]));
    }

    private int convertCodeStringToInt(String codeString) {
        if (TextUtils.isEmpty(codeString)) {
            return -1;
        } else {
            return Integer.valueOf(codeString);
        }
    }

    /**
     * Convert the int string to int array
     *
     * @param codeString
     * @return
     */
    private int[] convertCodeIntToIntArray(String codeString) {
        int code = convertCodeStringToInt(codeString);
        int[] codeArray = new int[]{10, 10, 10, 10};

        if (code < 0) {
            return codeArray;
        }
        int length = codeString.length();
        // Init mCode array.
        if (length == 4) {
            codeArray[0] = code / 1000;
            codeArray[1] = code % 1000 / 100;
            codeArray[2] = code % 1000 % 100 / 10;
            codeArray[3] = code % 1000 % 100 % 10;
        } else if (length == 3) {
            codeArray[0] = code % 1000 / 100;
            codeArray[1] = code % 1000 % 100 / 10;
            codeArray[2] = code % 1000 % 100 % 10;
        } else if (length == 2) {
            codeArray[0] = code % 1000 % 100 / 10;
            codeArray[1] = code % 1000 % 100 % 10;
        } else if (length == 1) {
            codeArray[0] = code;
        } else {
            //Todo if code is 0000
            throw new IllegalArgumentException("The mCode is illegal! or 0000");
        }
        return codeArray;
    }

    @Override
    public void onStart() {
        mMainActivity = mMainActivity == null ? (MainActivity) getActivity() : mMainActivity;
        GuavaUtil.checkNotNull(mMainActivity);

        Resources res = mMainActivity.getResources();
        Dialog dialog = getDialog();
        Window dialogWindow = dialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();

        //int statusBarHeight = AndroidDevices.getStatusBarHeight(mMainActivity);

        // Set layoutparams
        lp.y = res.getDimensionPixelSize(R.dimen.air_screen_code_dialog_marginTop);
        lp.width = res.getDimensionPixelSize(R.dimen.air_screen_code_dialog_width);
        lp.height = res.getDimensionPixelSize(R.dimen.air_screen_code_dialog_height);

        // Set Window params
        //dialogWindow.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        dialogWindow.setGravity(Gravity.CENTER);
        dialogWindow.setAttributes(lp);

        // Set dialog
        dialog.setCanceledOnTouchOutside(false);
        mMainActivity.showSoftInputKeyBoard(mInputController);
        super.onStart();
    }

    public int getCode() {
        return mCode;
    }

    public void setCode(int code) {
        this.mCode = code;
    }

    private boolean isCodeValid(int inputCode) {
        return mCode == inputCode;
    }
}
