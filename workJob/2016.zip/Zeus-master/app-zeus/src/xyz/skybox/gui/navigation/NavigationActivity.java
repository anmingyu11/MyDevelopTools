//Todo copyright
package xyz.skybox.gui.navigation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import xyz.skybox.BR;
import xyz.skybox.R;
import xyz.skybox.gui.FloatingActionBarWrapper;
import xyz.skybox.gui.navigation.favour.FavourGridFragment;
import xyz.skybox.gui.navigation.history.HistoryGridFragment;
import xyz.skybox.gui.swipeback.SwipeBackController;
import xyz.skybox.statistic.helper.FabricHelper;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

public abstract class NavigationActivity extends AppCompatActivity {

    private boolean isBackPressed;
    private boolean isSwipeBack = false;
    private Context mContext;

    private SwipeBackController mSwipeBackController;

    protected Resources mResources;

    private ViewDataBinding mNavigationActivityBinding = null;

    private NavigationMainUiParams mNavigationMainUiParams = null;

    private Fragment mFragment;

    protected abstract Fragment injectFragment();

    protected abstract NavigationMainUiParams injectNavigationMainUiParams();

    protected NavigationMainUiParams getUIParams() {
        return mNavigationMainUiParams;
    }

    protected Drawable getDrawableFromId(int drawableId) {
        return getResources().getDrawable(drawableId);
    }

    protected String getStringFromId(int stringId) {
        return getResources().getString(stringId);
    }

    private RelativeLayout mFloatingActionBar;
    private FloatingActionBarWrapper mFloatingActionBarWrapper;
    private ValueAnimator mFloatingTitleBarPushUpAnimation;
    private ValueAnimator mFloatingTitleBarNotPushUpAnimation;
    private ImageView mTitleBarShadow;
    private ImageView mLeftImageView;
    private ImageView mRightImageView;
    private TextView mTitleTextView;
    private boolean isPushUp = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.navigation_activity);
        mNavigationActivityBinding = DataBindingUtil.setContentView(this, R.layout.navigation_activity);
        init();
    }

    protected void init() {
        mContext = this;
        mResources = getResources();
        mFragment = injectFragment();
        mNavigationMainUiParams = injectNavigationMainUiParams();
        mSwipeBackController =
                SwipeBackController
                        .build(this);

        mSwipeBackController.clearHandleXListener();
        mSwipeBackController.addHandleXListener(new SwipeBackController.HandleXListener() {
            @Override
            public void handleX(float x, float distanceX, float fractionX) {
                if (distanceX > mContext.getResources().getDisplayMetrics().widthPixels / 6 && !isBackPressed) {
                    isSwipeBack = true;
                    onBackPressed();
                }
            }
        });

        mFloatingActionBar = (RelativeLayout) findViewById(R.id.floating_action_bar);
        mTitleBarShadow = (ImageView) findViewById(R.id.title_bar_shadow);
        mTitleTextView = (TextView) findViewById(R.id.textView);
        mRightImageView = (ImageView) findViewById(R.id.right_menu_imageview);
        mLeftImageView = (ImageView) findViewById(R.id.left_menu_imageview);

        isPushUp = false;
        mFloatingActionBarWrapper = new FloatingActionBarWrapper(this, mFloatingActionBar);
        mFloatingActionBarWrapper.setFloatingActionBarAlpha(0f);
        mFloatingTitleBarNotPushUpAnimation = getFloatingActionBarPushDownAnimation();
        mFloatingTitleBarPushUpAnimation = getFloatingActionBarPushUpAnimation();
        /*
        final ViewGroup contentView = (ViewGroup) getWindow().getDecorView();
        Bitmap bitmap = SwipeBackUtil.bytesToBitmap(getIntent().getByteArrayExtra(MainActivity.EXTRA_SCREEN_SHOT));
        mSwipeBackController = SwipeBackController
                .build(this)
                .enableScreenShotBackground(true)
                .setDecorBackgroundDrawable(new BitmapDrawable(bitmap));
        mSwipeBackController.addHandleXListener(new SwipeBackController.HandleXListener() {
            @Override
            public void handleX(float x, float distanceX, float fractionX) {
                contentView.getChildAt(0).setScaleX(0.95f + 0.05f * fractionX);
                contentView.getChildAt(0).setScaleY(0.95f + 0.05f * fractionX);
            }
        });
        */
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshUI();
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_place_holder, mFragment).commit();
    }

    protected void refreshUI() {
        mNavigationActivityBinding.setVariable(BR.activityParam, getUIParams());
        mNavigationActivityBinding.executePendingBindings();
    }

    protected Context getContext() {
        return this;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (mSwipeBackController.processEvent(ev)) {
            return true;
        } else {
            return super.onTouchEvent(ev);
        }
    }

    @Override
    public void onBackPressed() {
        FabricHelper.logCustomEvent(
                "navigation activity : "
                        + this.getLocalClassName()
                        + " finished by SwipeBack : "
                        + isSwipeBack);
        isSwipeBack = false;
        isBackPressed = true;
        finish();
        overridePendingTransition(R.anim.anim_activity_fade_in, R.anim.anim_activity_slide_out_right);
    }

    private ValueAnimator getFloatingActionBarPushUpAnimation() {
        //final String timeValue = "time";
        final String titleBarAlpha = "titleBarAlpha";
        final String titleBarHeight = "titleBarHeight";

        Resources res = mContext.getResources();

        long duration = 100;
        float alphaStart = 0f;
        float alphaEnd = 1f;
        int titleBarStartHeight = res.getDimensionPixelSize(R.dimen.main_top_tab_height_blackBg);
        int titleBarEndHeight = res.getDimensionPixelSize(R.dimen.main_top_tab_height_whiteBg);

        //value holder
        //PropertyValuesHolder timeHolder = PropertyValuesHolder.ofFloat(timeValue, 0f, duration);
        PropertyValuesHolder alphaHolder = PropertyValuesHolder.ofFloat(titleBarAlpha, alphaStart, alphaEnd);
        PropertyValuesHolder titleBarHeightHolder = PropertyValuesHolder.ofInt(titleBarHeight, titleBarStartHeight, titleBarEndHeight);

        ValueAnimator animator = ValueAnimator.ofPropertyValuesHolder(alphaHolder, titleBarHeightHolder);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float alpha = (float) animation.getAnimatedValue(titleBarAlpha);
                int titleBarHeightValue = (int) animation.getAnimatedValue(titleBarHeight);
                mFloatingActionBarWrapper.setFloatingActionBarAlpha(alpha);
                mFloatingActionBarWrapper.setFloatingActionBarHeight(titleBarHeightValue);
            }
        });

        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);

            }
        });
        animator.setDuration(duration);
        return animator;
    }

    private ValueAnimator getFloatingActionBarPushDownAnimation() {
        //final String timeValue = "time";
        final String titleBarAlpha = "titleBarAlpha";
        final String titleBarHeight = "titleBarHeight";

        Resources res = mContext.getResources();

        long duration = 100;
        float alphaStart = 1f;
        float alphaEnd = 0f;
        int titleBarStartHeight = res.getDimensionPixelSize(R.dimen.main_top_tab_height_whiteBg);
        int titleBarEndHeight = res.getDimensionPixelSize(R.dimen.main_top_tab_height_blackBg);

        //value holder
        //PropertyValuesHolder timeHolder = PropertyValuesHolder.ofFloat(timeValue, 0f, duration);
        PropertyValuesHolder alphaHolder = PropertyValuesHolder.ofFloat(titleBarAlpha, alphaStart, alphaEnd);
        PropertyValuesHolder titleBarHeightHolder = PropertyValuesHolder.ofInt(titleBarHeight, titleBarStartHeight, titleBarEndHeight);

        ValueAnimator animator = ValueAnimator.ofPropertyValuesHolder(alphaHolder, titleBarHeightHolder);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float alpha = (float) animation.getAnimatedValue(titleBarAlpha);
                int titleBarHeightValue = (int) animation.getAnimatedValue(titleBarHeight);
                mFloatingActionBarWrapper.setFloatingActionBarAlpha(alpha);
                mFloatingActionBarWrapper.setFloatingActionBarHeight(titleBarHeightValue);
            }
        });

        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
            }
        });
        animator.setDuration(duration);
        return animator;
    }

    /**
     * Just change the title bar color and height and status bar color.
     *
     * @param pushUp
     */
    public void pushUpFloatingActionBar(boolean pushUp, boolean isWithAnim) {
        //LogUtil.printTraceStack("amy where");
        if (pushUp) {
            if (!isPushUp) {
                mTitleBarShadow.setVisibility(VISIBLE);
                setFloatingActionBarPushUp(isWithAnim);
            }
        } else {
            if (isPushUp) {
                mTitleBarShadow.setVisibility(GONE);
                setFloatingActionBarPushDown(isWithAnim);
            }
        }
    }

    private void setFloatingActionBarPushUp(boolean isWithAnim) {
        if (isWithAnim) {
            mFloatingTitleBarPushUpAnimation.cancel();
            mFloatingTitleBarNotPushUpAnimation.cancel();
            mFloatingTitleBarPushUpAnimation.start();
        } else {
            mFloatingActionBar.setBackgroundColor(getResources().getColor(R.color.color_floating_actionbar_up));
            ViewGroup.LayoutParams layoutParams = mFloatingActionBar.getLayoutParams();
            layoutParams.height = getResources().getDimensionPixelSize(R.dimen.main_top_tab_height_whiteBg);
            mFloatingActionBar.setLayoutParams(layoutParams);

        }
        isPushUp = true;
    }

    private void setFloatingActionBarPushDown(boolean isWithAnim) {
        if (isWithAnim) {
            mFloatingTitleBarPushUpAnimation.cancel();
            mFloatingTitleBarNotPushUpAnimation.cancel();
            mFloatingTitleBarNotPushUpAnimation.start();
        } else {
            mFloatingActionBar.setBackgroundColor(getResources().getColor(R.color.color_floating_actionbar_normal));
            ViewGroup.LayoutParams layoutParams = mFloatingActionBar.getLayoutParams();
            layoutParams.height = getResources().getDimensionPixelSize(R.dimen.main_top_tab_height_blackBg);
            mFloatingActionBar.setLayoutParams(layoutParams);
        }
        isPushUp = false;
    }

    public void replaceFavourTitleBar(boolean isWithAnim) {
        FavourGridFragment favourGridFragment = (FavourGridFragment) mFragment;

        //Title
        boolean isPushUp = favourGridFragment.isPushUp();
        pushUpFloatingActionBar(isPushUp, isWithAnim);

        //Title Widget
        if (isPushUp) {
            //Todo set right imageView
            if (favourGridFragment.isListMode()) {
                mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_grid_black));
            } else {
                mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_list_black));
            }
            mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_back_black));
            ColorStateList csl = (ColorStateList) getResources().getColorStateList(R.color.main_tabtitle_top_whitebg);
            mTitleTextView.setTextColor(csl);
        } else {
            //Todo set right imageView
            if (favourGridFragment.isListMode()) {
                mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_grid_white));
            } else {
                mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_list_white));
            }
            mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_back_white));
            ColorStateList csl = (ColorStateList) getResources().getColorStateList(R.color.main_tabtitle_top_blackbg);
            mTitleTextView.setTextColor(csl);
        }
    }

    public void replaceHistoryTitleBar(boolean isWithAnim) {
        HistoryGridFragment historyGridFragment = (HistoryGridFragment) mFragment;
        //Title
        boolean isPushUp = historyGridFragment.isPushUp();
        pushUpFloatingActionBar(isPushUp, isWithAnim);

        //Title Widget
        if (isPushUp) {
            mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_clear_black));
            mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_back_black));
            ColorStateList csl = (ColorStateList) getResources().getColorStateList(R.color.main_tabtitle_top_whitebg);
            mTitleTextView.setTextColor(csl);
        } else {
            mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_clear_white));
            mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_back_white));
            ColorStateList csl = (ColorStateList) getResources().getColorStateList(R.color.main_tabtitle_top_blackbg);
            mTitleTextView.setTextColor(csl);
        }
    }

    public void enableRightIcon(boolean enable) {
        if (enable) {
            mRightImageView.setVisibility(VISIBLE);
        } else {
            mRightImageView.setVisibility(GONE);
        }
    }
}