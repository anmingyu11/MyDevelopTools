package xyz.skybox.gui.airscreen;

import xyz.skybox.common.util.GuavaUtil;

public class AirScreenPresenter implements AirScreenContract.Presenter {

    private final AirScreenNetwork mAirScreenNetwork = AirScreenNetwork.getInstance();

    private final AirScreenContract.View mAirScreenFragment;

    public AirScreenPresenter(AirScreenNetwork mAirScreenNetwork, AirScreenFragment airScreenFragment) {
        mAirScreenNetwork = GuavaUtil.checkNotNull(mAirScreenNetwork);
        mAirScreenFragment = GuavaUtil.checkNotNull(airScreenFragment);
    }

    @Override
    public void start() {

    }
}
