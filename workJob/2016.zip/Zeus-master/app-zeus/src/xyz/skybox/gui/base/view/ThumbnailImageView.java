//Todo copy right
package xyz.skybox.gui.base.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;

import xyz.skybox.R;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.gui.base.drawable.LoadingDrawable;
import xyz.skybox.util.BitmapUtil;

public class ThumbnailImageView extends ImageView {

    private String mThumbnailType;

    private int mThumbnailListWidth;
    private int mThumbnailListHeight;
    private int mThumbnailGridWidth;
    private int mThumbnailGridHeight;

    public ThumbnailImageView(Context context) {
        this(context, null);
    }

    public ThumbnailImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.TypeThumbnailImageView);

        setScaleType(ScaleType.CENTER);

        if (ta != null) {
            mThumbnailType = ta.getString(R.styleable.TypeThumbnailImageView_ThumbnailType);

            if (!mThumbnailType.equals(context.getString(R.string.thumbnail_image_view_type_grid))
                    && !mThumbnailType.equals(context.getString(R.string.thumbnail_image_view_type_list))) {
                throw new IllegalArgumentException("wrong thumbnail type");
            } else {
                mThumbnailGridWidth = context.getResources().getDimensionPixelSize(R.dimen.grid_card_thumb_width);
                mThumbnailGridHeight = context.getResources().getDimensionPixelSize(R.dimen.grid_card_thumb_height);
                mThumbnailListWidth = context.getResources().getDimensionPixelSize(R.dimen.list_card_thumb_width);
                mThumbnailListHeight = context.getResources().getDimensionPixelSize(R.dimen.list_card_thumb_height);
            }
            ta.recycle();
        }
    }

    public ThumbnailImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs);
    }

    public String getThumbnailType() {
        return mThumbnailType;
    }

    public void setThumbnailType(String thumbnailType) {
        mThumbnailType = thumbnailType;
    }

    @Override
    public void setBackground(Drawable background) {
        Bitmap thumbnail;
        if (background instanceof BitmapDrawable) {
            //This is real cover of thumbnail ImageView
            if (mThumbnailType.equals(getContext().getString(R.string.thumbnail_image_view_type_grid))) {
                super.setBackground(background);
            } else if (mThumbnailType.equals(getContext().getString(R.string.thumbnail_image_view_type_list))) {
                thumbnail = BitmapUtil.drawableToBitmap(background);
                Bitmap newThumbnail = null;
                newThumbnail = BitmapUtil.getMyVideoBitmap(thumbnail, mThumbnailListWidth, mThumbnailListHeight);
                super.setBackground(new BitmapDrawable(getResources(), newThumbnail));
            }
        } else {
            super.setBackground(background);
        }
    }

    public void setLoadingImgSrc() {
        setScaleType(ScaleType.CENTER);
        setImageDrawable(new LoadingDrawable(getContext()));
    }

    public void removeLoadingImgSrc() {
        setImageDrawable(null);
    }

    public boolean isLoading() {
        if (getDrawable() instanceof LoadingDrawable) {
            LoadingDrawable loadingDrawable = (LoadingDrawable) getDrawable();
            return loadingDrawable.isRunning();
        } else {
            LogUtil.e("img src is not loadingdrawable");
            return false;
        }
    }

    public void startLoading() {
        if (getDrawable() instanceof LoadingDrawable) {
            LoadingDrawable loadingDrawable = (LoadingDrawable) getDrawable();
            loadingDrawable.start();
        } else {
            LogUtil.e("img src is not loadingdrawable");
        }
    }

    public void stopLoading() {
        if (getDrawable() instanceof LoadingDrawable) {
            LoadingDrawable loadingDrawable = (LoadingDrawable) getDrawable();
            loadingDrawable.stop();
        } else {
            LogUtil.e("img src is not loadingdrawable");
        }
    }
}
