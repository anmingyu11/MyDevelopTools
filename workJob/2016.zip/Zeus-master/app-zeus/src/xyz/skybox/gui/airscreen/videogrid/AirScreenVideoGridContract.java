//Todo Copyright
package xyz.skybox.gui.airscreen.videogrid;

import java.util.List;

import xyz.skybox.interfaces.BasePresenter;
import xyz.skybox.interfaces.BaseView;
import xyz.skybox.repository.airscreen.AirScreenMediaWrapper;

public interface AirScreenVideoGridContract {

    interface View extends BaseView<Presenter> {
        void updateListAndDisplay(List<AirScreenMediaWrapper> airScreenMediaWrappers);
        void addAllAirScreenMediaList(List<AirScreenMediaWrapper> list);
    }

    interface Presenter extends BasePresenter {

        void updateList(List<AirScreenMediaWrapper> airScreenMediaWrappers);

        void getMediaListCallBack();
    }
}
