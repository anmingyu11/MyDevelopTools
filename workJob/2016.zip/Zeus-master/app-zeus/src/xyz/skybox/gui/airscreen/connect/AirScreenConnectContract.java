//Todo Copyright
package xyz.skybox.gui.airscreen.connect;

import xyz.skybox.interfaces.BasePresenter;
import xyz.skybox.interfaces.BaseView;
import xyz.skybox.repository.airscreen.ServerItemBean;
import java.util.List;

public interface AirScreenConnectContract {
    interface View extends BaseView<Presenter> {

        /**
         * Show search tips, and hide others.
         */
        void showSearchTips();

        /**
         * Show searching, and hide others.
         */
        void showSearching();

        /**
         * Show sevices which are founded, and hide others.
         *
         * @param foundDevices
         */
        void showFoundDevices(List<ServerItemBean> foundDevices);

        /**
         * Show no devices found, and hide others.
         */
        void showNotFoundDevice();

        /**
         * Start a dialog which let user input code in pc to login.
         */
        void showCodeCheckDialog(int code);

        void changeCodeDialogTitle(boolean isCodeValid);

        void dissmissCodeCheckDialog();

        void clearCodeDialogText();
    }

    interface Presenter extends BasePresenter {
        /**
         * Start searching device and show devices in list.
         */
        void startSearching();

    }
}
