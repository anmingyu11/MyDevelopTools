//Todo copyright
package xyz.skybox.gui;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.widget.RelativeLayout;

import xyz.skybox.R;

public class FloatingActionBarWrapper {

    private RelativeLayout mFloatingActionBar;
    private GradientDrawable mFloatingActionBarBackground;

    public FloatingActionBarWrapper(Context context,
                                    RelativeLayout floatingActionBar) {
        mFloatingActionBar = floatingActionBar;
        mFloatingActionBarBackground = new GradientDrawable();
        mFloatingActionBarBackground.setColor(context.getResources().getColor(R.color.color_floating_actionbar_up));
        mFloatingActionBarBackground.setAlpha(0);
    }

    public void setFloatingActionBarHeight(int height) {
        mFloatingActionBar.getLayoutParams().height = height;
        mFloatingActionBar.requestLayout();
    }

    public void setFloatingActionBarAlpha(float alpha) {
        int alphaValue = (int) (255 * alpha);
        mFloatingActionBarBackground.setAlpha(alphaValue);
        mFloatingActionBar.setBackground(mFloatingActionBarBackground);
    }

    public int getFloatingActionBarAlpha() {
        return 255 * mFloatingActionBarBackground.getAlpha();
    }

}
