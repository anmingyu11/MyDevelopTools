/*****************************************************************************
 * MainActivity.java
 * ****************************************************************************
 * Copyright © 2011-2014 VLC authors and VideoLAN
 * <p>
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * <p>
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * <p>
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

package xyz.skybox.gui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.FilterQueryProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.jaeger.library.StatusBarUtil;

import java.util.ArrayList;
import java.util.List;

import xyz.skybox.BuildConfig;
import xyz.skybox.R;
import xyz.skybox.common.util.GuavaUtil;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.gui.airscreen.AirScreenContract;
import xyz.skybox.gui.airscreen.AirScreenFragment;
import xyz.skybox.gui.airscreen.AirScreenNetwork;
import xyz.skybox.gui.airscreen.AirScreenTitleBarWrapper;
import xyz.skybox.gui.airscreen.connect.AirScreenConnectContract;
import xyz.skybox.gui.airscreen.connect.AirScreenConnectFragment;
import xyz.skybox.gui.airscreen.connect.AirScreenHelpDialog;
import xyz.skybox.gui.airscreen.videogrid.AirScreenVideoGridFragment;
import xyz.skybox.gui.base.LoadingDialog;
import xyz.skybox.gui.localfile.LocalFilesFragment;
import xyz.skybox.gui.localfile.gallery.GalleryGridFragment;
import xyz.skybox.gui.localfile.myvideo.MyVideoGridFragment;
import xyz.skybox.gui.navigation.favour.FavourActivity;
import xyz.skybox.gui.navigation.history.HistoryActivity;
import xyz.skybox.gui.navigation.setting.SettingActivity;
import xyz.skybox.gui.network.MRLPanelFragment;
import xyz.skybox.gui.view.HackyDrawerLayout;
import xyz.skybox.gui.view.PagerSlidingTabStrip;
import xyz.skybox.interfaces.IRefreshable;
import xyz.skybox.media.MediaDatabase;
import xyz.skybox.media.MediaLibrary;
import xyz.skybox.repository.SharedPreferencesManager;
import xyz.skybox.repository.airscreen.AirScreenMediaWrapper;
import xyz.skybox.repository.airscreen.ServerItemBean;
import xyz.skybox.repository.networkservice.NetworkService;
import xyz.skybox.repository.setting.ZeusSettings;
import xyz.skybox.statistic.helper.FabricHelper;
import xyz.skybox.util.AndroidDevices;
import xyz.skybox.util.LaunchHelper;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static xyz.skybox.media.MediaDatabase.getInstance;
import static xyz.skybox.util.AndroidDevices.initMyVideoDir;

public class MainActivity extends AppCompatActivity implements IMainActivity.View, FilterQueryProvider {
    public final static String TAG = "VLC/MainActivity";

    private MainActivity mMainActivity;

    public static final String EXTRA_SCREEN_SHOT = "ScreenShot";

    public static final int FRAGMENT_LOCAL_FILE = 0;
    public static final int FRAGMENT_AIR_SCREEN = 1;
    public static final int FRAGMENT_ONLINE = 2;
    public static final int FRAGMENT_MY_VIDEOS = 3;
    public static final int FRAGMENT_GALLERY = 4;

    private int mCurrentFragmentId = FRAGMENT_GALLERY;
    /*
     * To save fragment id when u change fragment to history or favour or other,
     * you return to home, show which fragment do you show.
     */
    private int mHomeFragmentIdSave = FRAGMENT_GALLERY;

    private Context mContext;
    MediaLibrary mMediaLibrary;

    private ImageView mTitleBarShadow;

    //Navigation
    private HackyDrawerLayout mDrawerLayout;
    private ViewGroup mNavigationView;
    private ViewGroup mNavigationItemHome;
    private ViewGroup mNavigationItemHistory;
    private ViewGroup mNavigationItemFavourite;
    private ViewGroup mNavigationItemSetting;
    private ViewGroup mNavigationVrMode;

    //Params
    private int mVersionNumber = -1;
    private boolean mScanNeeded = false;
    private boolean isAirScreenTitleBarUnfold = false;
    private boolean isPushUp = false;

    //ZeusHandler
    private ZeusHandler mZeusHandler = new ZeusHandler();

    //Bottom tabs
    private FrameLayout mBottomTabBar;
    private ImageView mBottomMask;
    private ImageView mBottomShadow;
    private ImageView mBottomBarBg;
    private ViewGroup mBottomTabLeft;
    private ViewGroup mBottomTabMiddle;
    private ViewGroup mBottomTabRight;

    //Title menu icon
    private ImageView mLeftImageView;
    private ImageView mRightImageView;
    private View mLeftCLick;
    private View mRightClick;

    //Title
    private PagerSlidingTabStrip mLocalFilesFragmentPagerSlidingTabStrip;
    private RelativeLayout mFloatingActionBar;
    private TextView mMyVideosTitle;
    private TextView mGalleryTitle;
    private TextView mTitleTextView;

    //AirScreenTitle
    private FrameLayout mAirScreenTitleBar;
    private View mAirScreenTitleBarTrigger;
    private ViewGroup mAirScreenTitleBarText;
    private TextView mAirScreenTitleBarMask;
    private TextView mAirScreenTitleBarDisconnect;
    private TextView mAirScreenTitleServerName;

    //Animate
    private ValueAnimator mFloatingTitleBarPushUpAnimation;
    private ValueAnimator mFloatingTitleBarNotPushUpAnimation;
    private ValueAnimator mAirScreenUnfoldAnimation;
    private ValueAnimator mAirScreenDisconnectFoldAnimation;
    private ValueAnimator mAirScreenFoldAnimation;
    private ValueAnimator mAirScreenTitleBarPushUpAnimation;
    private ValueAnimator mAirScreenTitleBarPushDownAnimation;
    private AirScreenTitleBarWrapper mAirScreenTitleBarWrapper;
    private FloatingActionBarWrapper mFloatingActionBarWrapper;

    //Fragments
    private LocalFilesFragment mLocalFilesFragment;
    private AirScreenFragment mAirScreenFragment;
    private GalleryGridFragment mGalleryGridFragment;
    private MyVideoGridFragment mMyVideoGridFragment;
    //Todo online
    private MRLPanelFragment mOnlineFragment;

    SharedPreferencesManager mSharedPreferencesManager;
    //Service Property
    private NetworkService.NetworkBinder mNetworkBinder;
    private ServiceConnection mNetWorkConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mNetworkBinder = (NetworkService.NetworkBinder) service;
            if (SharedPreferencesManager.getInstance(mContext).isNetWorkServiceDestroy()) {
                //Todo if service destroy;
            } else {
                mNetworkBinder.getDownloader().clearDownloadDb();
                SharedPreferencesManager.getInstance(mContext).setNetWorkServiceDestroy(false);
            }
            LogUtil.e("NetWorkServiceConnected");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            LogUtil.e("NetWorkServiceDisconnected");
        }
    };

    private LoadingDialog mLoadingDialog;
    private LaunchHelper mLaunchHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        LogUtil.e("Activity onCreate");

        mMainActivity = this;

        int width = getWindowManager().getDefaultDisplay().getWidth();
        int height = getWindowManager().getDefaultDisplay().getHeight();
        LogUtil.e("width : " + width + " height : " + height);
        LogUtil.d("----- screen param -----\n"
                + " width : " + AndroidDevices.getScreenWidth(this)
                + " height : " + AndroidDevices.getScreenHeight(this));

        mLaunchHelper = new LaunchHelper(this);

        mSharedPreferencesManager = SharedPreferencesManager.getInstance(this);

        bindNetWorkService();

        super.onCreate(savedInstanceState);

        mContext = this;

        ZeusSettings zeusSettings = ZeusSettings.getInstance(this);
        zeusSettings.register();

        StatusBarUtil.setColor(this, getResources().getColor(R.color.color_floating_actionbar_normal));

        AirScreenNetwork.getInstance().setMainActivity(this);

        /* Get the current version from package */
        mVersionNumber = BuildConfig.VERSION_CODE;

        // Init MyVideoDir.
        boolean isDirectoryMake = initMyVideoDir();
        LogUtil.d("MyVideoDirectory Maked: " + isDirectoryMake);

        mMediaLibrary = MediaLibrary.getInstance();

        //Todo guan this is why we have a long time delay in the onCreate
        if (!mMediaLibrary.isWorking() && mMediaLibrary.getMediaItems().isEmpty()) {
            mMediaLibrary.scanMediaItems();
        }

        /*** Start initializing the UI ***/
        setContentView(R.layout.main);

        initView();

        if (savedInstanceState != null) {
            mCurrentFragmentId = savedInstanceState.getInt("current");
        }

        setupNavigationView();

        /* Check if it's the first run */
        if (mSharedPreferencesManager.isFirstRun()) {
            //Todo FirstRun
            mSharedPreferencesManager.setNotFirstRun();
        } else {
        }

        /* Reload the latest preferences */
        reloadPreferences();
    }

    public void bindNetWorkService() {
        if (mNetworkBinder == null) {
            LogUtil.e("bindToNetWorkService");
            Intent intent = new Intent(this, NetworkService.class);
            bindService(intent, mNetWorkConnection, BIND_AUTO_CREATE);
        } else {
            LogUtil.e("Binder has exist");
        }
    }

    public void unbindNetWorkService() {
        unbindService(mNetWorkConnection);
        mNetworkBinder = null;
    }

    public NetworkService.NetworkBinder getNetworkBinder() {
        return mNetworkBinder;
    }

    public int getCurrentFragmentId() {
        return mCurrentFragmentId;
    }

    @Override
    protected void onDestroy() {
        if (mLoadingDialog != null) {
            if (mLoadingDialog.isShowing()) {
                mLoadingDialog.dismiss();
                mLoadingDialog = null;
            } else {
                mLoadingDialog = null;
            }
        }
        unbindNetWorkService();
        ZeusSettings.getInstance(mContext).unRegister();
        super.onDestroy();
        LogUtil.e("Activity onDestroy");
    }

    public ZeusHandler getZeusHandler() {
        return mZeusHandler;
    }

    public void setBottomTabLeftSelected() {
        mBottomTabLeft.setSelected(true);
        mBottomTabMiddle.setSelected(false);
        mBottomTabRight.setSelected(false);
    }

    public void setBottomTabMiddleSelected() {
        mBottomTabLeft.setSelected(false);
        mBottomTabMiddle.setSelected(true);
        mBottomTabRight.setSelected(false);
    }

    public void setBottomTabRightSelected() {
        mBottomTabLeft.setSelected(false);
        mBottomTabMiddle.setSelected(false);
        mBottomTabRight.setSelected(true);
    }

    public void initView() {
        mTitleBarShadow = (ImageView) findViewById(R.id.title_bar_shadow);

        //Navigation
        mDrawerLayout = (HackyDrawerLayout) findViewById(R.id.root_container);
        mNavigationView = (ViewGroup) findViewById(R.id.navigation);

        //Bottom tab
        mBottomBarBg = (ImageView) findViewById(R.id.main_bottom_tab_bar_bg);
        mBottomBarBg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Todo avoid click throw in to recyclerview item
                return;
            }
        });
        mBottomMask = (ImageView) findViewById(R.id.main_bottom_mask);
        mBottomMask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        mBottomShadow = (ImageView) findViewById(R.id.main_bottom_shadow);
        mBottomTabBar = (FrameLayout) findViewById(R.id.main_bottom_tab_bar);
        mBottomTabLeft = (ViewGroup) findViewById(R.id.main_bottom_tab_left);
        mBottomTabLeft.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    FabricHelper.logCustomEvent("click my video tab");
                    setupFragment(FRAGMENT_GALLERY);
                }
                return false;
            }
        });
        mBottomTabMiddle = (ViewGroup) findViewById(R.id.main_bottom_tab_middle);
        mBottomTabMiddle.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    FabricHelper.logCustomEvent("click air screen tab");
                    setupFragment(FRAGMENT_MY_VIDEOS);
                }
                return false;
            }
        });
        mBottomTabRight = (ViewGroup) findViewById(R.id.main_bottom_tab_right);
        mBottomTabRight.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    FabricHelper.logCustomEvent("click gallery tab");
                    setupFragment(FRAGMENT_AIR_SCREEN);
                }
                return false;
            }
        });

        //SlideMenu
        mRightImageView = (ImageView) findViewById(R.id.right_menu_imageview);
        mLeftImageView = (ImageView) findViewById(R.id.left_menu_imageview);
        mRightClick = findViewById(R.id.main_right_image_click);
        mLeftCLick = findViewById(R.id.main_left_image_click);

        //Title
        mFloatingActionBar = (RelativeLayout) findViewById(R.id.floating_action_bar);
        //ClickMask
        findViewById(R.id.floating_action_bar_click_mask).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        findViewById(R.id.main_bottom_click_mask).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
        mFloatingActionBarWrapper = new FloatingActionBarWrapper(this, mFloatingActionBar);
        mFloatingActionBarWrapper.setFloatingActionBarAlpha(0f);
        mFloatingTitleBarNotPushUpAnimation = getFloatingActionBarPushDownAnimation();
        mFloatingTitleBarPushUpAnimation = getFloatingActionBarPushUpAnimation();
        mTitleTextView = (TextView) findViewById(R.id.textView);

        //LocalFiles title
        mLocalFilesFragmentPagerSlidingTabStrip = (PagerSlidingTabStrip) findViewById(R.id.localfiles_tab_strip);
        mGalleryTitle = (TextView) findViewById(R.id.main_titlebar_gallery);
        mMyVideosTitle = (TextView) findViewById(R.id.main_titlebar_myvideos);

        mAirScreenTitleBar = (FrameLayout) findViewById(R.id.air_screen_grid_titlebar);
        mAirScreenTitleBarTrigger = findViewById(R.id.air_screen_grid_titlebar_trigger);
        mAirScreenTitleBarMask = (TextView) findViewById(R.id.air_screen_titlebar_title_maskbg);
        mAirScreenTitleBarDisconnect = (TextView) findViewById(R.id.air_screen_titlebar_disconnect_button);
        mAirScreenTitleBarText = (ViewGroup) findViewById(R.id.air_screen_titlebar_title_text);
        mAirScreenTitleBarWrapper = new AirScreenTitleBarWrapper(
                mContext,
                mAirScreenTitleBar,
                mAirScreenTitleBarText,
                mAirScreenTitleBarMask,
                mAirScreenTitleBarDisconnect,
                mAirScreenTitleBarTrigger
        );
        mAirScreenDisconnectFoldAnimation = getAirScreenTitlebarFoldAnimate(true);
        mAirScreenDisconnectFoldAnimation.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                mAirScreenTitleBarDisconnect.setVisibility(GONE);
                mAirScreenTitleBar.setVisibility(GONE);
                mAirScreenTitleBarTrigger.setVisibility(GONE);
                mZeusHandler.sendEmptyMessage(ZeusHandler.DISCONNECT_BUTTON_CLICKED);
            }
        });
        mAirScreenFoldAnimation = getAirScreenTitlebarFoldAnimate(false);
        mAirScreenFoldAnimation.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                mAirScreenTitleBarDisconnect.setVisibility(GONE);
            }
        });
        mAirScreenUnfoldAnimation = getAirScreenTitlebarUnfoldAnimate();
        mAirScreenTitleBarDisconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAirScreenDisconnectFoldAnimation.start();
            }
        });
        mAirScreenTitleBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isAirScreenTitleBarUnfold) {
                    mAirScreenUnfoldAnimation.start();
                } else {
                    mAirScreenFoldAnimation.start();
                }
            }
        });
        mAirScreenTitleBarTrigger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isAirScreenTitleBarUnfold) {
                    mAirScreenUnfoldAnimation.start();
                } else {
                    mAirScreenFoldAnimation.start();
                }
            }
        });
        //Todo this animation not finished
        mAirScreenTitleBarPushDownAnimation = getAirScreenTitlebarPushDownAnimation();
        mAirScreenTitleBarPushUpAnimation = getAirScreenTitlebarPushUpAnimation();
        mAirScreenTitleServerName = (TextView) findViewById(R.id.air_screen_current_connected_server_name);
        mAirScreenTitleBar.setVisibility(GONE);
        mAirScreenTitleBarTrigger.setVisibility(GONE);
        pushUpFloatingActionBar(false, false);
    }

    //To detact the view is in its range
    private boolean isInRangeOfView(View view, MotionEvent ev) {
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        int x = location[0];
        int y = location[1];
        if (ev.getX() < x
                || ev.getX() > (x + view.getWidth())
                || ev.getY() < y
                || ev.getY() > (y + view.getHeight())) {
            return false;
        }
        return true;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (mAirScreenTitleBar.getVisibility() != GONE && isAirScreenTitleBarUnfold) {
            if (!isInRangeOfView(mAirScreenTitleBar, ev)) {
                mAirScreenFoldAnimation.start();
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    private ValueAnimator getAirScreenTitlebarPushUpAnimation() {
        final String titleBarMarginTop = "titleBarMarginTop";

        final Resources res = mContext.getResources();

        long duration = 100;
        int titleBarStartMarginTop = res.getDimensionPixelSize(R.dimen.air_screen_title_margin_top_push_down);
        final int titleBarEndMarginTop = res.getDimensionPixelSize(R.dimen.air_screen_title_margin_top_push_up);

        //value holder
        //PropertyValuesHolder timeHolder = PropertyValuesHolder.ofFloat(timeValue, 0f, duration);
        PropertyValuesHolder titleBarMarginTopHolder = PropertyValuesHolder.ofInt(titleBarMarginTop, titleBarStartMarginTop, titleBarEndMarginTop);

        ValueAnimator animator = ValueAnimator.ofPropertyValuesHolder(titleBarMarginTopHolder);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                int titleBarMarginTopValue = (int) animation.getAnimatedValue(titleBarMarginTop);
                mAirScreenTitleBarWrapper.setTitleBarTopMargin(titleBarMarginTopValue);
            }
        });

        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                mAirScreenTitleBarWrapper.setPushUp(true);
                mAirScreenTitleBarWrapper.changeColorStylePushUp();
                mAirScreenTitleBarWrapper.setTitleBarTopMargin(titleBarEndMarginTop);
                mAirScreenTitleBarWrapper.setTitleBarTriggerTopMargin(res.getDimensionPixelSize(R.dimen.air_screen_title_trigger_margin_top_push_up));
            }

            @Override
            public void onAnimationCancel(Animator animation) {
                super.onAnimationCancel(animation);
                mAirScreenTitleBarWrapper.setPushUp(true);
                mAirScreenTitleBarWrapper.changeColorStylePushUp();
                mAirScreenTitleBarWrapper.setTitleBarTopMargin(titleBarEndMarginTop);
                mAirScreenTitleBarWrapper.setTitleBarTriggerTopMargin(titleBarEndMarginTop);
                mAirScreenTitleBarWrapper.setTitleBarTriggerTopMargin(res.getDimensionPixelSize(R.dimen.air_screen_title_trigger_margin_top_push_up));
            }
        });
        animator.setDuration(duration);
        return animator;
    }

    private ValueAnimator getAirScreenTitlebarPushDownAnimation() {
        final String titleBarMarginTop = "titleBarMarginTop";

        final Resources res = mContext.getResources();

        long duration = 100;
        final int titleBarEndMarginTop = res.getDimensionPixelSize(R.dimen.air_screen_title_margin_top_push_down);
        int titleBarStartMarginTop = res.getDimensionPixelSize(R.dimen.air_screen_title_margin_top_push_up);

        //value holder
        //PropertyValuesHolder timeHolder = PropertyValuesHolder.ofFloat(timeValue, 0f, duration);
        PropertyValuesHolder titleBarMarginTopHolder = PropertyValuesHolder.ofInt(titleBarMarginTop, titleBarStartMarginTop, titleBarEndMarginTop);

        ValueAnimator animator = ValueAnimator.ofPropertyValuesHolder(titleBarMarginTopHolder);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                int titleBarMarginTopValue = (int) animation.getAnimatedValue(titleBarMarginTop);
                mAirScreenTitleBarWrapper.setTitleBarTopMargin(titleBarMarginTopValue);
            }
        });

        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                mAirScreenTitleBarWrapper.setPushUp(false);
                mAirScreenTitleBarWrapper.changeColorStylePushDown();
                mAirScreenTitleBarWrapper.setTitleBarTopMargin(titleBarEndMarginTop);
                mAirScreenTitleBarWrapper.setTitleBarTriggerTopMargin(res.getDimensionPixelSize(R.dimen.air_screen_title_trigger_margin_top_push_down));
            }

            @Override
            public void onAnimationCancel(Animator animation) {
                super.onAnimationCancel(animation);
                mAirScreenTitleBarWrapper.setPushUp(false);
                mAirScreenTitleBarWrapper.changeColorStylePushDown();
                mAirScreenTitleBarWrapper.setTitleBarTopMargin(titleBarEndMarginTop);
                mAirScreenTitleBarWrapper.setTitleBarTriggerTopMargin(res.getDimensionPixelSize(R.dimen.air_screen_title_trigger_margin_top_push_down));
            }
        });
        animator.setDuration(duration);
        return animator;
    }

    private ValueAnimator getAirScreenTitlebarFoldAnimate(final boolean isDisconnectClick) {
        final String timeValue = "time";
        final String titleBarTextMarginTop = "titleBarTextMarginTop";
        final String titleBarCornerRadius = "titleBarCornerRadius";
        final String titleBarBgWidth = "titleBarBgWidth";
        final String titleBarBgHeight = "titleBarBgHeight";
        final String titleBarMaskWidth = "titleBarMaskWidth";
        final String titleBarMaskHeight = "titleBarMaskHeight";

        Resources res = mContext.getResources();

        //time
        final float duration = 300f;
        final float disconnectDisableTime = 0.51f;
        //final float disableViewTime = 0.51f;

        final int titleBarCornerStartRadius = res.getDimensionPixelSize(R.dimen.air_screen_title_unfold_corner);
        final int titleBarCornerEndRadius = res.getDimensionPixelSize(R.dimen.air_screen_title_fold_corner);

        //titlebar bg
        final int titleBarBgEndWidth = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_bg_start_width);
        final int titleBarBgStartWidth = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_bg_end_width);
        final int titleBarBgEndHeight = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_bg_start_height);
        final int titleBarBgStartHeight = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_bg_end_height);

        //titlebar mask
        final int titleBarMaskEndWidth = titleBarBgEndWidth;
        final int titleBarMaskStartWidth = titleBarBgStartWidth;
        final int titleBarMaskEndHeight = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_mask_bg_start_height);
        final int titleBarMaskStartHeight = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_mask_bg_end_height);

        //titletext marginTop
        int titleTextMarginTopStart = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_text_margin_top);
        final int titleTextMarginTopEnd = 0;

        final int titlBarDisconnetDisableTitlebarHeight = res.getDimensionPixelSize(R.dimen.air_screen_title_disconnect_disable_titlebar_height);

        //value holder
        PropertyValuesHolder timeHolder = PropertyValuesHolder.ofFloat(timeValue, 0f, duration);
        PropertyValuesHolder titleBarCornerRadiusHolder = PropertyValuesHolder.ofFloat(titleBarCornerRadius, titleBarCornerStartRadius, titleBarCornerEndRadius);
        PropertyValuesHolder titleTextMarginTopHolder = PropertyValuesHolder.ofInt(titleBarTextMarginTop, titleTextMarginTopStart,
                titleTextMarginTopEnd);
        PropertyValuesHolder titleBarBgWidthHolder = PropertyValuesHolder.ofInt(titleBarBgWidth, titleBarBgStartWidth, titleBarBgEndWidth);
        PropertyValuesHolder titleBarBgHeightHolder = PropertyValuesHolder.ofInt(titleBarBgHeight, titleBarBgStartHeight, titleBarBgEndHeight);
        PropertyValuesHolder titleBarMaskWidthHolder = PropertyValuesHolder.ofInt(titleBarMaskWidth, titleBarMaskStartWidth, titleBarMaskEndWidth);
        PropertyValuesHolder titleBarMaskHeightHolder = PropertyValuesHolder.ofInt(titleBarMaskHeight, titleBarMaskStartHeight, titleBarMaskEndHeight);

        ValueAnimator animator = ValueAnimator.ofPropertyValuesHolder(
                timeHolder, titleTextMarginTopHolder,
                titleBarBgWidthHolder, titleBarBgHeightHolder,
                titleBarMaskWidthHolder, titleBarMaskHeightHolder,
                titleBarCornerRadiusHolder);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float t = (float) animation.getAnimatedValue(timeValue);
                int textMarginTop = (int) animation.getAnimatedValue(titleBarTextMarginTop);
                int bgWidth = (int) animation.getAnimatedValue(titleBarBgWidth);
                int bgHeight = (int) animation.getAnimatedValue(titleBarBgHeight);
                int maskWidth = (int) animation.getAnimatedValue(titleBarMaskWidth);
                int maskHeight = (int) animation.getAnimatedValue(titleBarMaskHeight);
                float titleBarCorner = (float) animation.getAnimatedValue(titleBarCornerRadius);
                mAirScreenTitleBarWrapper.setTitleBarWidth(bgWidth);
                mAirScreenTitleBarWrapper.setTitleBarHeight(bgHeight);
                mAirScreenTitleBarWrapper.setTitleMaskBgWidth(maskWidth);
                mAirScreenTitleBarWrapper.setTitleMaskBgHeight(maskHeight);
                mAirScreenTitleBarWrapper.setTitleTextTopMargin(textMarginTop);
                mAirScreenTitleBarWrapper.setTitleBarCornerRadius(titleBarCorner);

                //DisconnectButton
                float alpha = 1.0f;
                //100 - 1 / 100
                if (bgHeight > titlBarDisconnetDisableTitlebarHeight) {
                    alpha = (float) (bgHeight - titlBarDisconnetDisableTitlebarHeight)
                            /
                            (float) (titleBarBgStartHeight - titlBarDisconnetDisableTitlebarHeight);
                } else {
                    alpha = 0.0f;
                }
                mAirScreenTitleBarWrapper.setDisconnectButtonAlpha(alpha);

                if (isDisconnectClick) {
                    float titlebarAlpha = 1 - t / duration;
                    float marginPercent = titlebarAlpha;
                    mAirScreenTitleBar.setAlpha(titlebarAlpha);
                }
            }
        });
        animator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                isAirScreenTitleBarUnfold = false;
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                mAirScreenTitleBar.setAlpha(1);
                mAirScreenTitleBarWrapper.setTitleBarWidth(titleBarBgEndWidth);
                mAirScreenTitleBarWrapper.setTitleBarHeight(titleBarBgEndHeight);
                mAirScreenTitleBarWrapper.setTitleMaskBgWidth(titleBarMaskEndWidth);
                mAirScreenTitleBarWrapper.setTitleMaskBgHeight(titleBarMaskEndHeight);
                mAirScreenTitleBarWrapper.setTitleTextTopMargin(titleTextMarginTopEnd);
                mAirScreenTitleBarWrapper.setTitleBarCornerRadius(titleBarCornerEndRadius);
                mAirScreenTitleBarWrapper.setDisconnectButtonAlpha(0.0f);
            }

            @Override
            public void onAnimationCancel(Animator animation) {
                mAirScreenTitleBar.setAlpha(1);
                mAirScreenTitleBarWrapper.setTitleBarWidth(titleBarBgEndWidth);
                mAirScreenTitleBarWrapper.setTitleBarHeight(titleBarBgEndHeight);
                mAirScreenTitleBarWrapper.setTitleMaskBgWidth(titleBarMaskEndWidth);
                mAirScreenTitleBarWrapper.setTitleMaskBgHeight(titleBarMaskEndHeight);
                mAirScreenTitleBarWrapper.setTitleTextTopMargin(titleTextMarginTopEnd);
                mAirScreenTitleBarWrapper.setTitleBarCornerRadius(titleBarCornerEndRadius);
                mAirScreenTitleBarWrapper.setDisconnectButtonAlpha(0.0f);
            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        animator.setDuration((long) duration);
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        return animator;
    }

    private ValueAnimator getAirScreenTitlebarUnfoldAnimate() {
        final String timeValue = "time";
        final String titleBarCornerRadius = "titleBarCornerRadius";
        final String titleBarTextMarginTop = "titleBarTextMarginTop";
        final String titleBarBgWidth = "titleBarBgWidth";
        final String titleBarBgHeight = "titleBarBgHeight";
        final String titleBarMaskWidth = "titleBarMaskWidth";
        final String titleBarMaskHeight = "titleBarMaskHeight";

        final Resources res = mContext.getResources();

        //time
        final float duration = 300f;

        final int titlBarDisconnetShowTitlebarHeight = res.getDimensionPixelSize(R.dimen.air_screen_title_disconnect_show_titlebar_height);

        //titlebar corner radius
        final int titleBarCornerEndRadius = res.getDimensionPixelSize(R.dimen.air_screen_title_unfold_corner);
        final int titleBarCornerStartRadius = res.getDimensionPixelSize(R.dimen.air_screen_title_fold_corner);

        //titlebar bg
        final int titleBarBgStartWidth = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_bg_start_width);
        final int titleBarBgEndWidth = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_bg_end_width);
        final int titleBarBgStartHeight = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_bg_start_height);
        final int titleBarBgEndHeight = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_bg_end_height);

        //titlebar mask
        final int titleBarMaskStartWidth = titleBarBgStartWidth;
        final int titleBarMaskEndWidth = titleBarBgEndWidth;
        final int titleBarMaskStartHeight = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_mask_bg_start_height);
        final int titleBarMaskEndHeight = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_mask_bg_end_height);

        //titletext marginTop
        final int titleTextMarginTopStart = 0;
        final int titleTextMarginTopEnd = res.getDimensionPixelSize(R.dimen.air_screen_titlebar_text_margin_top);

        //value holder
        PropertyValuesHolder timeHolder = PropertyValuesHolder.ofFloat(timeValue, 0f, duration);
        PropertyValuesHolder titleBarCornerRadiusHolder = PropertyValuesHolder.ofFloat(titleBarCornerRadius, titleBarCornerStartRadius,
                titleBarCornerEndRadius);
        PropertyValuesHolder titleTextMarginTopHolder = PropertyValuesHolder.ofInt(titleBarTextMarginTop, titleTextMarginTopStart,
                titleTextMarginTopEnd);
        PropertyValuesHolder titleBarBgWidthHolder = PropertyValuesHolder.ofInt(titleBarBgWidth, titleBarBgStartWidth, titleBarBgEndWidth);
        PropertyValuesHolder titleBarBgHeightHolder = PropertyValuesHolder.ofInt(titleBarBgHeight, titleBarBgStartHeight, titleBarBgEndHeight);
        PropertyValuesHolder titleBarMaskWidthHolder = PropertyValuesHolder.ofInt(titleBarMaskWidth, titleBarMaskStartWidth, titleBarMaskEndWidth);
        PropertyValuesHolder titleBarMaskHeightHolder = PropertyValuesHolder.ofInt(titleBarMaskHeight, titleBarMaskStartHeight, titleBarMaskEndHeight);

        ValueAnimator animator = ValueAnimator.ofPropertyValuesHolder(
                timeHolder, titleTextMarginTopHolder,
                titleBarBgWidthHolder, titleBarBgHeightHolder,
                titleBarMaskWidthHolder, titleBarMaskHeightHolder,
                titleBarCornerRadiusHolder);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float t = (float) animation.getAnimatedValue(timeValue);
                int textMarginTop = (int) animation.getAnimatedValue(titleBarTextMarginTop);
                int bgWidth = (int) animation.getAnimatedValue(titleBarBgWidth);
                int bgHeight = (int) animation.getAnimatedValue(titleBarBgHeight);
                int maskWidth = (int) animation.getAnimatedValue(titleBarMaskWidth);
                int maskHeight = (int) animation.getAnimatedValue(titleBarMaskHeight);
                float titleCorner = (float) animation.getAnimatedValue(titleBarCornerRadius);
                mAirScreenTitleBarWrapper.setTitleBarWidth(bgWidth);
                mAirScreenTitleBarWrapper.setTitleBarHeight(bgHeight);
                mAirScreenTitleBarWrapper.setTitleMaskBgWidth(maskWidth);
                mAirScreenTitleBarWrapper.setTitleMaskBgHeight(maskHeight);
                mAirScreenTitleBarWrapper.setTitleTextTopMargin(textMarginTop);
                mAirScreenTitleBarWrapper.setTitleBarCornerRadius(titleCorner);
                float alpha = 0.0f;
                //100 - 1 / 100
                if (bgHeight > titlBarDisconnetShowTitlebarHeight) {
                    alpha = (float) (bgHeight - titlBarDisconnetShowTitlebarHeight)
                            /
                            (float) (titleBarBgEndHeight - titlBarDisconnetShowTitlebarHeight);
                }
                mAirScreenTitleBarWrapper.setDisconnectButtonAlpha(alpha);
            }
        });
        animator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                mAirScreenTitleBarWrapper.setDisconnectButtonBackgroundAlpha(0f);
                mAirScreenTitleBarDisconnect.setVisibility(GONE);
                isAirScreenTitleBarUnfold = true;
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                mAirScreenTitleBar.setAlpha(1);
                mAirScreenTitleBarWrapper.setTitleBarWidth(titleBarBgEndWidth);
                mAirScreenTitleBarWrapper.setTitleBarHeight(titleBarBgEndHeight);
                mAirScreenTitleBarWrapper.setTitleMaskBgWidth(titleBarMaskEndWidth);
                mAirScreenTitleBarWrapper.setTitleMaskBgHeight(titleBarMaskEndHeight);
                mAirScreenTitleBarWrapper.setTitleTextTopMargin(titleTextMarginTopEnd);
                mAirScreenTitleBarWrapper.setTitleBarCornerRadius(titleBarCornerEndRadius);
                mAirScreenTitleBarWrapper.setDisconnectButtonAlpha(1f);
            }

            @Override
            public void onAnimationCancel(Animator animation) {
                mAirScreenTitleBar.setAlpha(1);
                mAirScreenTitleBarWrapper.setTitleBarWidth(titleBarBgEndWidth);
                mAirScreenTitleBarWrapper.setTitleBarHeight(titleBarBgEndHeight);
                mAirScreenTitleBarWrapper.setTitleMaskBgWidth(titleBarMaskEndWidth);
                mAirScreenTitleBarWrapper.setTitleMaskBgHeight(titleBarMaskEndHeight);
                mAirScreenTitleBarWrapper.setTitleTextTopMargin(titleTextMarginTopEnd);
                mAirScreenTitleBarWrapper.setTitleBarCornerRadius(titleBarCornerEndRadius);
                mAirScreenTitleBarWrapper.setDisconnectButtonAlpha(1f);
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
            }
        });
        animator.setDuration((long) duration);
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        return animator;
    }

    /**
     * @param fragmentId
     */
    @Override
    public void setupFragment(int fragmentId) {
        int updateTitleBarDelayed = 50;
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        Fragment currentFragment = getFragment(mCurrentFragmentId);
        switch (fragmentId) {
            case FRAGMENT_MY_VIDEOS: {
                mMyVideoGridFragment = (MyVideoGridFragment) getFragment(FRAGMENT_MY_VIDEOS);
                if (currentFragment != null) {
                    transaction.hide(currentFragment);
                }
                if (!mMyVideoGridFragment.isAdded()) {
                    transaction.add(R.id.main_fragment_container, mMyVideoGridFragment, getTag(FRAGMENT_MY_VIDEOS));
                }
                transaction.show(mMyVideoGridFragment).commit();
                mHomeFragmentIdSave = FRAGMENT_MY_VIDEOS;
                changeBottomTabVisual(true);
                setBottomTabMiddleSelected();
                mCurrentFragmentId = fragmentId;
                replaceTitleBar(false);
                break;
            }
            case FRAGMENT_GALLERY: {
                mGalleryGridFragment = (GalleryGridFragment) getFragment(FRAGMENT_GALLERY);
                if (currentFragment != null) {
                    transaction.hide(currentFragment);
                }
                if (!mGalleryGridFragment.isAdded()) {
                    transaction.add(R.id.main_fragment_container, mGalleryGridFragment, getTag(FRAGMENT_GALLERY));
                }
                transaction.show(mGalleryGridFragment).commit();
                mHomeFragmentIdSave = FRAGMENT_GALLERY;
                changeBottomTabVisual(true);
                setBottomTabLeftSelected();
                mCurrentFragmentId = fragmentId;
                replaceTitleBar(false);
                break;
            }
            case FRAGMENT_LOCAL_FILE: {
                mLocalFilesFragment = (LocalFilesFragment) getFragment(FRAGMENT_LOCAL_FILE);
                if (currentFragment != null) {
                    transaction.hide(currentFragment);
                }
                if (!mLocalFilesFragment.isAdded()) {
                    transaction.add(R.id.main_fragment_container, mLocalFilesFragment, getTag(FRAGMENT_LOCAL_FILE));
                }
                transaction.show(mLocalFilesFragment).commit();
                mHomeFragmentIdSave = FRAGMENT_LOCAL_FILE;
                changeBottomTabVisual(true);
                setBottomTabLeftSelected();
                mCurrentFragmentId = fragmentId;
                replaceTitleBar(false);
                break;
            }
            case FRAGMENT_AIR_SCREEN: {
                mAirScreenFragment = (AirScreenFragment) getFragment(FRAGMENT_AIR_SCREEN);
                if (currentFragment != null) {
                    transaction.hide(currentFragment);
                }
                if (!mAirScreenFragment.isAdded()) {
                    transaction.add(R.id.main_fragment_container, mAirScreenFragment, getTag(FRAGMENT_AIR_SCREEN));
                }
                transaction.show(mAirScreenFragment).commit();
                mHomeFragmentIdSave = FRAGMENT_AIR_SCREEN;
                changeBottomTabVisual(true);
                setBottomTabRightSelected();
                mCurrentFragmentId = fragmentId;
                replaceTitleBar(false);
                break;
            }
            case FRAGMENT_ONLINE: {
                mOnlineFragment = (MRLPanelFragment) getFragment(FRAGMENT_ONLINE);
                if (currentFragment != null) {
                    transaction.hide(currentFragment);
                }
                if (!mOnlineFragment.isAdded()) {
                    transaction.add(R.id.main_fragment_container, mOnlineFragment, getTag(FRAGMENT_ONLINE));
                }
                transaction.show(mOnlineFragment).commit();
                mHomeFragmentIdSave = FRAGMENT_ONLINE;
                changeBottomTabVisual(true);
                setBottomTabRightSelected();
                mCurrentFragmentId = fragmentId;
                replaceTitleBar(false);
                break;
            }
        }
    }

    public void replaceTitleBar(final boolean isWithAnim) {
        LogUtil.d("replaceTitleBar with anim : " + isWithAnim);
        mZeusHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    switch (mCurrentFragmentId) {
                        case FRAGMENT_LOCAL_FILE: {
                            replaceLocalTitleBar(isWithAnim);
                            mLeftCLick.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    mDrawerLayout.openDrawer(mNavigationView);
                                }
                            });
                            mRightClick.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //Todo show dict2
                                }
                            });
                            break;
                        }
                        case FRAGMENT_AIR_SCREEN: {
                            replaceAirScreenTitleBar(isWithAnim);
                            mLeftCLick.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    mDrawerLayout.openDrawer(mNavigationView);
                                }
                            });
                            mRightClick.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (mAirScreenFragment.getCurrentFragmentId() == AirScreenFragment.FRAGMENT_CONNECT) {
                                        new AirScreenHelpDialog().show(getSupportFragmentManager(), "help_dialog");
                                    } else if (mAirScreenFragment.getCurrentFragmentId() == AirScreenFragment.FRAGMENT_GRID) {
                                        mAirScreenFragment.getAirScreenVideoGridFragment().setAndUpdateListMode();
                                        replaceAirScreenTitleBar(false);
                                    } else {
                                        throw new IllegalArgumentException();
                                    }
                                }
                            });
                            break;
                        }
                        case FRAGMENT_ONLINE: {
                            replaceOnlineTitleBar(isWithAnim);
                            mLeftCLick.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    mDrawerLayout.openDrawer(mNavigationView);
                                }
                            });
                            mRightClick.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //Todo online
                                }
                            });
                            break;
                        }
                        case FRAGMENT_GALLERY: {
                            replaceGalleryTitleBar(isWithAnim);
                            mLeftCLick.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    mDrawerLayout.openDrawer(mNavigationView);
                                }
                            });
                            mRightClick.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    mGalleryGridFragment.setAndUpdateListMode();
                                    replaceGalleryTitleBar(false);
                                }
                            });
                            break;
                        }
                        case FRAGMENT_MY_VIDEOS: {
                            replaceMyVideoTitleBar(isWithAnim);
                            mLeftCLick.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    mDrawerLayout.openDrawer(mNavigationView);
                                }
                            });
                            mRightClick.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    mMyVideoGridFragment.setAndUpdateListMode();
                                    replaceMyVideoTitleBar(false);
                                }
                            });
                            break;
                        }
                    }
                } catch (Exception e) {
                    FabricHelper.logException(e);
                    e.printStackTrace();
                }
            }
        }, 50);
    }

    public void replaceAirScreenTitleBar(boolean isWithAnim) {
        if (mCurrentFragmentId != FRAGMENT_AIR_SCREEN) {
            return;
        }
        //LogUtil.printTraceStack("");
        GuavaUtil.checkNotNull(mAirScreenFragment);

        int currentFragmentId = mAirScreenFragment.getCurrentFragmentId();
        //Title
        mLocalFilesFragmentPagerSlidingTabStrip.setVisibility(GONE);
        if (currentFragmentId == AirScreenFragment.FRAGMENT_CONNECT) {
            mTitleTextView.setVisibility(VISIBLE);
            mAirScreenTitleBarTrigger.setVisibility(GONE);
            mAirScreenTitleBar.setVisibility(GONE);
            mTitleTextView.setText(getString(R.string.title_air_screen));
            mRightImageView.setVisibility(VISIBLE);
            ColorStateList csl = getResources().getColorStateList(R.color.main_tabtitle_top_blackbg);
            mTitleTextView.setTextColor(csl);
        } else if (currentFragmentId == AirScreenFragment.FRAGMENT_GRID) {
            mTitleTextView.setVisibility(GONE);
            mAirScreenTitleBarTrigger.setVisibility(VISIBLE);
            mAirScreenTitleBar.setVisibility(VISIBLE);
            mRightImageView.setVisibility(VISIBLE);
        } else {
            throw new IllegalArgumentException("Illegal air screen fragment id");
        }

        boolean isPushUp = mAirScreenFragment.isPushUp();
        //LogUtil.d("AirScreenFragment isPushUp : " + mAirScreenFragment.isPushUp());
        pushUpFloatingActionBar(isPushUp, isWithAnim);
        //Title Widget
        if (currentFragmentId == AirScreenFragment.FRAGMENT_CONNECT) {
            //Connect
            mRightImageView.setBackground(getResources().getDrawable(R.drawable.air_screen_titlebar_help_white));
            mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_menu_white));
        } else if (currentFragmentId == AirScreenFragment.FRAGMENT_GRID) {
            //Grid
            if (isPushUp) {
                if (!mAirScreenTitleBarWrapper.isPushUp()) {
                    if (isWithAnim) {
                        mAirScreenFoldAnimation.cancel();
                        mAirScreenUnfoldAnimation.cancel();
                        mAirScreenTitleBarPushUpAnimation.cancel();
                        mAirScreenTitleBarPushDownAnimation.cancel();
                        mAirScreenTitleBarPushUpAnimation.start();
                    } else {
                        mAirScreenFoldAnimation.cancel();
                        mAirScreenUnfoldAnimation.cancel();
                        mAirScreenTitleBarPushUpAnimation.cancel();
                        mAirScreenTitleBarPushDownAnimation.cancel();
                        mAirScreenTitleBarWrapper.setPushUp(true);
                        mAirScreenTitleBarWrapper.setTitleBarTopMargin(getResources().getDimensionPixelSize(R.dimen.air_screen_title_margin_top_push_up));
                        mAirScreenTitleBarWrapper.setTitleBarTriggerTopMargin(getResources()
                                .getDimensionPixelSize(R.dimen.air_screen_title_trigger_margin_top_push_up));
                    }
                }

                if (mAirScreenFragment.getAirScreenVideoGridFragment().isListMode()) {
                    mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_grid_black));
                } else {
                    mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_list_black));
                }
                mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_menu_black));
            } else {
                if (mAirScreenTitleBarWrapper.isPushUp()) {
                    if (isWithAnim) {
                        mAirScreenFoldAnimation.cancel();
                        mAirScreenUnfoldAnimation.cancel();
                        mAirScreenTitleBarPushUpAnimation.cancel();
                        mAirScreenTitleBarPushDownAnimation.cancel();
                        mAirScreenTitleBarPushDownAnimation.start();
                    } else {
                        mAirScreenFoldAnimation.cancel();
                        mAirScreenUnfoldAnimation.cancel();
                        mAirScreenTitleBarPushUpAnimation.cancel();
                        mAirScreenTitleBarPushDownAnimation.cancel();
                        mAirScreenTitleBarWrapper.setPushUp(false);
                        mAirScreenTitleBarWrapper.setTitleBarTopMargin(getResources().getDimensionPixelSize(R.dimen.air_screen_title_margin_top_push_down));
                        mAirScreenTitleBarWrapper.setTitleBarTriggerTopMargin(getResources()
                                .getDimensionPixelSize(R.dimen.air_screen_title_trigger_margin_top_push_down));
                    }
                }
                if (mAirScreenFragment.getAirScreenVideoGridFragment().isListMode()) {
                    mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_grid_white));
                } else {
                    mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_list_white));
                }
                mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_menu_white));
            }
        } else {
            throw new IllegalArgumentException("Illegal air screen fragment id");
        }

    }

    public void replaceMyVideoTitleBar(boolean isWithAnim) {
        if (mCurrentFragmentId != FRAGMENT_MY_VIDEOS) {
            return;
        }
        GuavaUtil.checkNotNull(mMyVideoGridFragment);

        //Title
        mAirScreenTitleBar.setVisibility(GONE);
        mAirScreenTitleBarTrigger.setVisibility(GONE);
        mLocalFilesFragmentPagerSlidingTabStrip.setVisibility(GONE);
        mTitleTextView.setVisibility(VISIBLE);
        mTitleTextView.setText(R.string.title_my_videos);
        mRightImageView.setVisibility(VISIBLE);

        boolean isPushUp = mMyVideoGridFragment.isPushUp();
        pushUpFloatingActionBar(isPushUp, isWithAnim);

        //Title Widget
        if (isPushUp) {
            if (!mMyVideoGridFragment.isListMode()) {
                mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_list_black));
            } else {
                mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_grid_black));
            }
            //mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_add_black));
            mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_menu_black));
            ColorStateList csl = getResources().getColorStateList(R.color.main_tabtitle_top_whitebg);
            mTitleTextView.setTextColor(csl);
        } else {
            if (!mMyVideoGridFragment.isListMode()) {
                mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_list_white));
            } else {
                mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_grid_white));
            }
            //mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_add_white));
            mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_menu_white));
            ColorStateList csl = getResources().getColorStateList(R.color.main_tabtitle_top_blackbg);
            mTitleTextView.setTextColor(csl);
        }
    }

    public void replaceGalleryTitleBar(boolean isWithAnim) {
        if (mCurrentFragmentId != FRAGMENT_GALLERY) {
            return;
        }
        GuavaUtil.checkNotNull(mGalleryGridFragment);

        //Title
        mAirScreenTitleBar.setVisibility(GONE);
        mAirScreenTitleBarTrigger.setVisibility(GONE);
        mLocalFilesFragmentPagerSlidingTabStrip.setVisibility(GONE);
        mTitleTextView.setVisibility(VISIBLE);
        mRightImageView.setVisibility(VISIBLE);
        mTitleTextView.setText(R.string.title_gallery);

        boolean isPushUp = mGalleryGridFragment.isPushUp();
        pushUpFloatingActionBar(isPushUp, isWithAnim);

        //Title Widget
        if (isPushUp) {
            if (!mGalleryGridFragment.isListMode()) {
                mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_list_black));
            } else {
                mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_grid_black));
            }
            //mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_add_black));
            mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_menu_black));
            ColorStateList csl = getResources().getColorStateList(R.color.main_tabtitle_top_whitebg);
            mTitleTextView.setTextColor(csl);
        } else {
            if (!mGalleryGridFragment.isListMode()) {
                mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_list_white));
            } else {
                mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_grid_white));
            }
            //mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_add_white));
            mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_menu_white));
            ColorStateList csl = getResources().getColorStateList(R.color.main_tabtitle_top_blackbg);
            mTitleTextView.setTextColor(csl);
        }
    }

    public void replaceLocalTitleBar(boolean isWithAnim) {
        GuavaUtil.checkNotNull(mLocalFilesFragment);

        //Title
        mAirScreenTitleBar.setVisibility(GONE);
        mAirScreenTitleBarTrigger.setVisibility(GONE);
        mTitleTextView.setVisibility(GONE);
        mRightImageView.setVisibility(VISIBLE);
        mLocalFilesFragmentPagerSlidingTabStrip.setVisibility(VISIBLE);

        boolean isPushUp = mLocalFilesFragment.isPushUp();
        pushUpFloatingActionBar(isPushUp, isWithAnim);

        //Title Widget
        if (isPushUp) {
            mLocalFilesFragmentPagerSlidingTabStrip.setSlidingBlockDrawable(
                    getResources().getDrawable(R.drawable.home_titlebar_local_tab_black));
            mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_add_black));
            mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_menu_black));
            ColorStateList csl = getResources().getColorStateList(R.color.main_tabtitle_top_whitebg);
            mMyVideosTitle.setTextColor(csl);
            mGalleryTitle.setTextColor(csl);
        } else {
            mLocalFilesFragmentPagerSlidingTabStrip.setSlidingBlockDrawable(
                    getResources().getDrawable(R.drawable.home_titlebar_local_tab_white));
            mRightImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_add_white));
            mLeftImageView.setBackground(getResources().getDrawable(R.drawable.home_titlebar_menu_white));
            ColorStateList csl = getResources().getColorStateList(R.color.main_tabtitle_top_blackbg);
            mMyVideosTitle.setTextColor(csl);
            mGalleryTitle.setTextColor(csl);
        }

    }

    public void replaceOnlineTitleBar(boolean isWithAnim) {
        GuavaUtil.checkNotNull(mOnlineFragment);
        //TitleBar State
        pushUpFloatingActionBar(false, isWithAnim);

        //Title
        mRightImageView.setVisibility(View.GONE);
        mAirScreenTitleBar.setVisibility(GONE);
        mAirScreenTitleBarTrigger.setVisibility(GONE);
        mLocalFilesFragmentPagerSlidingTabStrip.setVisibility(GONE);
        mTitleTextView.setVisibility(VISIBLE);
        mTitleTextView.setText(R.string.title_online);

        //Todo Title Widget

    }

    public void setViewPagerForLocalFilesTabStrip(ViewPager viewPager) {
        if (mLocalFilesFragmentPagerSlidingTabStrip != null) {
            mLocalFilesFragmentPagerSlidingTabStrip.setViewPager(viewPager);
        }
    }

    /**
     * Just change the title bar color and height and status bar color.
     *
     * @param pushUp
     */
    public void pushUpFloatingActionBar(boolean pushUp, boolean isWithAnim) {
        //LogUtil.printTraceStack("amy where");
        if (pushUp) {
            if (!isPushUp) {
                mTitleBarShadow.setVisibility(VISIBLE);
                setFloatingActionBarPushUp(isWithAnim);
            }
        } else {
            if (isPushUp) {
                mTitleBarShadow.setVisibility(GONE);
                setFloatingActionBarPushDown(isWithAnim);
            }
        }
    }

    private void setFloatingActionBarPushUp(boolean isWithAnim) {
        if (isWithAnim) {
            mFloatingTitleBarPushUpAnimation.cancel();
            mFloatingTitleBarNotPushUpAnimation.cancel();
            mFloatingTitleBarPushUpAnimation.start();
        } else {
            mFloatingActionBar.setBackgroundColor(getResources().getColor(R.color.color_floating_actionbar_up));
            ViewGroup.LayoutParams layoutParams = mFloatingActionBar.getLayoutParams();
            layoutParams.height = getResources().getDimensionPixelSize(R.dimen.main_top_tab_height_whiteBg);
            mFloatingActionBar.setLayoutParams(layoutParams);

        }
        isPushUp = true;
    }

    private void setFloatingActionBarPushDown(boolean isWithAnim) {
        if (isWithAnim) {
            mFloatingTitleBarPushUpAnimation.cancel();
            mFloatingTitleBarNotPushUpAnimation.cancel();
            mFloatingTitleBarNotPushUpAnimation.start();
        } else {
            mFloatingActionBar.setBackgroundColor(getResources().getColor(R.color.color_floating_actionbar_normal));
            ViewGroup.LayoutParams layoutParams = mFloatingActionBar.getLayoutParams();
            layoutParams.height = getResources().getDimensionPixelSize(R.dimen.main_top_tab_height_blackBg);
            mFloatingActionBar.setLayoutParams(layoutParams);
        }
        isPushUp = false;
    }

    private ValueAnimator getFloatingActionBarPushUpAnimation() {
        //final String timeValue = "time";
        final String titleBarAlpha = "titleBarAlpha";
        final String titleBarHeight = "titleBarHeight";

        Resources res = mContext.getResources();

        long duration = 100;
        float alphaStart = 0f;
        float alphaEnd = 1f;
        int titleBarStartHeight = res.getDimensionPixelSize(R.dimen.main_top_tab_height_blackBg);
        int titleBarEndHeight = res.getDimensionPixelSize(R.dimen.main_top_tab_height_whiteBg);

        //value holder
        //PropertyValuesHolder timeHolder = PropertyValuesHolder.ofFloat(timeValue, 0f, duration);
        PropertyValuesHolder alphaHolder = PropertyValuesHolder.ofFloat(titleBarAlpha, alphaStart, alphaEnd);
        PropertyValuesHolder titleBarHeightHolder = PropertyValuesHolder.ofInt(titleBarHeight, titleBarStartHeight, titleBarEndHeight);

        ValueAnimator animator = ValueAnimator.ofPropertyValuesHolder(alphaHolder, titleBarHeightHolder);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float alpha = (float) animation.getAnimatedValue(titleBarAlpha);
                int titleBarHeightValue = (int) animation.getAnimatedValue(titleBarHeight);
                mFloatingActionBarWrapper.setFloatingActionBarAlpha(alpha);
                mFloatingActionBarWrapper.setFloatingActionBarHeight(titleBarHeightValue);
            }
        });

        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);

            }
        });
        animator.setDuration(duration);
        return animator;
    }

    private ValueAnimator getFloatingActionBarPushDownAnimation() {
        //final String timeValue = "time";
        final String titleBarAlpha = "titleBarAlpha";
        final String titleBarHeight = "titleBarHeight";

        Resources res = mContext.getResources();

        long duration = 100;
        float alphaStart = 1f;
        float alphaEnd = 0f;
        int titleBarStartHeight = res.getDimensionPixelSize(R.dimen.main_top_tab_height_whiteBg);
        int titleBarEndHeight = res.getDimensionPixelSize(R.dimen.main_top_tab_height_blackBg);

        //value holder
        //PropertyValuesHolder timeHolder = PropertyValuesHolder.ofFloat(timeValue, 0f, duration);
        PropertyValuesHolder alphaHolder = PropertyValuesHolder.ofFloat(titleBarAlpha, alphaStart, alphaEnd);
        PropertyValuesHolder titleBarHeightHolder = PropertyValuesHolder.ofInt(titleBarHeight, titleBarStartHeight, titleBarEndHeight);

        ValueAnimator animator = ValueAnimator.ofPropertyValuesHolder(alphaHolder, titleBarHeightHolder);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float alpha = (float) animation.getAnimatedValue(titleBarAlpha);
                int titleBarHeightValue = (int) animation.getAnimatedValue(titleBarHeight);
                mFloatingActionBarWrapper.setFloatingActionBarAlpha(alpha);
                mFloatingActionBarWrapper.setFloatingActionBarHeight(titleBarHeightValue);
            }
        });

        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
            }
        });
        animator.setDuration(duration);
        return animator;
    }

    private void startNavigationActivityWithScreenShot(Class<?> cls) {
        Intent intent = new Intent();
        //Bitmap bitmap = SwipeBackUtil.takeScreenShot(mMainActivity);
        //byte[] bytes = SwipeBackUtil.bitmapToBytes(bitmap);
        //intent.putExtra(EXTRA_SCREEN_SHOT, bytes);
        intent.setClass(mMainActivity, cls);
        startActivity(intent);
        overridePendingTransition(R.anim.anim_activity_slide_in_right, R.anim.anim_activity_fade_out);
    }

    private void setupNavigationView() {

        mNavigationView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

        mNavigationItemHistory = (ViewGroup) mNavigationView.findViewById(R.id.navigation_item_title_history);
        mNavigationItemHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawerDelayed(0);
                FabricHelper.logCustomEvent("start history activity");
                startNavigationActivityWithScreenShot(HistoryActivity.class);
            }
        });
        mNavigationItemFavourite = (ViewGroup) mNavigationView.findViewById(R.id.navigation_item_title_favourite);
        mNavigationItemFavourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawerDelayed(0);
                FabricHelper.logCustomEvent("start favour activity");
                startNavigationActivityWithScreenShot(FavourActivity.class);
            }
        });
        mNavigationItemSetting = (ViewGroup) mNavigationView.findViewById(R.id.navigation_item_title_setting);
        mNavigationItemSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawerDelayed(0);
                FabricHelper.logCustomEvent("start setting activity");
                startNavigationActivityWithScreenShot(SettingActivity.class);
            }
        });
        mNavigationVrMode = (ViewGroup) mNavigationView.findViewById(R.id.navigation_vr_mode);
        mNavigationVrMode.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN: {
                        v.setBackground(new ColorDrawable(getResources().getColor(R.color.navigation_vr_bg_press_color)));
                        break;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        v.setBackground(null);
                        break;
                    }
                }
                return false;
            }
        });
        mNavigationVrMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawerDelayed(0);
                mLaunchHelper.launchVR(null, "navigation");
                overridePendingTransition(R.anim.anim_activity_slide_in_right, R.anim.anim_activity_fade_out);
            }
        });
    }

    private void closeDrawerDelayed(int delayed) {
        if (delayed == 0) {
            mZeusHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mDrawerLayout.closeDrawer(mNavigationView);
                }
            }, getResources().getInteger(android.R.integer.config_mediumAnimTime));
        } else if (delayed < 0) {
            mDrawerLayout.closeDrawer(mNavigationView, false);
        } else {
            mZeusHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mDrawerLayout.closeDrawer(mNavigationView);
                }
            }, delayed);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        LogUtil.e("Activity onStart");
        //Deactivated for now
//        createExtensionServiceConnection();

//        clearBackstackFromClass(ExtensionBrowser.class);
    }

    @Override
    protected void onStop() {
        super.onStop();
        LogUtil.e("Activity onStop");
    }

    @Override
    protected void onResume() {
        super.onResume();
        LogUtil.e("Activity onResume");

        //Set up fragment resume bugs here?
        setupFragment(mCurrentFragmentId);
        /* Load media items from database and storage */
        if (mScanNeeded) {
            mMediaLibrary.scanMediaItems();
        }
    }

    /**
     * Stop audio player and save opened tab
     */
    @Override
    protected void onPause() {
        super.onPause();
        LogUtil.e("Activity onPause");
        if (getChangingConfigurations() == 0) {
            /* Check for an ongoing scan that needs to be resumed during onResume */
            mScanNeeded = mMediaLibrary.isWorking();
            /* Stop scanning for files */
            mMediaLibrary.stop();
        }
        /* Save the tab status in pref */
        mSharedPreferencesManager.setCurrentFragmentId(mCurrentFragmentId);
    }

    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("current", mCurrentFragmentId);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        /* Reload the latest preferences */
        reloadPreferences();
    }

    @Override
    public void onBackPressed() {
        /* Close the menu first */
        if (mDrawerLayout.isDrawerOpen(mNavigationView)) {
            mDrawerLayout.closeDrawer(mNavigationView);
            return;
        }

        // Press twice to exit the application.
        if ((System.currentTimeMillis() - exitTime) > 2000) {
            Toast.makeText(getApplicationContext(), "Press again to exit the application", Toast.LENGTH_SHORT).show();
            exitTime = System.currentTimeMillis();
        } else {
            finish();
        }
    }

    long exitTime;

    private Fragment getFragment(int id) {
        Fragment frag = getSupportFragmentManager().findFragmentByTag(getTag(id));
        if (frag != null)
            return frag;
        switch (id) {
            case FRAGMENT_GALLERY: {
                return new GalleryGridFragment();
            }
            case FRAGMENT_MY_VIDEOS: {
                return new MyVideoGridFragment();
            }
            case FRAGMENT_LOCAL_FILE: {
                return new LocalFilesFragment();
            }
            case FRAGMENT_AIR_SCREEN: {
                return new AirScreenFragment();
            }
            case FRAGMENT_ONLINE: {
                return new MRLPanelFragment();
            }
            default: {
                throw new IllegalArgumentException("wrong fragment id");
            }
        }
    }

    public void forceRefresh() {
        // TODO GUAN
//        forceRefresh(getSupportFragmentManager().findFragmentById(R.id.fragment_placeholder));
    }

    private void forceRefresh(Fragment current) {
        if (!mMediaLibrary.isWorking()) {
            if (current != null && current instanceof IRefreshable)
                ((IRefreshable) current).refresh();
            else
                mMediaLibrary.scanMediaItems(true);
        }
    }

    // Note. onKeyDown will not occur while moving within a list
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        //Filter for LG devices, see https://code.google.com/p/android/issues/detail?id=78154
        if ((keyCode == KeyEvent.KEYCODE_MENU) &&
                (Build.VERSION.SDK_INT <= 16) &&
                (Build.MANUFACTURER.compareTo("LGE") == 0)) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    // Note. onKeyDown will not occur while moving within a list
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        //Filter for LG devices, see https://code.google.com/p/android/issues/detail?id=78154
        if ((keyCode == KeyEvent.KEYCODE_MENU) &&
                (Build.VERSION.SDK_INT <= 16) &&
                (Build.MANUFACTURER.compareTo("LGE") == 0)) {
            openOptionsMenu();
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    private void reloadPreferences() {
        mCurrentFragmentId = mSharedPreferencesManager.getCurrentFragmentId();
    }

    @Override
    public Cursor runQuery(CharSequence constraint) {
        return getInstance().queryMedia(constraint.toString());
    }

    @Override
    public void showSoftInputKeyBoard(final View view) {
        getZeusHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    view.requestFocus();
                    imm.showSoftInput(view, 0);
                }
            }
        }, 100);
    }

    @Override
    public void hideSoftInputKeyBoard(final View view) {
        getZeusHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    view.requestFocus();
                    imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
                }
            }
        }, 100);
    }

    @Override
    public void setAirScreenUnfoldTitleBar(String deviceName, View.OnClickListener disconnectListener) {
    }

    @Override
    public void changeBottomTabVisual(boolean isVisible) {
        if (isVisible) {
            mBottomShadow.setVisibility(VISIBLE);
            mBottomMask.setVisibility(VISIBLE);
            mBottomBarBg.setVisibility(VISIBLE);
            mBottomTabBar.setVisibility(VISIBLE);
        } else {
            mBottomShadow.setVisibility(GONE);
            mBottomMask.setVisibility(GONE);
            mBottomBarBg.setVisibility(GONE);
            mBottomTabBar.setVisibility(GONE);
        }
    }

    @Override
    public void setPresenter(AirScreenContract.Presenter presenter) {

    }

    public void enableRightIcon(boolean enable) {
        if (enable) {
            mRightImageView.setVisibility(VISIBLE);
        } else {
            mRightImageView.setVisibility(GONE);
        }
    }

    public class ZeusHandler extends Handler {
        private static final String TAG = "ZeusHandler";
        public static final int SHOW_SEARCH_TIPS = 0;
        public static final int SHOW_SEARCHING = 1;
        /**
         * msg.obj is a object[2],<br/>
         * object[0] = AirScreenConnectContract.View,<br/>
         * object[1] = List '<'String'>' device list
         */
        public static final int SHOW_DEVICE_FOUNDED = 2;
        public static final int SHOW_NO_DEVICE = 3;
        //public static final int SHOW_CONNECTING_TO_DEVICE = 4;
        public static final int SHOW_AIRSCREEN_GRID_FRAGMENT = 4;
        public static final int SHOW_CODE_DIALOG = 5;
        public static final int CHANGE_CODE_DIALOG_TITLE = 6;
        public static final int DISMISS_CODE_DIALOG = 7;
        public static final int DISCONNECT_BUTTON_CLICKED = 8;
        public static final int SHOW_LOADING_DIALOG = 9;
        public static final int DISSMISS_LOADING_DIALOG = 10;
        public static final int UPDATE_AIRSCREEN_GRID_ITEM_LIST = 11;
        public static final int START_MEDIA_DOWNLOAD = 12;
        public static final int CANCEL_MEDIA_DOWNLOAD = 13;
        public static final int DELETE_AIRSCREEN_MEDIA_ITEM = 14;
        public static final int DELETE_ALL_AIRSCREEN_MEDIA_ITEM = 15;
        public static final int AIR_SCREEN_CONNECT_OVER_TIME = 16;
        AirScreenConnectContract.View mAirScreenConnectView;
        AirScreenConnectContract.Presenter mAirScreenConnectPresenter;

        public ZeusHandler() {
        }

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case DELETE_AIRSCREEN_MEDIA_ITEM: {
                    Object[] obj = (Object[]) msg.obj;
                    String id = (String) obj[0];
                    AirScreenVideoGridFragment airScreenVideoGridFragment = mAirScreenFragment.getAirScreenVideoGridFragment();
                    List<AirScreenMediaWrapper> list = airScreenVideoGridFragment.getMediaList();
                    for (int i = 0; i < list.size(); i++) {
                        AirScreenMediaWrapper airScreenMediaWrapper = list.get(i);
                        if (airScreenMediaWrapper.getId().equals(id)) {
                            list.remove(i);
                        }
                    }
                    airScreenVideoGridFragment.updateListAndDisplay(list);
                    break;
                }
                case DELETE_ALL_AIRSCREEN_MEDIA_ITEM: {
                    AirScreenVideoGridFragment airScreenVideoGridFragment = mAirScreenFragment.getAirScreenVideoGridFragment();
                    airScreenVideoGridFragment.updateListAndDisplay(new ArrayList<AirScreenMediaWrapper>(0));
                    break;
                }
                case START_MEDIA_DOWNLOAD: {
                    Object[] obj = (Object[]) msg.obj;
                    String id = (String) obj[0];
                    AirScreenVideoGridFragment airScreenVideoGridFragment = mAirScreenFragment.getAirScreenVideoGridFragment();
                    List<AirScreenMediaWrapper> list = airScreenVideoGridFragment.getMediaList();
                    for (AirScreenMediaWrapper airScreenMediaWrapper : list) {
                        if (airScreenMediaWrapper.getId().equals(id)) {
                            if (mNetworkBinder != null) {
                                mNetworkBinder.getDownloader().startDownload(airScreenMediaWrapper.getVideoUrl(), airScreenMediaWrapper);
                            } else {
                                //Todo callBack
                                LogUtil.e("mNetWorkBinder is null");
                                bindNetWorkService();
                            }
                        }
                    }
                    break;
                }
                case CANCEL_MEDIA_DOWNLOAD: {
                    Object[] obj = (Object[]) msg.obj;
                    String id = (String) obj[0];
                    AirScreenVideoGridFragment airScreenVideoGridFragment = mAirScreenFragment.getAirScreenVideoGridFragment();
                    List<AirScreenMediaWrapper> list = airScreenVideoGridFragment.getMediaList();
                    for (AirScreenMediaWrapper airScreenMediaWrapper : list) {
                        if (airScreenMediaWrapper.getId().equals(id)) {
                            if (mNetworkBinder != null) {
                                mNetworkBinder.getDownloader().cancelDownload(airScreenMediaWrapper.getVideoUrl(), airScreenMediaWrapper);
                            } else {
                                //Todo callBack
                                LogUtil.e("mNetWorkBinder is null");
                                bindNetWorkService();
                            }
                        }
                    }
                    break;
                }
                case SHOW_SEARCH_TIPS: {
                    mAirScreenConnectView = mAirScreenFragment.getAirScreenConnectFragment();
                    mAirScreenConnectView.showSearchTips();
                    break;
                }
                case SHOW_SEARCHING: {
                    mAirScreenConnectView = mAirScreenFragment.getAirScreenConnectFragment();
                    mAirScreenConnectView.showSearching();
                    break;
                }
                case SHOW_DEVICE_FOUNDED: {
                    mAirScreenConnectView = mAirScreenFragment.getAirScreenConnectFragment();
                    List<ServerItemBean> deviceList = (List<ServerItemBean>) msg.obj;
                    mAirScreenConnectView.showFoundDevices(deviceList);
                    break;
                }
                case SHOW_NO_DEVICE: {
                    mAirScreenConnectView = mAirScreenFragment.getAirScreenConnectFragment();
                    mAirScreenConnectView.showNotFoundDevice();
                    break;
                }
                case SHOW_AIRSCREEN_GRID_FRAGMENT: {
                    LogUtil.i(TAG + " received SHOW_AIRSCREEN_GRID_FRAGMENT");
                    Object[] objectsVideoGrid = (Object[]) msg.obj;
                    String deviceName = (String) objectsVideoGrid[0];
                    mAirScreenTitleServerName.setText(deviceName);
                    mAirScreenFragment.showVideoGridFragment();
                    replaceAirScreenTitleBar(false);
                    break;
                }
                case UPDATE_AIRSCREEN_GRID_ITEM_LIST: {
                    LogUtil.i(TAG + " received UPDATE_AIRSCREEN_GRID_ITEM_LIST");
                    LogUtil.d("getMediaList step 3 Zeus Handler : received UPDATE_AIRSCREEN_GRID_ITEM_LIST");
                    List<AirScreenMediaWrapper> mediaWrappers = (List<AirScreenMediaWrapper>) msg.obj;
                    mAirScreenFragment.getAirScreenVideoGridPresenter().updateList(mediaWrappers);
                    break;
                }
                case SHOW_CODE_DIALOG: {
                    String msgs = (String) msg.obj;
                    mAirScreenConnectView = mAirScreenFragment.getAirScreenConnectFragment();
                    mAirScreenConnectView.showCodeCheckDialog(-1);
                    break;
                }
                case CHANGE_CODE_DIALOG_TITLE: {
                    Boolean isTitleNormal = (Boolean) msg.obj;
                    mAirScreenConnectView = mAirScreenFragment.getAirScreenConnectFragment();
                    mAirScreenConnectView.changeCodeDialogTitle(isTitleNormal);
                    break;
                }
                case DISMISS_CODE_DIALOG: {
                    mAirScreenConnectView.dissmissCodeCheckDialog();
                    break;
                }
                case DISCONNECT_BUTTON_CLICKED: {
                    mNetworkBinder.getDownloader().pauseAllDownload();
                    AirScreenConnectFragment airScreenConnectFragment = mAirScreenFragment.getAirScreenConnectFragment();
                    mAirScreenConnectView = airScreenConnectFragment;
                    mAirScreenFragment.showConnectFragment();
                    replaceAirScreenTitleBar(true);

                    // Remove connected server info.
                    MediaDatabase mediaDatabase = getInstance();
                    mediaDatabase.clearServerTable();
                    AirScreenNetwork.getInstance().notifyDisconnect();
                    break;
                }
                case SHOW_LOADING_DIALOG: {
                    Integer y = null;
                    if (msg.obj != null) {
                        y = (Integer) msg.obj;
                    }
                    if (mLoadingDialog == null) {
                        mLoadingDialog = new LoadingDialog(mContext, R.style.LoadingDialog);
                        mLoadingDialog.setCancelable(false);
                    }
                    if (!mLoadingDialog.isShowing()) {
                        Window dialogWindow = mLoadingDialog.getWindow();
                        WindowManager.LayoutParams lp = dialogWindow.getAttributes();
                        if (y == null) {
                            lp.y = getResources().getDimensionPixelSize(R.dimen.loading_dialog_margin_top);
                        } else {
                            lp.y = y;
                        }
                        dialogWindow.setGravity(Gravity.TOP);
                        dialogWindow.setAttributes(lp);
                        mLoadingDialog.show();
                        sendEmptyMessageDelayed(AIR_SCREEN_CONNECT_OVER_TIME, AirScreenNetwork.OVER_TIME);
                    }
                    break;
                }
                case AIR_SCREEN_CONNECT_OVER_TIME: {
                    AirScreenNetwork airScreenNetwork = AirScreenNetwork.getInstance();
                    int connectState = airScreenNetwork.getConnectState().ordinal();
                    LogUtil.d("Connect State : " + connectState);
                    if (connectState < AirScreenNetwork.State.LoggedIn.ordinal()) {
                        airScreenNetwork.destroy();
                        airScreenNetwork = AirScreenNetwork.getInstance();
                        airScreenNetwork.setMainActivity(mMainActivity);
                        airScreenNetwork.startThread();
                        mAirScreenConnectView.showSearchTips();
                        if (mLoadingDialog != null && mLoadingDialog.isShowing()) {
                            mLoadingDialog.dismiss();
                        }
                        Toast.makeText(mMainActivity, "Connect failed, check your net state and reconnect.", Toast.LENGTH_SHORT).show();
                    }
                    break;
                }
                case DISSMISS_LOADING_DIALOG: {
                    if (mLoadingDialog != null && mLoadingDialog.isShowing()) {
                        mLoadingDialog.dismiss();
                    }
                    break;
                }
            }
        }
    }

    private String getTag(int id) {
        return "MainFragment_" + id;
    }
}
