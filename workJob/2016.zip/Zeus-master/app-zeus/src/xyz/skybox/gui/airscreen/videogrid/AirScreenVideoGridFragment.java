//Todo Copyright
package xyz.skybox.gui.airscreen.videogrid;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;

import com.amy.inertia.interfaces.PullListenerAdapter;
import com.amy.inertia.view.PullToRefreshContainer;

import java.util.ArrayList;
import java.util.List;

import xyz.skybox.R;
import xyz.skybox.common.util.GuavaUtil;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.gui.MainActivity;
import xyz.skybox.gui.base.view.VideoRecyclerView;
import xyz.skybox.gui.base.view.refresh.TopLoadingRefreshView;
import xyz.skybox.interfaces.ISortable;
import xyz.skybox.media.MediaUtils;
import xyz.skybox.repository.SharedPreferencesManager;
import xyz.skybox.repository.airscreen.AirScreenMediaWrapper;
import xyz.skybox.util.AndroidDevices;

import static android.view.View.GONE;

public class AirScreenVideoGridFragment extends Fragment implements AirScreenVideoGridContract.View, ISortable {

    //Global
    private MainActivity mMainActivity;
    private AirScreenVideoGridContract.Presenter mPresenter;

    //Properties
    private boolean isListMode = false;
    private boolean isRefreshByPull = false;
    private boolean isPushUp = false;

    //Views
    private PullToRefreshContainer mPullToRefreshContainer;
    private ViewGroup mHints;
    private VideoRecyclerView mGridView;
    private ViewGroup mLoading;
    private ImageView mLoadingIcon;
    private ViewGroup mNoRemoteMedia;
    private ImageView mVideoMask;

    private RotateAnimation mLoadingIconRotateAnimation;

    //GridView Properties
    private AirScreenVideoListAdapter mAdapter;
    private RecyclerView.OnScrollListener mScrollListener = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            if (mMainActivity == null) {
                return;
            }
            int topRowVerticalPosition =
                    (recyclerView == null || recyclerView.getChildCount() == 0) ? 0 : recyclerView.getChildAt(0).getTop();
            mPullToRefreshContainer.setEnabled(topRowVerticalPosition >= 0);

            pushUpFloatingActionBar();
        }
    };

    private final BroadcastReceiver mRemoteScanReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (action.equalsIgnoreCase(MediaUtils.ACTION_REMOTE_SCAN_START)) {
                LogUtil.e(" ACTION_REMOTE_SCAN_START receive " + " : " + "isRefreshByPull : " + isRefreshByPull);
                if (!isRefreshByPull) {
                    mGridView.setVisibility(GONE);
                    mHints.setVisibility(View.VISIBLE);
                    mNoRemoteMedia.setVisibility(GONE);
                    mLoading.setVisibility(View.VISIBLE);
                    startLoadingIconRotate();
                }
            } else if (action.equalsIgnoreCase(MediaUtils.ACTION_REMOTE_SCAN_STOP)) {
                LogUtil.e(" ACTION_REMOTE_SCAN_STOP receive " + " : " + "isRefreshByPull : " + isRefreshByPull);
                if (isRefreshByPull) {
                    stopRefreshViewRefresh();
                } else {
                    stopRefreshViewRefresh();
                    stopLoadingIconRotate();
                    mLoading.setVisibility(GONE);
                    mGridView.setVisibility(View.VISIBLE);
                }
            }
        }
    };

    public AirScreenVideoGridFragment() {
        super();
    }

    private void addReceiver(IntentFilter filter, BroadcastReceiver receiver) {
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(receiver, filter);
    }

    private void removeReceiver(BroadcastReceiver receiver) {
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(receiver);
    }

    private void initRemoteScanActionReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(MediaUtils.ACTION_REMOTE_SCAN_START);
        filter.addAction(MediaUtils.ACTION_REMOTE_SCAN_STOP);
        addReceiver(filter, mRemoteScanReceiver);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        LogUtil.e("onCreate start");

        super.onCreate(savedInstanceState);

        LogUtil.e("onCreate end");
    }

    @Override
    public void onAttach(Context context) {
        LogUtil.e("onAttach start");

        super.onAttach(context);

        mMainActivity = (MainActivity) context;
        isListMode = SharedPreferencesManager.getInstance(mMainActivity).getFragmentListMode(this.getClass().getName());

        LogUtil.e("onAttach end");
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LogUtil.e("onCreateView start");

        View v = inflater.inflate(R.layout.video_grid_remote_fragment, container, false);

        LogUtil.e("onCreateView end");

        return v;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        LogUtil.e("onViewCreated start");

        super.onViewCreated(view, savedInstanceState);

        initRemoteScanActionReceiver();

        findViews(view);

        initViews();

        updateViewMode();

        LogUtil.e("onViewCreated end");
    }

    private void findViews(View view) {
        mHints = (ViewGroup) view.findViewById(R.id.video_grid_hint);
        mGridView = (VideoRecyclerView) view.findViewById(R.id.video_grid_list_view);
        mLoading = (ViewGroup) view.findViewById(R.id.video_grid_loading);
        mLoadingIcon = (ImageView) view.findViewById(R.id.video_grid_loading_icon);
        mPullToRefreshContainer = (PullToRefreshContainer) view.findViewById(R.id.video_grid_refresh_layout);
        mNoRemoteMedia = (ViewGroup) view.findViewById(R.id.video_grid_no_media_remote);
        mVideoMask = (ImageView) view.findViewById(R.id.video_grid_no_media_remote_mask);
    }

    private void initViews() {
        TopLoadingRefreshView topLoadingRefreshView = new TopLoadingRefreshView(getContext());

        mPullToRefreshContainer.setHeaderView(topLoadingRefreshView);
        mPullToRefreshContainer.addIPullListener(new PullListenerAdapter() {
            private int stopRefreshDelayed = 3000;

            @Override
            public void onHeaderRefresh() {
                super.onHeaderRefresh();

                mPullToRefreshContainer.setHeaderRefreshing(true);

                mAdapter.setClickable(false);
                mGridView.setScrollEnabled(false);
                isRefreshByPull = true;
                mPresenter.getMediaListCallBack();
                mPullToRefreshContainer.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        stopRefreshViewRefresh();
                    }
                }, stopRefreshDelayed);
            }

        });

        mAdapter = new AirScreenVideoListAdapter(false);
        mGridView.setAdapter(mAdapter);
        mGridView.addOnScrollListener(mScrollListener);

        setHint();
    }

    @Override
    public void onResume() {
        LogUtil.e("onResume start");
        super.onResume();
        LogUtil.d("resume : " + this + " presenter : " + mPresenter);
        //Todo if air screen net work crashed
        final boolean refresh = mAdapter.isEmpty();

        if (refresh) {
            mPresenter.getMediaListCallBack();
        } else {
            changeHintVisible();
        }

        LogUtil.e("onResume end");
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        LogUtil.e("AirScreenGridFragment onHiddenChanged : " + hidden);
        if (!hidden && mPresenter != null) {
            mPresenter.getMediaListCallBack();
        }

        if (hidden && mAdapter != null) {
            clear();
            mAdapter.notifyDataSetChanged();

            mHints.setVisibility(GONE);
            mGridView.setVisibility(View.VISIBLE);
            changeNoMediaVisible();
        }

    }

    public List<AirScreenMediaWrapper> getMediaList() {
        return mAdapter.getAll();
    }

    @Override
    public void updateListAndDisplay(List<AirScreenMediaWrapper> itemList) {
        LogUtil.d("getMediaList step 5 updateListAndDisplay start");
        if (mMainActivity == null) {
            mMainActivity = (MainActivity) getActivity();
        }
        if (mMainActivity != null && mMainActivity.getCurrentFragmentId() == MainActivity.FRAGMENT_AIR_SCREEN) {
            if (!mPullToRefreshContainer.isHeaderRefreshing() && isRefreshByPull) {
                mPullToRefreshContainer.setHeaderRefreshing(true);
            }
            if (itemList.size() > 0) {
                final ArrayList<AirScreenMediaWrapper> displayList = new ArrayList<>();

                for (AirScreenMediaWrapper item : itemList) {
                    displayList.add(item);
                }
                clear();
                mAdapter.addAll(displayList);
                display();
            } else if (itemList.size() == 0) {
                clear();
                display();
                // If there is no item in the itemList show the empty tips.
            } else {
                throw new RuntimeException("size < 0 cannot be happend?");
            }
            LogUtil.d("getMediaLIst step 6 updateListAndDisplay end");
        }
    }

    @Override
    public void onDestroyView() {
        LogUtil.e("onDestroyView start");

        stopLoadingIconRotate();
        super.onDestroyView();

        LogUtil.e("onDestroyView end");
    }

    @Override
    public void onStart() {
        LogUtil.e("onStart start");

        super.onStart();

        LogUtil.e("onStart end");
    }

    @Override
    public void onStop() {
        LogUtil.e("onStop start");

        super.onStop();

        LogUtil.e("onStop end");
    }

    @Override
    public void onPause() {
        LogUtil.e("onPause start");

        super.onPause();

        removeReceiver(mRemoteScanReceiver);

        LogUtil.e("onPause end");
    }

    @Override
    public void onDestroy() {
        LogUtil.e("onDestroy start");

        super.onDestroy();
        clear();

        LogUtil.e("onDestroy end");
    }

    private void display() {
        mMainActivity = mMainActivity == null ? (MainActivity) getActivity() : mMainActivity;
        if (mMainActivity != null) {
            mAdapter.notifyDataSetChanged();
            changeHintVisible();
        } else {
            throw new NullPointerException("Context is null in display()");
        }
    }

    private void clear() {
        if (mAdapter != null) {
            mAdapter.clear();
        } else {
            throw new NullPointerException("mAdapter == null");
        }
    }

    private void startLoadingIconRotate() {
        GuavaUtil.checkNotNull(mLoadingIcon);

        int fromRotate = 0;
        int toRotate = 360;
        float pivotX = 0.5f;
        float pivotY = 0.5f;
        int rotateDuration = 2500;

        mLoadingIconRotateAnimation = new RotateAnimation(fromRotate, toRotate, Animation.RELATIVE_TO_SELF,
                pivotX, Animation.RELATIVE_TO_SELF, pivotY);
        mLoadingIconRotateAnimation.setDuration(rotateDuration);
        mLoadingIconRotateAnimation.setInterpolator(new LinearInterpolator());
        mLoadingIconRotateAnimation.setRepeatCount(Animation.INFINITE);
        mLoadingIconRotateAnimation.setRepeatMode(Animation.RESTART);

        mLoadingIcon.startAnimation(mLoadingIconRotateAnimation);
    }

    private void stopLoadingIconRotate() {
        if (mLoadingIconRotateAnimation != null) {
            mLoadingIconRotateAnimation.cancel();
            mLoadingIcon.clearAnimation();
            mLoadingIconRotateAnimation = null;
        }
    }

    private RecyclerView.ItemDecoration mListItemDecoration = new RecyclerView.ItemDecoration() {

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            super.getItemOffsets(outRect, view, parent, state);

            int childLayoutPosition = parent.getChildLayoutPosition(view);
            // Top padding
            if (childLayoutPosition == 0) {
                outRect.top = getResources().getDimensionPixelSize(R.dimen.recycler_view_top_padding_list_mode);
            }
            // Bottom padding
            int gridViewItemCount = mGridView.getAdapter().getItemCount();
            if ((gridViewItemCount - 1) == childLayoutPosition) {
                outRect.bottom = getResources().getDimensionPixelSize(R.dimen.recycler_view_bottom_item_bottom_padding);
            }
        }
    };

    private RecyclerView.ItemDecoration mGridItemDecoration = new RecyclerView.ItemDecoration() {
        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            super.getItemOffsets(outRect, view, parent, state);
            int childLayoutPosition = parent.getChildLayoutPosition(view);
            // TopPadding
            if (childLayoutPosition == 0 || childLayoutPosition == 1) {
                outRect.top = getResources().getDimensionPixelSize(R.dimen.recycler_view_top_padding_grid_mode);
            }
            // ItemPadding
            if (childLayoutPosition % 2 != 0) {
                outRect.left = getResources().getDimensionPixelSize(R.dimen.recycler_view_grid_item_bottom_top_padding);
            }
            //BottomPadding
            int gridViewItemCount = mGridView.getAdapter().getItemCount();
            if ((gridViewItemCount - 1) == childLayoutPosition) {
                outRect.bottom = getResources().getDimensionPixelSize(R.dimen.recycler_view_bottom_item_bottom_padding);
            }
        }
    };

    /**
     * Remove all ItemDecoration,<br/>
     * Google did not provide the method of remove all ItemDecoration.
     */
    private void removeAllItemDecoration() {
        mGridView.removeItemDecoration(mGridItemDecoration);
        mGridView.removeItemDecoration(mListItemDecoration);
    }

    private void setListMode(boolean isListMode) {
        this.isListMode = isListMode;
        SharedPreferencesManager.getInstance(mMainActivity).saveFragmentListMode(this.getClass().getName(), isListMode);
    }

    public void addAllAirScreenMediaList(List<AirScreenMediaWrapper> list) {
        mAdapter.addAll(list);
        mAdapter.notifyDataSetChanged();
    }

    public void setAndUpdateListMode() {
        setListMode(!isListMode);
        updateViewMode();
    }

    public boolean isListMode() {
        return isListMode;
    }

    private void changeWrapperListMode(List<AirScreenMediaWrapper> list, boolean listMode) {
        for (AirScreenMediaWrapper airScreenMediaWrapper : list) {
            airScreenMediaWrapper.setListMode(listMode);
        }
    }

    /**
     * Change View mode,
     * If isListMode not set yet,
     * Default list mode is grid columns count is 2.
     */
    public void changeListMode() {
        final Resources res = getResources();

        // Select between grid or list , the set num columns will do requestLayout.
        if (!isListMode) {
            int flankPadding = res.getDimensionPixelSize(R.dimen.recycler_view_flank_padding_grid_mode);
            mGridView.setPadding(flankPadding, 0, flankPadding, 0);
            removeAllItemDecoration();
            mGridView.addItemDecoration(mGridItemDecoration);
            if (mAdapter != null) {
                List<AirScreenMediaWrapper> list = mAdapter.getAll();
                changeWrapperListMode(list, false);
                mAdapter = new AirScreenVideoListAdapter(false);
                mAdapter.addAll(list);
            } else {
                mAdapter = new AirScreenVideoListAdapter(false);
            }
            mGridView.setAdapter(mAdapter);
            mGridView.setNumColumns(2);
        } else {
            int flankPadding = res.getDimensionPixelSize(R.dimen.recycler_view_flank_padding_list_mode);
            mGridView.setPadding(flankPadding, 0, flankPadding, 0);
            removeAllItemDecoration();
            mGridView.addItemDecoration(mListItemDecoration);
            int position = 0;
            if (mAdapter != null) {
                List<AirScreenMediaWrapper> list = mAdapter.getAll();
                changeWrapperListMode(list, true);
                mAdapter = new AirScreenVideoListAdapter(true);
                mAdapter.addAll(list);
            } else {
                mAdapter = new AirScreenVideoListAdapter(true);
            }
            mGridView.setAdapter(mAdapter);
            mGridView.setNumColumns(1);
        }
    }

    public void updateViewMode() {
        if (getView() == null || getActivity() == null) {
            LogUtil.e("Unable to setup the view");
            return;
        }

        changeListMode();
    }

    public void stopRefreshViewRefresh() {
        if (mPullToRefreshContainer == null) {
            throw new NullPointerException();
        }

        mMainActivity.getZeusHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mPullToRefreshContainer.isHeaderRefreshing()) {
                    mPullToRefreshContainer.finishHeaderRefresh();
                    mAdapter.setClickable(true);
                    mGridView.setScrollEnabled(true);
                    isRefreshByPull = false;
                }
            }
        }, AndroidDevices.REFRESH_DELAYED);
    }

    public void pushUpFloatingActionBar() {
        mMainActivity = mMainActivity == null ? (MainActivity) getActivity() : mMainActivity;

        if (mGridView == null) {
            throw new NullPointerException("mGridView == null ! app crashed");
        }

        int firstVisibleItemPosition = ((LinearLayoutManager) mGridView.getLayoutManager()).findFirstVisibleItemPosition();
        final Resources res = getResources();
        if (mGridView.getChildCount() > 0 && firstVisibleItemPosition == 0) {
            int firstItemTopPosition = mGridView.getChildAt(0).getTop();
            //LogUtil.e("first item Top position  : " + firstItemTopPosition + " isPushUp : " + isPushUp);
            if (firstItemTopPosition > res.getDimensionPixelSize(R.dimen.recycler_view_on_scroll_hide_white_first_item_top)) {
                // > 60
                LogUtil.d("before isPushUp : " + isPushUp());
                if (isPushUp) {
                    isPushUp = false;
                    LogUtil.d("isPushUp : " + isPushUp());
                    mMainActivity.replaceAirScreenTitleBar(true);
                }
            } else if (firstItemTopPosition < 0) {
                // < 0
                LogUtil.d("before isPushUp : " + isPushUp());
                if (!isPushUp) {
                    isPushUp = true;
                    //LogUtil.d("isPushUp : " + isPushUp());
                    LogUtil.e("frag " + toString());
                    mMainActivity.replaceAirScreenTitleBar(true);
                }
            }
        }
    }

    public boolean isPushUp() {
        //LogUtil.e("real isPushUp : " + isPushUp + " frag id " + toString());
        return isPushUp;
    }

    private void changeHintVisible() {
        if (mAdapter.getItemCount() > 0) {
            mHints.setVisibility(GONE);
            mGridView.setVisibility(View.VISIBLE);
            changeNoMediaVisible();
        } else {
            mHints.setVisibility(View.VISIBLE);
            mGridView.setVisibility(GONE);
            changeNoMediaVisible();
        }
    }

    private void changeNoMediaVisible() {
        mNoRemoteMedia.setVisibility(mAdapter.getItemCount() != 0 ? GONE : View.VISIBLE);
        mVideoMask.setVisibility(mAdapter.getItemCount() != 0 ? GONE : View.VISIBLE);
    }

    @Override
    public void sortBy(int sortby) {
        mAdapter.sortBy(sortby);
    }

    @Override
    public int sortDirection(int sortby) {
        return mAdapter.sortDirection(sortby);
    }

    public void setHint() {
        Resources res = mMainActivity.getResources();
        initEmptyMask();
    }

    @Override
    public void setPresenter(AirScreenVideoGridContract.Presenter presenter) {
        LogUtil.e(" presenter is null : " + (presenter == null));
        mPresenter = presenter;
    }

    private void initEmptyMask() {
        AnimationDrawable animationDrawable = new AnimationDrawable();
        for (int i = 1; i < 68; i++) {
            int id = 0;
            if (i > 9) {
                id = getResources().getIdentifier("airscreen_empty_" + i, "drawable", getContext().getPackageName());
            } else {
                id = getResources().getIdentifier("airscreen_empty_0" + i, "drawable", getContext().getPackageName());
            }
            Drawable drawable = getResources().getDrawable(id);
            if (i == 42) {
                animationDrawable.addFrame(drawable, 150);
            } else if (i == 59) {
                animationDrawable.addFrame(drawable, 800);
            } else {
                animationDrawable.addFrame(drawable, getContext().getResources().getInteger(R.integer.air_screen_empty_duration));
            }
            animationDrawable.setOneShot(false);
            mVideoMask.setImageDrawable(animationDrawable);
            animationDrawable.start();
        }
    }
}
