//Todo copyright
package xyz.skybox.gui.airscreen.connect;

import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

import xyz.skybox.R;
import xyz.skybox.common.util.GuavaUtil;
import xyz.skybox.gui.MainActivity;

public class AirScreenHelpDialog extends DialogFragment {
    private MainActivity mMainActivity;

    private View mCancel;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mMainActivity = (MainActivity) context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(STYLE_NO_FRAME, R.style.HelpDialog);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        inflater = getActivity().getLayoutInflater();
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        return inflater.inflate(R.layout.air_screen_help_dialog, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onStart() {
        mMainActivity = mMainActivity == null ? (MainActivity) getActivity() : mMainActivity;
        GuavaUtil.checkNotNull(mMainActivity);

        Resources res = mMainActivity.getResources();
        Dialog dialog = getDialog();
        Window dialogWindow = dialog.getWindow();
        WindowManager.LayoutParams lp = dialogWindow.getAttributes();

        // Set layoutParams
        lp.y = res.getDimensionPixelSize(R.dimen.air_screen_help_dialog_top_margin);
        lp.width = res.getDimensionPixelSize(R.dimen.air_screen_help_dialog_width);
        lp.height = res.getDimensionPixelSize(R.dimen.air_screen_help_dialog_height);

        dialogWindow.setGravity(Gravity.TOP);
        dialogWindow.setAttributes(lp);

        // Set dialog

        dialog.setCanceledOnTouchOutside(true);
        super.onStart();
    }
}
