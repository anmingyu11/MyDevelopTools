//Todo copyright
package xyz.skybox.gui.base.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.TextView;

import xyz.skybox.R;
import xyz.skybox.util.TypeFaceUtil;

public class TypeFaceTextView extends TextView {

    private String mTypeFaceString;
    private Typeface mTypeface;

    public TypeFaceTextView(Context context) {
        this(context, null);
    }

    public TypeFaceTextView(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.TypeFaceTextView);

        if (ta != null) {
            mTypeFaceString = ta.getString(R.styleable.TypeFaceTextView_CustomTypeFace);

            if (mTypeFaceString.equals(context.getString(R.string.typeface_normal))) {
                mTypeface = TypeFaceUtil.mTypeFaceNormal;
                setTypeface(mTypeface);
            } else if (mTypeFaceString.equals(context.getString(R.string.typeface_thin))) {
                mTypeface = TypeFaceUtil.mTypeFaceThin;
                setTypeface(mTypeface);
            } else if (mTypeFaceString.equals(context.getString(R.string.typeface_fat))) {
                mTypeface = TypeFaceUtil.mTypeFaceFat;
                setTypeface(mTypeface);
            } else if (mTypeFaceString.equals(context.getString(R.string.typeface_source_sans_pro_light))) {
                mTypeface = TypeFaceUtil.mTypeFaceSourceSansPro_Light;
                setTypeface(mTypeface);
            } else {
                throw new IllegalArgumentException("wrong type face");
            }
            ta.recycle();
        }

        init();
    }

    public TypeFaceTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs);
    }

    private void init() {
        if (isInEditMode()) {
            return;
        }
    }

}
