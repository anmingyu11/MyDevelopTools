//Todo copyright
package xyz.skybox.gui.base;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;

import xyz.skybox.R;

public class LoadingDialog extends Dialog {

    private ImageView mLoadingIcon;
    private Animation mLoadingAnimation;

    public LoadingDialog(Context context) {
        super(context);
    }

    public LoadingDialog(Context context, int themeResId) {
        super(context, themeResId);
    }

    protected LoadingDialog(Context context, boolean cancelable, OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.loading_dialog, null);
        mLoadingIcon = (ImageView) view.findViewById(R.id.loading_dialog_icon);
        setContentView(view);
    }

    @Override
    public void show() {
        super.show();
        mLoadingAnimation = getLoadingIconRotateAnimate();
        mLoadingIcon.startAnimation(mLoadingAnimation);
    }

    public RotateAnimation getLoadingIconRotateAnimate() {
        int fromRotate = 0;
        int toRotate = 360;
        float pivotX = 0.5f;
        float pivotY = 0.5f;
        int rotateDuration = 2500;

        RotateAnimation animation;
        animation = new RotateAnimation(fromRotate, toRotate, Animation.RELATIVE_TO_SELF,
                pivotX, Animation.RELATIVE_TO_SELF, pivotY);
        animation.setDuration(rotateDuration);
        animation.setInterpolator(new LinearInterpolator());
        animation.setRepeatCount(Animation.INFINITE);
        animation.setRepeatMode(Animation.RESTART);

        return animation;
    }

    @Override
    public void dismiss() {
        super.dismiss();
        mLoadingAnimation.cancel();
    }
}
