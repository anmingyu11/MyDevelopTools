//Todo Copyright
package xyz.skybox.gui.airscreen.connect;

import android.os.Message;

import xyz.skybox.gui.MainActivity;
import xyz.skybox.gui.airscreen.AirScreenNetwork;

public class AirScreenConnectPresenter implements AirScreenConnectContract.Presenter {

    private final AirScreenNetwork mAirScreenNetwork;

    private AirScreenConnectContract.View mAirScreenConnectView;

    private MainActivity mActivity;

    public AirScreenConnectPresenter(MainActivity mainActivity,
                                     AirScreenNetwork airScreenRepository,
                                     AirScreenConnectContract.View airScreenConnectView) {
        mActivity = mainActivity;
        mAirScreenNetwork = airScreenRepository;
        setAirScreenConnectView(airScreenConnectView);

    }

    public void setAirScreenConnectView(AirScreenConnectContract.View airScreenConnectView) {
        mAirScreenConnectView = airScreenConnectView;
        mAirScreenConnectView.setPresenter(this);
    }

    @Override
    public void startSearching() {
        Message msg = new Message();
        msg.what = MainActivity.ZeusHandler.SHOW_SEARCHING;
        mActivity.getZeusHandler().sendMessage(msg);

        AirScreenNetwork network = AirScreenNetwork.getInstance();
        AirScreenNetwork.State connectState = network.getConnectState();

        network.searchServer();
    }

    @Override
    public void start() {

    }

}
