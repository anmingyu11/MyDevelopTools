//Todo copy right
package xyz.skybox.gui.localfile.myvideo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.amy.inertia.interfaces.PullListenerAdapter;
import com.amy.inertia.view.PullToRefreshContainer;

import java.util.ArrayList;
import java.util.List;

import xyz.skybox.R;
import xyz.skybox.common.util.GuavaUtil;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.gui.MainActivity;
import xyz.skybox.gui.base.view.VideoRecyclerView;
import xyz.skybox.gui.base.view.refresh.TopLoadingRefreshView;
import xyz.skybox.gui.video.VideoListHandler;
import xyz.skybox.interfaces.ISortable;
import xyz.skybox.interfaces.IVideoBrowser;
import xyz.skybox.media.MediaLibrary;
import xyz.skybox.media.MediaUtils;
import xyz.skybox.media.MediaWrapper;
import xyz.skybox.repository.SharedPreferencesManager;
import xyz.skybox.statistic.helper.FabricHelper;
import xyz.skybox.util.AndroidDevices;

import static android.view.View.GONE;

public class MyVideoGridFragment extends Fragment implements ISortable, IVideoBrowser {

    private static final String TAG = "MyVideoGridFragment";

    //Global
    private MainActivity mMainActivity;
    private MediaLibrary mMediaLibrary;

    //Properties
    private boolean isListMode = true;
    private boolean isRefreshByPull = false;
    private boolean isPushUp = false;

    //Views
    private PullToRefreshContainer mPullToRefreshContainer;
    private ViewGroup mHints;
    private VideoRecyclerView mGridView;
    private ViewGroup mLoading;
    private ImageView mLoadingIcon;
    private ViewGroup mNoMediaLocal;
    private ImageView mNoMediaLocalIcon;
    private TextView mNoMediaLocalTip;

    //Animations
    private RotateAnimation mLoadingIconRotateAnimation;

    //GridView Property
    private MyVideoListAdapter mAdapter;
    private RecyclerView.ItemDecoration mListItemDecoration = new RecyclerView.ItemDecoration() {

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            super.getItemOffsets(outRect, view, parent, state);

            int childLayoutPosition = parent.getChildLayoutPosition(view);
            // Top padding
            if (childLayoutPosition == 0) {
                outRect.top = getResources().getDimensionPixelSize(R.dimen.recycler_view_top_padding_list_mode);
            }
            // Bottom padding
            int gridViewItemCount = mGridView.getAdapter().getItemCount();
            if ((gridViewItemCount - 1) == childLayoutPosition) {
                outRect.bottom = getResources().getDimensionPixelSize(R.dimen.recycler_view_bottom_item_bottom_padding);
            }
        }
    };

    private RecyclerView.ItemDecoration mGridItemDecoration = new RecyclerView.ItemDecoration() {
        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            super.getItemOffsets(outRect, view, parent, state);
            int childLayoutPosition = parent.getChildLayoutPosition(view);
            // TopPadding
            if (childLayoutPosition == 0 || childLayoutPosition == 1) {
                outRect.top = getResources().getDimensionPixelSize(R.dimen.recycler_view_top_padding_grid_mode);
            }
            // ItemPadding
            if (childLayoutPosition % 2 != 0) {
                outRect.left = getResources().getDimensionPixelSize(R.dimen.recycler_view_grid_item_bottom_top_padding);
            }
            //BottomPadding
            int gridViewItemCount = mGridView.getAdapter().getItemCount();
            if ((gridViewItemCount - 1) == childLayoutPosition) {
                outRect.bottom = getResources().getDimensionPixelSize(R.dimen.recycler_view_bottom_item_bottom_padding);
            }
        }
    };

    private RecyclerView.OnScrollListener mScrollListener = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            if (mMainActivity == null) {
                return;
            }
            int topRowVerticalPosition =
                    (recyclerView == null || recyclerView.getChildCount() == 0) ? 0 : recyclerView.getChildAt(0).getTop();
            mPullToRefreshContainer.setEnabled(topRowVerticalPosition >= 0);

            pushUpFloatingActionBar();
        }
    };

    //ScanLocalReceiver
    private final BroadcastReceiver mLocalScanReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (action.equalsIgnoreCase(MediaUtils.ACTION_SCAN_START)) {
                LogUtil.e(" Action scan start receive " + " : " + "isRefreshByPull : " + isRefreshByPull);
                if (!isRefreshByPull) {
                    mGridView.setVisibility(GONE);
                    mHints.setVisibility(View.VISIBLE);
                    mNoMediaLocal.setVisibility(GONE);
                    mLoading.setVisibility(View.VISIBLE);
                    startLoadingIconRotate();
                }
            } else if (action.equalsIgnoreCase(MediaUtils.ACTION_SCAN_STOP)) {
                LogUtil.e(" Action scan stop receive " + " : " + "isRefreshByPull : " + isRefreshByPull);
                if (isRefreshByPull) {
                    stopRefreshViewRefresh();
                } else {
                    stopRefreshViewRefresh();
                    stopLoadingIconRotate();
                    mLoading.setVisibility(GONE);
                    mGridView.setVisibility(View.VISIBLE);
                }
            }
        }
    };

    public MyVideoGridFragment() {
        super();
    }

    private List<MediaWrapper> getMediaItems() {
        //if (new File(AndroidDevices.MY_VIDEO_DIRECTORY).isDirectory()) {
        //    LogUtil.e("MyVideoDir exists");
        return mMediaLibrary.getVRVideoItems();
        //} else {
        //   LogUtil.e("MyVideoDir not exists");
        //    return AndroidDevices.initMyVideoDir() ? mMediaLibrary.getVideoItems() : new ArrayList<MediaWrapper>(0);
        //}
    }

    @Override
    public void onAttach(Context context) {
        LogUtil.e("onAttach start");

        super.onAttach(context);

        mMainActivity = (MainActivity) context;
        isListMode = SharedPreferencesManager.getInstance(mMainActivity).getFragmentListMode(this.getClass().getName());

        LogUtil.e("onAttach end");
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        LogUtil.e("onCreate start");

        super.onCreate(savedInstanceState);

        mMediaLibrary = MediaLibrary.getInstance();

        LogUtil.e("onCreate end");
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        LogUtil.e("onCreateView start");

        View v = inflater.inflate(R.layout.video_grid_local_fragment, container, false);

        LogUtil.e("onCreatedView end");

        return v;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        LogUtil.e("onViewCreate start");
        super.onViewCreated(view, savedInstanceState);

        findViews(view);

        initViews();

        updateViewMode();

        LogUtil.e("onViewCreate end");
    }

    @Override
    public void onStart() {
        LogUtil.e("onStart start");

        super.onStart();

        initLocalScanActionReceiver();

        LogUtil.e("onStart end");
    }

    @Override
    public void onResume() {
        LogUtil.e("onResume start");

        super.onResume();

        attachToMediaLibrary();

        final boolean refresh = mAdapter.isEmpty() && !mMediaLibrary.isWorking();

        LogUtil.e("resume refresh : " + refresh);
        if (refresh)
            updateList();
        else {
            changeHintVisible();
        }

        LogUtil.e("onResume end");
    }

    @Override
    public void onPause() {
        LogUtil.e("onPause start");

        super.onPause();

        dettachMediaLibrary();

        LogUtil.e("onPause end");
    }

    @Override
    public void onStop() {
        LogUtil.e("onStop start");

        super.onStop();

        removeReceiver(mLocalScanReceiver);

        LogUtil.e("onStop end");
    }

    @Override
    public void onDestroyView() {
        LogUtil.e("onDestroyView start");

        stopLoadingIconRotate();

        super.onDestroyView();

        LogUtil.e("onDestroyView end");
    }

    @Override
    public void onDestroy() {
        LogUtil.e("onDestroy start");

        super.onDestroy();

        clear();

        LogUtil.e("onDestroy end");
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);

        if (hidden) {
            MediaUtils.actionScanStop();
        } else {
            updateList();
        }
        LogUtil.e("MyVideo onHiddenChanged : " + hidden);
    }

    private void display() {
        mAdapter.notifyDataSetChanged();
        changeHintVisible();
        mGridView.requestFocus();
    }

    public void clear() {
        if (mAdapter != null) {
            mAdapter.clear();
        } else {
            throw new NullPointerException("mAdapter == null");
        }
    }

    private void startLoadingIconRotate() {
        GuavaUtil.checkNotNull(mLoadingIcon);

        int fromRotate = 0;
        int toRotate = 360;
        float pivotX = 0.5f;
        float pivotY = 0.5f;
        int rotateDuration = 2500;

        mLoadingIconRotateAnimation = new RotateAnimation(fromRotate, toRotate, Animation.RELATIVE_TO_SELF,
                pivotX, Animation.RELATIVE_TO_SELF, pivotY);
        mLoadingIconRotateAnimation.setDuration(rotateDuration);
        mLoadingIconRotateAnimation.setInterpolator(new LinearInterpolator());
        mLoadingIconRotateAnimation.setRepeatCount(Animation.INFINITE);
        mLoadingIconRotateAnimation.setRepeatMode(Animation.RESTART);

        mLoadingIcon.startAnimation(mLoadingIconRotateAnimation);
    }

    private void stopLoadingIconRotate() {
        if (mLoadingIconRotateAnimation != null) {
            mLoadingIconRotateAnimation.cancel();
            mLoadingIcon.clearAnimation();
            mLoadingIconRotateAnimation = null;
        }
    }

    public void attachToMediaLibrary() {
        if (mMediaLibrary == null) {
            mMediaLibrary = MediaLibrary.getInstance();
        }

        mMediaLibrary.addUpdateHandler(MyVideoGridFragment.class.getName(), mHandler);
        LogUtil.e("attachToMediaLibrary");

    }

    public void dettachMediaLibrary() {
        if (mMediaLibrary == null) {
            mMediaLibrary = MediaLibrary.getInstance();
        }
        try {
            mMediaLibrary.removeUpdateHandler(mHandler);
            LogUtil.e("dettachToMediaLibrary");
        } catch (Exception e) {
            FabricHelper.logException(e);
            e.printStackTrace();
        }
    }

    /**
     * Remove all ItemDecoration,<br/>
     * Google did not provide the method of remove all ItemDecoration.
     */
    private void removeAllItemDecoration() {
        mGridView.removeItemDecoration(mGridItemDecoration);
        mGridView.removeItemDecoration(mListItemDecoration);
    }

    public void setListMode(boolean isListMode) {
        this.isListMode = isListMode;
        SharedPreferencesManager.getInstance(mMainActivity).saveFragmentListMode(this.getClass().getName(), isListMode);
    }

    public boolean isListMode() {
        return isListMode;
    }

    /**
     * Change View mode,
     * If isListMode not set yet,
     * Default list mode is grid columns count is 2.
     */
    private void changeListMode() {
        final Resources res = getResources();

        // Select between grid or list , the set num columns will do requestLayout.
        if (!isListMode) {
            int flankPadding = res.getDimensionPixelSize(R.dimen.recycler_view_flank_padding_grid_mode);
            mGridView.setPadding(flankPadding, 0, flankPadding, 0);
            removeAllItemDecoration();
            mGridView.addItemDecoration(mGridItemDecoration);
            if (mAdapter != null) {
                List<MediaWrapper> list = mAdapter.getAll();
                mAdapter = new MyVideoListAdapter(false);
                mAdapter.addAll(list);
            } else {
                mAdapter = new MyVideoListAdapter(false);
            }
            mGridView.setAdapter(mAdapter);
            mGridView.setNumColumns(2);
        } else {
            int flankPadding = res.getDimensionPixelSize(R.dimen.recycler_view_flank_padding_list_mode);
            mGridView.setPadding(flankPadding, 0, flankPadding, 0);
            removeAllItemDecoration();
            mGridView.addItemDecoration(mListItemDecoration);
            int position = 0;
            if (mAdapter != null) {
                List<MediaWrapper> list = mAdapter.getAll();
                mAdapter = new MyVideoListAdapter(true);
                mAdapter.addAll(list);
            } else {
                mAdapter = new MyVideoListAdapter(true);
            }
            mGridView.setAdapter(mAdapter);
            mGridView.setNumColumns(1);
        }
    }

    private void stopRefreshViewRefresh() {
        if (mPullToRefreshContainer == null) {
            throw new NullPointerException();
        }
        if (mPullToRefreshContainer.isHeaderRefreshing()) {
            LogUtil.e("stop refresh view refresh");
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mPullToRefreshContainer.finishHeaderRefresh();
                    mAdapter.setClickable(true);
                    mGridView.setScrollEnabled(true);
                    isRefreshByPull = false;
                }
            }, AndroidDevices.REFRESH_DELAYED);
        }
    }

    public boolean isPushUp() {
        return isPushUp;
    }

    private Handler mHandler = new VideoListHandler(this);

    @Override
    public void setItemToUpdate(MediaWrapper item) {

    }

    @Override
    public void updateItem(MediaWrapper item) {
        mAdapter.add(item);
        changeHintVisible();
    }

    private void changeHintVisible() {
        LogUtil.e("Item count : " + mAdapter.getItemCount());
        if (mAdapter.getItemCount() > 0) {
            mHints.setVisibility(GONE);
            changeNoMediaVisible(false);
            mGridView.setVisibility(View.VISIBLE);
        } else {
            mHints.setVisibility(View.VISIBLE);
            changeNoMediaVisible(true);
            mGridView.setVisibility(GONE);
        }
    }

    private void changeNoMediaVisible(boolean isVisible) {
        mNoMediaLocal.setVisibility(isVisible ? View.VISIBLE : GONE);
    }

    @Override
    public void sortBy(int sortby) {
        mAdapter.sortBy(sortby);
    }

    @Override
    public int sortDirection(int sortby) {
        return mAdapter.sortDirection(sortby);
    }

    private void setHint() {
        Resources res = mMainActivity.getResources();
        mNoMediaLocal.setVisibility(View.VISIBLE);

        //NoMediaLocalIcon
        int width = res.getDimensionPixelSize(R.dimen.empty_my_video_width);
        int height = res.getDimensionPixelSize(R.dimen.empty_my_video_height);
        LinearLayout.LayoutParams noMediaLocalIconParams = new LinearLayout.LayoutParams(width, height);
        mNoMediaLocalIcon.setLayoutParams(noMediaLocalIconParams);

        //loading
        int topMargin = res.getDimensionPixelSize(R.dimen.empty_my_video_margin_top);
        int loadingTopMargin = res.getDimensionPixelSize(R.dimen.loading_icon_margin_top_with_tab);
        FrameLayout.LayoutParams loadingLayoutParams = new FrameLayout.LayoutParams(mLoading.getLayoutParams());
        loadingLayoutParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        loadingLayoutParams.topMargin = loadingTopMargin;
        mLoading.setLayoutParams(loadingLayoutParams);

        //Hint group
        FrameLayout.LayoutParams layoutParams1 = new FrameLayout.LayoutParams(mHints.getLayoutParams());
        layoutParams1.topMargin = topMargin;
        layoutParams1.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        mHints.setLayoutParams(layoutParams1);

        mNoMediaLocalIcon.setBackground(res.getDrawable(R.drawable.vrvideo_empty));
        mNoMediaLocalIcon.getLayoutParams().width = mMainActivity.getResources().getDimensionPixelSize(R.dimen.x632);
        mNoMediaLocalIcon.getLayoutParams().height = mMainActivity.getResources().getDimensionPixelSize(R.dimen.y404);
        mNoMediaLocalIcon.requestLayout();
        mNoMediaLocalTip.setText(res.getString(R.string.video_grid_novideos_myvideo));
    }

    @Override
    public void updateList() {
        if (mMainActivity.getCurrentFragmentId() == MainActivity.FRAGMENT_LOCAL_FILE ||
                mMainActivity.getCurrentFragmentId() == MainActivity.FRAGMENT_MY_VIDEOS) {
            if (!mPullToRefreshContainer.isHeaderRefreshing() && isRefreshByPull) {
                mPullToRefreshContainer.setHeaderRefreshing(true);
            }

            updateItemList(getMediaItems());
        }
    }

    private void updateItemList(final List<MediaWrapper> itemList) {
        LogUtil.e("handler : " + mHandler.toString());
        if (itemList.size() > 0) {
            final ArrayList<MediaWrapper> displayList = new ArrayList<>();
            final ArrayList<MediaWrapper> jobsList = new ArrayList<>();

            for (MediaWrapper item : itemList) {
                displayList.add(item);
                jobsList.add(item);
            }
            clear();
            mAdapter.addAll(displayList);
            display();
            mMainActivity.enableRightIcon(true);
        } else if (itemList.size() == 0) {
            clear();
            display();
            // If there is no item in the itemList show the empty tips.
            mMainActivity.enableRightIcon(false);
        } else {
            throw new RuntimeException("size < 0 cannot be happend?");
        }
        stopRefreshViewRefresh();
    }


    private void findViews(View view) {
        mHints = (ViewGroup) view.findViewById(R.id.video_grid_hint);
        mGridView = (VideoRecyclerView) view.findViewById(R.id.video_grid_list_view);
        mLoading = (ViewGroup) view.findViewById(R.id.video_grid_loading);
        mLoadingIcon = (ImageView) view.findViewById(R.id.video_grid_loading_icon);
        mPullToRefreshContainer = (PullToRefreshContainer) view.findViewById(R.id.video_grid_refresh_layout);
        mNoMediaLocal = (ViewGroup) view.findViewById(R.id.video_grid_no_media_local);
        mNoMediaLocalIcon = (ImageView) view.findViewById(R.id.video_grid_no_media_local_icon);
        mNoMediaLocalTip = (TextView) view.findViewById(R.id.video_grid_no_media_local_tip);
    }

    private void initViews() {
        TopLoadingRefreshView topLoadingRefreshView = new TopLoadingRefreshView(getContext());
        mPullToRefreshContainer.setHeaderView(topLoadingRefreshView);
        mPullToRefreshContainer.addIPullListener(new PullListenerAdapter() {
            @Override
            public void onHeaderRefresh() {
                super.onHeaderRefresh();

                mPullToRefreshContainer.setHeaderRefreshing(true);

                mAdapter.setClickable(false);
                mGridView.setScrollEnabled(false);
                isRefreshByPull = true;

                if (getActivity() != null && !mMediaLibrary.isWorking()) {
                    mMediaLibrary.scanLocalMediaItems(true);
                }
            }
        });

        mGridView.addOnScrollListener(mScrollListener);

        setHint();

        mNoMediaLocal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMediaLibrary.scanLocalMediaItems(true);
            }
        });
    }


    public void setAndUpdateListMode() {
        setListMode(!isListMode);
        updateViewMode();
    }

    private void updateViewMode() {
        if (getView() == null || getActivity() == null) {
            LogUtil.e("Unable to setup the view");
            return;
        }

        changeListMode();
    }

    public void pushUpFloatingActionBar() {
        mMainActivity = mMainActivity == null ? (MainActivity) getActivity() : mMainActivity;

        if (mGridView == null) {
            throw new NullPointerException("mGridView == null ! app crashed");
        }

        //Todo fix this
        int firstVisibleItemPosition = ((LinearLayoutManager) mGridView.getLayoutManager()).findFirstVisibleItemPosition();
        final Resources res = getResources();
        if (mGridView.getChildCount() > 0) {
            int firstItemTopPosition = mGridView.getChildAt(0).getTop();
            if (firstItemTopPosition > res.getDimensionPixelSize(R.dimen.recycler_view_on_scroll_hide_white_first_item_top)) {
                // > 60
                if (isPushUp) {
                    isPushUp = false;
                    mMainActivity.replaceMyVideoTitleBar(true);
                }
            } else if (firstItemTopPosition < res.getDimensionPixelSize(R.dimen.recycler_view_on_scroll_show_white_first_item_top)) {
                // < 0
                if (!isPushUp) {
                    isPushUp = true;
                    mMainActivity.replaceMyVideoTitleBar(true);
                }
            }
        }
    }

    private void addReceiver(IntentFilter filter, BroadcastReceiver receiver) {
        LogUtil.e("local action receiver added");
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(receiver, filter);
    }

    private void removeReceiver(BroadcastReceiver receiver) {
        LogUtil.e("local action receiver removed");
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(receiver);
    }

    private void initLocalScanActionReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(MediaUtils.ACTION_SCAN_START);
        filter.addAction(MediaUtils.ACTION_SCAN_STOP);
        addReceiver(filter, mLocalScanReceiver);
        if (mMediaLibrary.isWorking()) {
            MediaUtils.actionScanStart();
        }
    }

}

