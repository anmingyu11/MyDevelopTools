//Todo copyright
package xyz.skybox.gui.navigation.favour;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v4.app.Fragment;
import android.view.View;

import xyz.skybox.R;
import xyz.skybox.gui.navigation.NavigationActivity;
import xyz.skybox.gui.navigation.NavigationMainUiParams;

public class FavourActivity extends NavigationActivity {

    private FavourGridFragment mFavourGridFragment;
    private boolean isPushUp;
    private boolean isListMode;

    @Override
    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
    }

    @Override
    public Fragment injectFragment() {
        return mFavourGridFragment = new FavourGridFragment();
    }

    @Override
    protected NavigationMainUiParams injectNavigationMainUiParams() {
        isPushUp = mFavourGridFragment.isPushUp();
        isListMode = mFavourGridFragment.isListMode();

        return new NavigationMainUiParams(
                isListMode ? getDrawableFromId(R.drawable.home_titlebar_list_white) : getDrawableFromId(R.drawable.home_titlebar_grid_white),
                getDrawableFromId(R.drawable.home_titlebar_back_white),
                isListMode ? getDrawableFromId(R.drawable.home_titlebar_list_black) : getDrawableFromId(R.drawable.home_titlebar_grid_black),
                getDrawableFromId(R.drawable.home_titlebar_back_black),
                mFavourGridFragment.isPushUp(),
                getStringFromId(R.string.title_favour)) {

            @Override
            public void rightOnClick(View view) {
                isListMode = !isListMode;
                mFavourGridFragment.setAndUpdateListMode();
                if (!isListMode) {
                    setRightWhiteIcon(getDrawableFromId(R.drawable.home_titlebar_list_white));
                    setRightBlackIcon(getDrawableFromId(R.drawable.home_titlebar_list_black));
                    setIsPushUp(isPushUp);
                } else {
                    setRightWhiteIcon(getDrawableFromId(R.drawable.home_titlebar_grid_white));
                    setRightBlackIcon(getDrawableFromId(R.drawable.home_titlebar_grid_black));
                    setIsPushUp(isPushUp);
                }
            }

            @Override
            public void leftOnclick(View view) {
                onBackPressed();
            }
        };
    }
}
