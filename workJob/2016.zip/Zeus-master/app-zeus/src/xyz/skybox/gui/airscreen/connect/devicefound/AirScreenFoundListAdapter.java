//Todo copyRight
package xyz.skybox.gui.airscreen.connect.devicefound;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import xyz.skybox.R;
import xyz.skybox.repository.airscreen.ServerItemBean;

import java.util.ArrayList;
import java.util.List;


public class AirScreenFoundListAdapter extends RecyclerView.Adapter {

    private Context mContext;
    private List<ServerItemBean> mDeviceList;

    public AirScreenFoundListAdapter(Context context) {
        this.mContext = context;
        mDeviceList = new ArrayList<ServerItemBean>();
        //initData();
    }

    public AirScreenFoundListAdapter(Context context, List<ServerItemBean> deviceList) {
        this.mContext = context;
        this.mDeviceList = deviceList;
        //initData();
    }

    // Test
    /*
    private void initData() {
        int num = 0;
        try {
            num = Util.getRandomNumber(10, 1);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        mDeviceList = new ArrayList<DeviceItemBean>(num);
        for (int i = 0; i < num; i++) {
            mDeviceList.add(new DeviceItemBean("Device SItem - " + i),1234,new View.OnClickListener(){

            });
        }
    }
    */

    public void changeData(List<ServerItemBean> deviceList) {
        this.mDeviceList = deviceList;
        notifyDataSetChanged();
    }

    public void clearData() {
        this.mDeviceList.clear();
        notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        DeviceViewHolder holder
                = new DeviceViewHolder(LayoutInflater.from(mContext).inflate(R.layout.air_screen_device_found_list_item,
                parent, false));
        return holder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        DeviceViewHolder deviceViewHolder = (DeviceViewHolder) holder;
        ServerItemBean itemBean = mDeviceList.get(position);

        deviceViewHolder.mContainer.setOnClickListener(itemBean.getOnClickListener());
        deviceViewHolder.mDeviceName.setText(itemBean.getServerName());
    }


    @Override
    public int getItemCount() {
        return mDeviceList.size();
    }

    class DeviceViewHolder extends RecyclerView.ViewHolder {
        private ViewGroup mContainer;
        //private ImageView mSelected;
        private TextView mDeviceName;

        public DeviceViewHolder(View itemView) {
            super(itemView);
            mContainer = (ViewGroup) itemView.findViewById(R.id.air_screen_connect_device_found_list_item);
            //mSelected = (ImageView) itemView.findViewById(R.id.air_screen_connect_device_found_list_item_selected);
            mDeviceName = (TextView) itemView.findViewById(R.id.air_screen_connect_device_found_list_item_device_name);
        }
    }
}
