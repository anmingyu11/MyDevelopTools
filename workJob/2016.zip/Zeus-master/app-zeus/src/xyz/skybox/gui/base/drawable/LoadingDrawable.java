//Todo copyright
package xyz.skybox.gui.base.drawable;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.view.animation.LinearInterpolator;

import xyz.skybox.R;

public class LoadingDrawable extends Drawable implements Animatable {

    private Context mContext;
    private Matrix mMatrix;

    /**** Loading Icon ****/
    private Bitmap mLoading;
    private int mLoadingSize;

    /**** Animator ****/
    private ValueAnimator mAnimator;

    public LoadingDrawable(Context context) {
        mContext = context;
        initLoadingIcon();
        initAnimator();
    }

    private void createLoadingBitmap() {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;

        mLoading = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.loading, options);
        mLoading = Bitmap.createScaledBitmap(mLoading, mLoadingSize, mLoadingSize, true);
    }

    private void initLoadingIcon() {

        mLoadingSize = mContext.getResources().getDimensionPixelSize(R.dimen.refresh_view_loading_size);
        mMatrix = new Matrix();

        createLoadingBitmap();
    }

    private void initAnimator() {
        float fromDegree = 0.0f;
        float toDegree = 360f;
        final float pX = mLoadingSize / 2f;
        final float pY = mLoadingSize / 2f;
        int duration = 1000;

        mAnimator = ValueAnimator.ofFloat(fromDegree, toDegree);
        mAnimator.setDuration(duration);
        mAnimator.setRepeatCount(ValueAnimator.INFINITE);
        mAnimator.setRepeatMode(ValueAnimator.RESTART);
        mAnimator.setInterpolator(new LinearInterpolator());
        mAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                mMatrix.setRotate((Float) animation.getAnimatedValue(), pX, pY);
                invalidateSelf();
            }
        });
    }

    private void drawLoading(Canvas canvas) {
        canvas.drawBitmap(mLoading, mMatrix, null);
    }

    @Override
    public void draw(Canvas canvas) {
        drawLoading(canvas);
    }

    @Override
    public void setAlpha(int alpha) {
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {

    }

    @Override
    public int getOpacity() {
        return PixelFormat.OPAQUE;
    }

    @Override
    public void start() {
        mAnimator.start();
    }

    @Override
    public void stop() {
        mAnimator.cancel();
    }

    @Override
    public boolean isRunning() {
        return false;
    }

    @Override
    public int getIntrinsicWidth() {
        return mLoadingSize;
    }

    @Override
    public int getIntrinsicHeight() {
        return mLoadingSize;
    }
}
