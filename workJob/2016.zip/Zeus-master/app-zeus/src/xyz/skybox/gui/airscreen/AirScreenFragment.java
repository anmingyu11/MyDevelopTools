package xyz.skybox.gui.airscreen;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import xyz.skybox.R;
import xyz.skybox.common.util.GuavaUtil;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.gui.MainActivity;
import xyz.skybox.gui.airscreen.connect.AirScreenConnectFragment;
import xyz.skybox.gui.airscreen.connect.AirScreenConnectPresenter;
import xyz.skybox.gui.airscreen.videogrid.AirScreenVideoGridFragment;
import xyz.skybox.gui.airscreen.videogrid.AirScreenVideoGridPresenter;
import xyz.skybox.repository.airscreen.ServerInfo;
import xyz.skybox.repository.airscreen.ServerInfoManager;

public class AirScreenFragment extends Fragment implements AirScreenContract.View {

    private AirScreenContract.Presenter mAirScreenPresenter;

    private MainActivity mMainActivity;

    private int mCurrentFragmentId = FRAGMENT_CONNECT;
    public static final int FRAGMENT_CONNECT = 1;
    public static final int FRAGMENT_GRID = 2;

    private final String SAVE_CURRENT_ITEM = "current_item";
    private final String SAVE_CURRENT_SERVER_INFO = "current_server_info";

    private AirScreenConnectFragment mAirScreenConnectFragment;
    private AirScreenConnectPresenter mAirScreenConnectPresenter;
    private AirScreenVideoGridFragment mAirScreenVideoGridFragment;
    private AirScreenVideoGridPresenter mAirScreenVideoGridPresenter;

    private ServerInfo mSaveCurrentServerInfo = null;

    public AirScreenFragment() {
        super();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mMainActivity = (MainActivity) context;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        LogUtil.e("onCreate start : " + savedInstanceState);
        super.onCreate(savedInstanceState);


        if (savedInstanceState != null) {
            mCurrentFragmentId = savedInstanceState.getInt(SAVE_CURRENT_ITEM);
            mSaveCurrentServerInfo = savedInstanceState.getParcelable(SAVE_CURRENT_SERVER_INFO);
        }

        initConnectPresenter((AirScreenConnectFragment) getFragment(FRAGMENT_CONNECT));
        initGridPresenter((AirScreenVideoGridFragment) getFragment(FRAGMENT_GRID));

        LogUtil.e("onCreate end ");
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(SAVE_CURRENT_ITEM, mCurrentFragmentId);
        outState.putParcelable(SAVE_CURRENT_SERVER_INFO, ServerInfoManager.getInstance().getCurrentServerInfo());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.air_screen_fragment, container, false);

        mMainActivity = (MainActivity) getActivity();

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    private void showCurrentFragment() {
        if (mCurrentFragmentId == FRAGMENT_CONNECT) {
            showConnectFragment();
        } else if (mCurrentFragmentId == FRAGMENT_GRID) {
            if (mSaveCurrentServerInfo != null) {
                LogUtil.d("save server info " + mSaveCurrentServerInfo);
                ServerInfoManager.getInstance().addServerInfo(mSaveCurrentServerInfo);
                AirScreenNetwork.getInstance().connectServerByIpSync(mSaveCurrentServerInfo.ip);
            } else {
                LogUtil.d("save server info is null");
                showVideoGridFragment();
            }
        } else {
            throw new IllegalArgumentException("mCurrentFragmentId is invalid");
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        AirScreenNetwork network = AirScreenNetwork.getInstance();

        showCurrentFragment();

        network.setMainActivity(mMainActivity);
        if (!network.isThreadRunning()) {
            network.startThread();
        }

    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        AirScreenNetwork network = AirScreenNetwork.getInstance();
        network.destroy();
    }

    @Override
    public void setPresenter(AirScreenContract.Presenter presenter) {
        mAirScreenPresenter = GuavaUtil.checkNotNull(presenter);
    }

    private int showFragment(int fragmentId) {
        int result = 0;
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        switch (fragmentId) {
            case FRAGMENT_CONNECT: {
                mAirScreenConnectFragment = (AirScreenConnectFragment) getFragment(FRAGMENT_CONNECT);
                initConnectPresenter(mAirScreenConnectFragment);
                /*
                  transaction.setCustomAnimations(
                  R.anim.anim_fragment_slide_left_enter,
                  R.anim.anim_fragment_slide_right_exit);
                */
                if (!mAirScreenConnectFragment.isAdded()) {
                    transaction.add(R.id.fragment_air_screen, mAirScreenConnectFragment, getTag(FRAGMENT_CONNECT));
                }
                result = transaction.hide(getFragment(FRAGMENT_GRID)).show(mAirScreenConnectFragment).commit();
                mCurrentFragmentId = FRAGMENT_CONNECT;
                break;
            }
            case FRAGMENT_GRID: {
                mAirScreenVideoGridFragment = (AirScreenVideoGridFragment) getFragment(FRAGMENT_GRID);
                initGridPresenter(mAirScreenVideoGridFragment);
                /*
                  transaction.setCustomAnimations(
                  R.anim.anim_fragment_slide_left_enter,
                  R.anim.anim_fragment_slide_right_exit);
                */
                if (!mAirScreenVideoGridFragment.isAdded()) {
                    transaction.add(R.id.fragment_air_screen, mAirScreenVideoGridFragment, getTag(FRAGMENT_GRID));
                }
                result = transaction.hide(getFragment(FRAGMENT_CONNECT)).show(mAirScreenVideoGridFragment).commit();
                mCurrentFragmentId = FRAGMENT_GRID;
                break;
            }
            default: {
                throw new IllegalArgumentException("Wrong Fragment ID");
            }
        }
        return result;
    }

    public int getCurrentFragmentId() {
        return mCurrentFragmentId;
    }

    public boolean isPushUp() {
        if (mCurrentFragmentId == FRAGMENT_GRID) {
            mAirScreenVideoGridFragment = (AirScreenVideoGridFragment) getFragment(FRAGMENT_GRID);
            if (mAirScreenVideoGridFragment != null) {
                return mAirScreenVideoGridFragment.isPushUp();
            } else {
                return false;
            }
        } else if (mCurrentFragmentId == FRAGMENT_CONNECT) {
            return false;
        } else {
            throw new IllegalArgumentException("not correct fragment id");
        }
    }

    public AirScreenConnectFragment getAirScreenConnectFragment() {
        return (AirScreenConnectFragment) getFragment(FRAGMENT_CONNECT);
    }

    public AirScreenConnectPresenter getAirScreenConnectPresenter() {
        return mAirScreenConnectPresenter;
    }

    public AirScreenVideoGridFragment getAirScreenVideoGridFragment() {
        return (AirScreenVideoGridFragment) getFragment(FRAGMENT_GRID);
    }

    public AirScreenVideoGridPresenter getAirScreenVideoGridPresenter() {
        return mAirScreenVideoGridPresenter;
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        LogUtil.d("AirScreenFragment onHidden changed");
    }

    private void initConnectPresenter(AirScreenConnectFragment fragment) {
        if (mAirScreenConnectPresenter == null) {
            LogUtil.e("initConnectPresenter");
            mAirScreenConnectPresenter = new AirScreenConnectPresenter(
                    mMainActivity,
                    AirScreenNetwork.getInstance(),
                    fragment);
        } else {
            mAirScreenConnectPresenter.setAirScreenConnectView(fragment);
        }
    }

    private void initGridPresenter(AirScreenVideoGridFragment fragment) {
        LogUtil.e("initGridPresenter");
        if (mAirScreenVideoGridPresenter == null) {
            mAirScreenVideoGridPresenter = new AirScreenVideoGridPresenter(
                    mMainActivity,
                    fragment
            );
        } else {
            mAirScreenVideoGridPresenter.setAirScreenVideoGridView(fragment);
        }
    }

    private Fragment getFragment(int id) {
        Fragment frag = getChildFragmentManager().findFragmentByTag(getTag(id));
        if (frag != null) {
            LogUtil.e("find frag : " + frag);
            return frag;
        }

        switch (id) {
            case FRAGMENT_CONNECT: {
                LogUtil.e("new Fragment : " + getTag(id));
                mAirScreenConnectFragment = new AirScreenConnectFragment();
                return mAirScreenConnectFragment;
            }
            case FRAGMENT_GRID: {
                LogUtil.e("new Fragment : " + getTag(id));
                mAirScreenVideoGridFragment = new AirScreenVideoGridFragment();
                return mAirScreenVideoGridFragment;
            }
            default: {
                throw new IllegalArgumentException("wrong fragment id");
            }
        }
    }

    private String getTag(int id) {
        return "AirScreenFragment_" + id;
    }

    @Override
    public int showVideoGridFragment() {
        return showFragment(FRAGMENT_GRID);
    }

    @Override
    public int showConnectFragment() {
        return showFragment(FRAGMENT_CONNECT);
    }
}
