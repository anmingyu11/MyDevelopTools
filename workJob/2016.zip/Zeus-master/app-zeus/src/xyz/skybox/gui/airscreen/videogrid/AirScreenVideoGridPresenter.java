//Todo Copyright
package xyz.skybox.gui.airscreen.videogrid;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import xyz.skybox.common.util.LogUtil;
import xyz.skybox.statistic.helper.FabricHelper;
import xyz.skybox.gui.MainActivity;
import xyz.skybox.gui.airscreen.AirScreenNetwork;
import xyz.skybox.media.MediaLibrary;
import xyz.skybox.media.MediaUtils;
import xyz.skybox.media.MediaWrapper;
import xyz.skybox.repository.airscreen.AirScreenMediaWrapper;

public class AirScreenVideoGridPresenter implements AirScreenVideoGridContract.Presenter {
    private AirScreenVideoGridContract.View mAirScreenVideoGridView;
    private MainActivity mMainActivity;

    public AirScreenVideoGridPresenter(MainActivity mainActivity, AirScreenVideoGridFragment airScreenVideoGridFragment) {
        mMainActivity = mainActivity;
        setAirScreenVideoGridView(airScreenVideoGridFragment);
    }


    public void setAirScreenVideoGridView(AirScreenVideoGridContract.View airScreenVideoGridView) {
        mAirScreenVideoGridView = airScreenVideoGridView;
        mAirScreenVideoGridView.setPresenter(this);
    }

    @Override
    public void start() {

    }

    @Override
    public void updateList(List<AirScreenMediaWrapper> remoteList) {
        LogUtil.d("getMediaList step 4 presenter updateList");
        if (mMainActivity.getCurrentFragmentId() == MainActivity.FRAGMENT_AIR_SCREEN) {
            mAirScreenVideoGridView.updateListAndDisplay(setRemoteListDownloadState(remoteList));
        } else {
            mAirScreenVideoGridView.addAllAirScreenMediaList(remoteList);
        }
    }

    /**
     * 这个方法用于识别文件是否下载，中文名的文件无法正常识别。
     *
     * @param remoteList
     * @return
     */
    private List<AirScreenMediaWrapper> setRemoteListDownloadState(List<AirScreenMediaWrapper> remoteList) {
        LogUtil.d("------------------Has Downloaded Start -----------------");
        for (AirScreenMediaWrapper airScreenMediaWrapper : remoteList) {
            for (MediaWrapper mediaWrapper : MediaLibrary.getInstance().getVideoItems()) {
                boolean titleEqual = airScreenMediaWrapper.getTitle().replaceAll(" ", "").replaceAll("_", "").
                        equals(mediaWrapper.getFileName().replaceAll(" ", "").replaceAll("_", ""));
                boolean lengthEqual = airScreenMediaWrapper.getSize() == new File(mediaWrapper.getLocation().substring(7)).length();
                if (titleEqual && lengthEqual) {
                    airScreenMediaWrapper.setState(AirScreenMediaWrapper.STATE_HAS_DOWNLOAD);
                    LogUtil.d("remote | name : " + airScreenMediaWrapper.getTitle().replaceAll(" ", "").replaceAll("_", "")
                            + " length : " + airScreenMediaWrapper.getSize());
                    LogUtil.d("local | name : " + mediaWrapper.getFileName().replaceAll("_", "").replaceAll(" ", "")
                            + " length : " + new File(mediaWrapper.getLocation().substring(7)).length());

                }
            }
        }
        LogUtil.d("------------------Has Downloaded End ------------------");
        return remoteList;
    }

    @Override
    public void getMediaListCallBack() {
        LogUtil.d("getMediaList step 1 CallBack");
        //Todo optimize this
        MediaUtils.actionRemoteScanStart();
        Thread thread = new Thread(new Runnable() {
            private final int mCheckTime = 300;
            private final int mInterupptTime = 5000;
            private int mTimeSpend = 0;

            @Override
            public void run() {
                while (true) {
                    try {
                        LogUtil.d("ConnectState is " + AirScreenNetwork.sStateArray[AirScreenNetwork.getInstance().getConnectState().ordinal()]);
                        if (AirScreenNetwork.getInstance().getConnectState() == AirScreenNetwork.State.LoggedIn) {
                            AirScreenNetwork.getInstance().getMediaList();
                            return;
                        }
                        //Wait to loop
                        Thread.sleep(mCheckTime);
                        mTimeSpend += mCheckTime;
                        if (mTimeSpend >= mInterupptTime) {
                            //Todo connect error
                            LogUtil.e("Connect over time");
                            mMainActivity.getZeusHandler().post(new Runnable() {
                                @Override
                                public void run() {
                                    updateList(new ArrayList<AirScreenMediaWrapper>(0));
                                }
                            });
                            MediaUtils.actionRemoteScanStop();
                            return;
                        }
                    } catch (InterruptedException e) {
                        FabricHelper.logException(e);
                        e.printStackTrace();
                    }
                }
            }
        });
        thread.start();
    }

}
