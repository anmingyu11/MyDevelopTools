// TODO GUAN Copyright
package xyz.skybox.gui.localfile;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import xyz.skybox.R;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.gui.FragmentPagerAdapter;
import xyz.skybox.gui.MainActivity;
import xyz.skybox.gui.localfile.gallery.GalleryGridFragment;
import xyz.skybox.gui.localfile.myvideo.MyVideoGridFragment;
import xyz.skybox.media.MediaLibrary;

//TODO UN USED FOR NOW
public class LocalFilesFragment extends Fragment {

    private MainActivity mMainActivity;

    private final String SAVE_CURRENT_ITEM = "current_item";
    private final String SAVE_MY_VIDEO_TAG = "my_video_tag";
    private final String SAVE_GALLERY_TAG = "gallery_tag";

    // This is the ownViewPager
    private ViewPager mLocalViewPager;
    private int mCurrentItem = 0;
    private String mSaveMyVideoTag = null;
    private String mSaveGalleryTag = null;

    private MyVideoGridFragment mMyVideoFragment;
    private GalleryGridFragment mGalleryVideoFragment;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtil.e("onCreate start : " + savedInstanceState);

        if (savedInstanceState != null) {
            mCurrentItem = savedInstanceState.getInt(SAVE_CURRENT_ITEM);
            mSaveMyVideoTag = savedInstanceState.getString(SAVE_MY_VIDEO_TAG);
            mSaveGalleryTag = savedInstanceState.getString(SAVE_GALLERY_TAG);
        }

        LogUtil.e("onCreate end : " + savedInstanceState);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(SAVE_CURRENT_ITEM, mLocalViewPager.getCurrentItem());
        outState.putString(SAVE_MY_VIDEO_TAG, mMyVideoFragment.getTag());
        outState.putString(SAVE_GALLERY_TAG, mGalleryVideoFragment.getTag());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        LogUtil.e("onCreateView start");

        View view = inflater.inflate(R.layout.local_files_fragment, container, false);

        mLocalViewPager = (ViewPager) view.findViewById(R.id.fragment_view_pager);

        initFragments();

        LogUtil.e("onCreateView end");
        return view;
    }


    @Override
    public void onStart() {
        LogUtil.e("onStart start");
        super.onStart();

        initViewPager();
        LogUtil.e("onStart end");
    }

    private void initFragments() {
        if (mSaveGalleryTag != null) {
            mGalleryVideoFragment = (GalleryGridFragment) getChildFragmentManager().findFragmentByTag(mSaveGalleryTag);
        }

        if (mSaveMyVideoTag != null) {
            mMyVideoFragment = (MyVideoGridFragment) getChildFragmentManager().findFragmentByTag(mSaveMyVideoTag);
        }

        if (mMyVideoFragment == null) {
            mMyVideoFragment = new MyVideoGridFragment();
        }

        if (mGalleryVideoFragment == null) {
            mGalleryVideoFragment = new GalleryGridFragment();
        }
    }

    private void initViewPager() {
        LogUtil.e("Container id : " + mLocalViewPager.getId());
        mLocalViewPager.setAdapter(new FragmentPagerAdapter(getChildFragmentManager(), new Fragment[]{
                mMyVideoFragment,
                mGalleryVideoFragment
        }));
        mLocalViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                if (positionOffsetPixels == 0 && positionOffset == 0) {
                    if (position == 0) {
                        LogUtil.e(mMyVideoFragment.toString() + "\n" + mGalleryVideoFragment.toString());
                        mMyVideoFragment.pushUpFloatingActionBar();
                        mCurrentItem = 0;
                    } else if (position == 1) {
                        LogUtil.e(mMyVideoFragment.toString() + "\n" + mGalleryVideoFragment.toString());
                        mGalleryVideoFragment.pushUpFloatingActionBar();
                        mCurrentItem = 1;
                    } else {
                        LogUtil.e("For the further feature maybe");
                        return;
                    }
                }
            }

            @Override
            public void onPageSelected(int position) {
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });

        mLocalViewPager.setCurrentItem(mCurrentItem);
    }

    @Override
    public void onStop() {
        LogUtil.e(" onStop start");
        super.onStop();

        mLocalViewPager.clearOnPageChangeListeners();
        LogUtil.e(" onStop end");
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    public boolean isPushUp() {
        int currentItem = mLocalViewPager.getCurrentItem();
        if (currentItem == 0) {
            return mMyVideoFragment.isPushUp();
        } else if (currentItem == 1) {
            return mGalleryVideoFragment.isPushUp();
        } else {
            throw new RuntimeException("For the further feature maybe");
        }
    }

    @Override
    public void onResume() {
        LogUtil.e(" onResume start");

        super.onResume();
        if (getActivity() instanceof MainActivity)
            mMainActivity = (MainActivity) getActivity();

        if (mMainActivity != null) {
            mMainActivity.setViewPagerForLocalFilesTabStrip(mLocalViewPager);
        }

        LogUtil.e(" onResume end");
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        LogUtil.e(" onHiddenChanged : " + hidden);
        if (hidden) {
        }else {
            MediaLibrary.getInstance().notifyMediaUpdated();
        }
    }
}
