package xyz.skybox.gui.video;

import android.os.Message;

import xyz.skybox.interfaces.IVideoBrowser;
import xyz.skybox.media.MediaLibrary;
import xyz.skybox.media.MediaWrapper;
import xyz.skybox.util.WeakHandler;

public class VideoListHandler extends WeakHandler<IVideoBrowser> {

    public VideoListHandler(IVideoBrowser owner) {
        super(owner);
    }

    @Override
    public void handleMessage(Message msg) {
        IVideoBrowser owner = getOwner();
        if (owner == null) return;

        switch (msg.what) {
            case MediaLibrary.UPDATE_ITEM: {
                owner.updateItem((MediaWrapper) msg.obj);
                break;
            }
            case MediaLibrary.MEDIA_ITEMS_UPDATED: {
                owner.updateList();
                break;
            }
        }
    }
};
