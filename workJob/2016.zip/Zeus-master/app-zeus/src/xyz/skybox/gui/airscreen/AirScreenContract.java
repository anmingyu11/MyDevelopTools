package xyz.skybox.gui.airscreen;

import xyz.skybox.interfaces.BasePresenter;
import xyz.skybox.interfaces.BaseView;

public interface AirScreenContract {

    interface View extends BaseView<Presenter> {

        int showVideoGridFragment();

        int showConnectFragment();

    }

    interface Presenter extends BasePresenter {

    }

}
