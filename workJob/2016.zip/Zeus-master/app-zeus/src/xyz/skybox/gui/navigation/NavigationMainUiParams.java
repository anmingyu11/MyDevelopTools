package xyz.skybox.gui.navigation;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.View;

public abstract class NavigationMainUiParams {
    private Drawable mRightWhiteIcon = null;
    private Drawable mRightBlackIcon = null;
    private Drawable mLeftWhiteIcon = null;
    private Drawable mLeftBlackIcon = null;

    public final ObservableField<Drawable> mRightIcon = new ObservableField<Drawable>();
    public final ObservableField<Drawable> mLeftIcon = new ObservableField<Drawable>();
    public final ObservableField<Color> mTitleTextColor = null;
    public final ObservableField<Color> mTitleBarBackgroundColor = null;
    public final ObservableBoolean mIsPushUp = new ObservableBoolean(false);
    private String mTitle;

    public NavigationMainUiParams(
            Drawable rightWhiteIcon,
            Drawable leftWhiteIcon,
            Drawable rightBlackIcon,
            Drawable leftBlackIcon,
            Boolean isPushUp,
            String title) {
        setRightWhiteIcon(rightWhiteIcon);
        setLeftWhiteIcon(leftWhiteIcon);
        setRightBlackIcon(rightBlackIcon);
        setLeftBlackIcon(leftBlackIcon);
        setLeftIcon(mLeftWhiteIcon);
        setRightIcon(mRightWhiteIcon);
        setIsPushUp(isPushUp);
        setTitle(title);
    }

    public Drawable getRightWhiteIcon() {
        return mRightWhiteIcon;
    }

    public void setRightWhiteIcon(Drawable rightWhiteIcon) {
        mRightWhiteIcon = rightWhiteIcon;
    }

    public void setRightBlackIcon(Drawable rightBlackIcon) {
        mRightBlackIcon = rightBlackIcon;
    }

    public void setLeftWhiteIcon(Drawable leftWhiteIcon) {
        mLeftWhiteIcon = leftWhiteIcon;
    }

    public void setLeftBlackIcon(Drawable leftBlackIcon) {
        mLeftBlackIcon = leftBlackIcon;
    }

    public void emptyClick(View view) {
    }

    public abstract void rightOnClick(View view);

    public abstract void leftOnclick(View view);

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public void setRightIcon(Drawable rightIcon) {
        mRightIcon.set(rightIcon);
    }

    public void setLeftIcon(Drawable leftIcon) {
        mLeftIcon.set(leftIcon);
    }

    public void setIsPushUp(boolean isPushUp) {
        mIsPushUp.set(isPushUp);
        if (isPushUp) {
            setLeftIcon(mLeftBlackIcon);
            setRightIcon(mRightBlackIcon);
        } else {
            setLeftIcon(mLeftWhiteIcon);
            setRightIcon(mRightWhiteIcon);
        }
    }

}
