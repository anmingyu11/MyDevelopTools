package xyz.skybox.gui.airscreen;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import xyz.skybox.R;

import static xyz.skybox.R.drawable.title_bar_arrow_button_black;
import static xyz.skybox.R.drawable.title_bar_arrow_button_white;

public class AirScreenTitleBarWrapper {

    private Context mContext;
    private FrameLayout mTitleBar;
    private View mTitleBarTrigger;
    private GradientDrawable mTitleBarBackground;

    private ViewGroup mTitleText;
    private TextView mTitleName;
    private ImageView mTitleArrowButton;

    private TextView mTitleMaskBg;
    private GradientDrawable mTitleMaskBgDrawable;

    private TextView mDisconnectButton;
    private GradientDrawable mDisconnectButtonBackground;

    private boolean isPushUp;

    public AirScreenTitleBarWrapper(
            Context context,
            FrameLayout titleBar, ViewGroup titleText, TextView titleMaskBg, TextView disconnectButton,
            View trigger) {
        mContext = context;
        mTitleBar = titleBar;
        mTitleBarBackground = (GradientDrawable) mTitleBar.getBackground();
        mTitleMaskBg = titleMaskBg;
        mTitleMaskBgDrawable = (GradientDrawable) mTitleMaskBg.getBackground();
        mTitleText = titleText;
        mTitleName = (TextView) mTitleText.findViewById(R.id.air_screen_current_connected_server_name);
        mTitleArrowButton = (ImageView) mTitleText.findViewById(R.id.titlebar_arrow_button);
        mTitleBarTrigger = trigger;

        mDisconnectButton = disconnectButton;
        mDisconnectButtonBackground = (GradientDrawable) context.getResources().getDrawable(R.drawable.current_server_disconnect_white_bg);
        mDisconnectButtonBackground.setAlpha(0);
    }

    public void setTitleTextTopMargin(int topMargin) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) mTitleText.getLayoutParams();
        marginLayoutParams.topMargin = topMargin;
        mTitleText.setLayoutParams(marginLayoutParams);
    }

    public void setTitleBarTopMargin(int topMargin) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) mTitleBar.getLayoutParams();
        marginLayoutParams.topMargin = topMargin;
        mTitleBar.setLayoutParams(marginLayoutParams);
    }

    public void setTitleBarTriggerTopMargin(int topMargin) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) mTitleBarTrigger.getLayoutParams();
        marginLayoutParams.topMargin = topMargin;
        mTitleBarTrigger.setLayoutParams(marginLayoutParams);
    }

    public void setTitleBarDisconnectMarginBottom(int bottomMargin) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) mDisconnectButton.getLayoutParams();
        marginLayoutParams.bottomMargin = bottomMargin;
        mDisconnectButton.setLayoutParams(marginLayoutParams);
    }

    public void changeColorStylePushUp() {
        Resources res = mContext.getResources();

        mTitleBarBackground = (GradientDrawable) res.getDrawable(R.drawable.current_server_black_bg);
        mTitleBar.setBackground(mTitleBarBackground);
        mTitleMaskBgDrawable = (GradientDrawable) res.getDrawable(R.drawable.current_server_mask_black_bg);
        mTitleMaskBg.setBackground(mTitleMaskBgDrawable);

        mTitleArrowButton.setBackground(res.getDrawable(title_bar_arrow_button_white));
        mTitleName.setTextColor(res.getColorStateList(R.color.color_air_screen_title_server_black_bg_text_normal));

        mDisconnectButtonBackground.setAlpha(255);
        mDisconnectButtonBackground = (GradientDrawable) res.getDrawable(R.drawable.current_server_disconnect_black_bg);
        mDisconnectButton.setTextColor(res.getColorStateList(R.color.color_air_screen_title_disconnect_black_bg_text_normal));
        mDisconnectButton.setBackground(mDisconnectButtonBackground);
    }

    public void changeColorStylePushDown() {
        Resources res = mContext.getResources();

        mTitleBarBackground = (GradientDrawable) res.getDrawable(R.drawable.current_server_white_bg);
        mTitleBar.setBackground(mTitleBarBackground);
        mTitleMaskBgDrawable = (GradientDrawable) res.getDrawable(R.drawable.current_server_mask_white_bg);
        mTitleMaskBg.setBackground(mTitleMaskBgDrawable);

        mTitleArrowButton.setBackground(res.getDrawable(title_bar_arrow_button_black));
        mTitleName.setTextColor(res.getColorStateList(R.color.color_air_screen_title_server_white_bg_text_normal));

        mDisconnectButtonBackground.setAlpha(255);
        mDisconnectButtonBackground = (GradientDrawable) res.getDrawable(R.drawable.current_server_disconnect_white_bg);
        mDisconnectButton.setTextColor(res.getColorStateList(R.color.color_air_screen_title_disconnect_white_bg_text_normal));
        mDisconnectButton.setBackground(mDisconnectButtonBackground);
    }

    public void setTitleBarWidth(int width) {
        mTitleBar.getLayoutParams().width = width;
        mTitleBar.requestLayout();
    }

    public void setTitleBarHeight(int height) {
        mTitleBar.getLayoutParams().height = height;
        mTitleBar.requestLayout();
    }

    public void setTitleBarMarginTop(int marginTop) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) mTitleBar.getLayoutParams();
        marginLayoutParams.topMargin = marginTop;
        mTitleBar.setLayoutParams(marginLayoutParams);
    }

    public void setTitleBarCornerRadius(float cornerRadius) {
        mTitleBarBackground.setCornerRadius(cornerRadius);
        mTitleMaskBgDrawable.setCornerRadii(new float[]{cornerRadius, cornerRadius, cornerRadius, cornerRadius, 0, 0, 0, 0});
        mTitleMaskBg.setBackground(mTitleMaskBgDrawable);
        mTitleBar.setBackground(mTitleBarBackground);
    }

    public void setTitleMaskBgWidth(int width) {
        mTitleMaskBg.getLayoutParams().width = width;
        mTitleMaskBg.requestLayout();
    }

    public void setTitleMaskBgHeight(int height) {
        mTitleMaskBg.getLayoutParams().height = height;
        mTitleMaskBg.requestLayout();
    }

    public int getTitleBarWidth() {
        return mTitleBar.getLayoutParams().width;
    }

    public int getTitleBarHeight() {
        return mTitleBar.getLayoutParams().height;
    }

    public int getTitleMaskBgWidth() {
        return mTitleMaskBg.getLayoutParams().width;
    }

    public int getTitleMaskBgHeight() {
        return mTitleMaskBg.getLayoutParams().height;
    }

    public void setDisconnectButtonAlpha(float alpha) {
        int alphaValue = (int) (255 * alpha);
        if (mDisconnectButton.getVisibility() == View.GONE) {
            mDisconnectButton.setVisibility(View.VISIBLE);
        }
        mDisconnectButtonBackground.setAlpha(alphaValue);
        mDisconnectButton.setBackground(mDisconnectButtonBackground);
    }

    public void setDisconnectButtonBackgroundAlpha(float alpha) {
        int alphaValue = (int) (255 * alpha);
        mDisconnectButtonBackground.setAlpha(alphaValue);
    }

    public boolean isPushUp() {
        return isPushUp;
    }

    public void setPushUp(boolean pushUp) {
        isPushUp = pushUp;
    }
}
