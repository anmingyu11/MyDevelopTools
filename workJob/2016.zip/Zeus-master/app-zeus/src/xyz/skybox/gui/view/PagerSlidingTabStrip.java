// TODO GUAN Copyright
package xyz.skybox.gui.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import xyz.skybox.R;

public class PagerSlidingTabStrip extends HorizontalScrollView {
    private int mCurrentPosition;
    private int mLastOffset;
    private int mLastScrollX = 0;
    private float mCurrentPositionOffset;
    private boolean mStart;
    private boolean mAllowWidthFull;  // When the width of the content can not be filled, it is allowed to automatically adjust the width of Item to fill.
    private boolean mDisableViewPager;
    private Drawable mSlidingBlockDrawable;
    private ViewPager mViewPager;
    private ViewGroup mTabsLayout;
    private ViewPager.OnPageChangeListener mOnPageChangeListener;
    private OnClickTabListener mOnClickTabListener;
    private OnDoubleClickTabListener mOnDoubleClickTabListener;
    private List<View> mTabViews;
    private boolean mDisableTensileSlidingBlock;
    private TabViewFactory mTabViewFactory;
    private Paint mBottomLinePaint;
    private int mBottomLineColor = -1;
    private int mBottomLineHeight = -1;
    private final PageChangedListener mPageChangedListener = new PageChangedListener();
    private final TabViewClickListener mTabViewClickListener = new TabViewClickListener();
    private final SetSelectedTabListener mSetSelectedTabListener = new SetSelectedTabListener();
    private final DoubleClickGestureDetector mTabViewDoubleClickGestureDetector;

    public PagerSlidingTabStrip(Context context) {
        this(context, null);
    }

    public PagerSlidingTabStrip(Context context, AttributeSet attrs) {
        super(context, attrs);
        setHorizontalScrollBarEnabled(false);    // Hide horizontal scroll bar.
        removeAllViews();
        if (attrs != null) {
            TypedArray attrsTypedArray = context.obtainStyledAttributes(attrs, R.styleable.PagerSlidingTabStrip);
            if (attrsTypedArray != null) {
                mAllowWidthFull = attrsTypedArray.getBoolean(R.styleable.PagerSlidingTabStrip_allowWidthFull, false);
                mSlidingBlockDrawable = attrsTypedArray.getDrawable(R.styleable.PagerSlidingTabStrip_slidingBlock);
                mDisableViewPager = attrsTypedArray.getBoolean(R.styleable.PagerSlidingTabStrip_disableViewPager, false);
                mDisableTensileSlidingBlock = attrsTypedArray.getBoolean(R.styleable.PagerSlidingTabStrip_disableTensileSlidingBlock, false);
                mBottomLineColor = attrsTypedArray.getColor(R.styleable.PagerSlidingTabStrip_bottomLineColor, -1);
                mBottomLineHeight = (int) attrsTypedArray.getDimension(R.styleable.PagerSlidingTabStrip_bottomLineHeight, -1);
                attrsTypedArray.recycle();
            }
        }
        mTabViewDoubleClickGestureDetector = new DoubleClickGestureDetector(context);

        getViewTreeObserver().addOnGlobalLayoutListener(mSetSelectedTabListener);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (mAllowWidthFull && mTabsLayout != null) {
            View childView;
            for (int w = 0, size = mTabsLayout.getChildCount(); w < size; w++) {
                childView = mTabsLayout.getChildAt(w);
                ViewGroup.LayoutParams params = childView.getLayoutParams();
                params.width = ViewGroup.LayoutParams.WRAP_CONTENT;
                childView.setLayoutParams(params);
            }
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        if (!mAllowWidthFull) {
            return;
        }
        ViewGroup tabsLayout = getTabsLayout();
        if (tabsLayout == null) {
            return;
        }
        if (tabsLayout.getChildCount() <= 0) {
            return;
        }

        if (mTabViews == null) {
            mTabViews = new ArrayList<View>();
        } else {
            mTabViews.clear();
        }
        for (int w = 0; w < tabsLayout.getChildCount(); w++) {
            mTabViews.add(tabsLayout.getChildAt(w));
        }

        adjustChildWidthWithParent(mTabViews, getMeasuredWidth() - tabsLayout.getPaddingLeft() - tabsLayout.getPaddingRight(), widthMeasureSpec, heightMeasureSpec);

        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    /**
     * Adjust the View in the views collection so that the width of all views is exactly equal to the parentViewWidth.
     *
     * @param views                   the views collection
     * @param parentViewWidth         parent view width
     * @param parentWidthMeasureSpec  parent width measure spec
     * @param parentHeightMeasureSpec parent height measure spec
     */
    private void adjustChildWidthWithParent(List<View> views, int parentViewWidth, int parentWidthMeasureSpec, int parentHeightMeasureSpec) {
        // At first, remove the outer margin of all child View.
        for (View view : views) {
            if (view.getLayoutParams() instanceof MarginLayoutParams) {
                MarginLayoutParams lp = (MarginLayoutParams) view.getLayoutParams();
                parentViewWidth -= lp.leftMargin + lp.rightMargin;
            }
        }

        // After removing the View that is wider than the average width, calculate the average width again.
        int averageWidth = parentViewWidth / views.size();
        int bigTabCount = views.size();
        while (true) {
            Iterator<View> iterator = views.iterator();
            while (iterator.hasNext()) {
                View view = iterator.next();
                if (view.getMeasuredWidth() > averageWidth) {
                    parentViewWidth -= view.getMeasuredWidth();
                    bigTabCount--;
                    iterator.remove();
                }
            }
            if (bigTabCount <= 0) {
                break;
            }
            averageWidth = parentViewWidth / bigTabCount;
            boolean end = true;
            for (View view : views) {
                if (view.getMeasuredWidth() > averageWidth) {
                    end = false;
                }
            }
            if (end) {
                break;
            }
        }

        // Modify the width of a View that is less than the new average width.
        for (View view : views) {
            if (view.getMeasuredWidth() < averageWidth) {
                ViewGroup.LayoutParams layoutParams = (ViewGroup.LayoutParams) view.getLayoutParams();
                layoutParams.width = averageWidth;
                view.setLayoutParams(layoutParams);
                // Measure again to make the new width effective.
                if (layoutParams instanceof MarginLayoutParams) {
                    measureChildWithMargins(view, parentWidthMeasureSpec, 0, parentHeightMeasureSpec, 0);
                } else {
                    measureChild(view, parentWidthMeasureSpec, parentHeightMeasureSpec);
                }
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mBottomLineColor != -1 && mBottomLineHeight != -1) {
            if (mBottomLinePaint == null) {
                mBottomLinePaint = new Paint();
                mBottomLinePaint.setColor(mBottomLineColor);
            }
            canvas.drawRect(0, getBottom() - mBottomLineHeight, getRight(), getBottom(), mBottomLinePaint);
        }

        if (mDisableViewPager) return;
        // Draw sliding tab.
        ViewGroup tabsLayout = getTabsLayout();
        if (tabsLayout != null && tabsLayout.getChildCount() > 0 && mSlidingBlockDrawable != null) {
            View currentTab = tabsLayout.getChildAt(mCurrentPosition);
            if (currentTab != null) {
                float slidingBlockLeft = currentTab.getLeft();
                float slidingBlockRight = currentTab.getRight();
                if (mCurrentPositionOffset > 0f && mCurrentPosition < tabsLayout.getChildCount() - 1) {
                    View nextTab = tabsLayout.getChildAt(mCurrentPosition + 1);
                    if (nextTab != null) {
                        final float nextTabLeft = nextTab.getLeft();
                        final float nextTabRight = nextTab.getRight();
                        slidingBlockLeft = (mCurrentPositionOffset * nextTabLeft + (1f - mCurrentPositionOffset) * slidingBlockLeft);
                        slidingBlockRight = (mCurrentPositionOffset * nextTabRight + (1f - mCurrentPositionOffset) * slidingBlockRight);
                    }
                }

                // Do not stretch.
                if (mDisableTensileSlidingBlock) {
                    int center = (int) (slidingBlockLeft + (slidingBlockRight - slidingBlockLeft) / 2);
                    slidingBlockLeft = center - mSlidingBlockDrawable.getIntrinsicWidth() / 2;
                    slidingBlockRight = center + mSlidingBlockDrawable.getIntrinsicWidth() / 2;
                }

                mSlidingBlockDrawable.setBounds((int) slidingBlockLeft, 0, (int) slidingBlockRight, getHeight());
                mSlidingBlockDrawable.draw(canvas);
            }
        }
    }

    private ViewGroup getTabsLayout() {
        if (mTabsLayout == null) {
            if (getChildCount() > 0) {
                mTabsLayout = (ViewGroup) getChildAt(0);
            } else {
                removeAllViews();
                LinearLayout tabsLayout = new LinearLayout(getContext());
                tabsLayout.setGravity(Gravity.CENTER_VERTICAL);
                this.mTabsLayout = tabsLayout;
                addView(tabsLayout, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL));
            }
        }
        return mTabsLayout;
    }

    /**
     * Clean and reset all tabs.
     */
    public void reset() {
        if (mTabViewFactory != null) {
            ViewGroup tabViewGroup = getTabsLayout();
            mTabViewFactory.addTabs(tabViewGroup, mViewPager != null ? mViewPager.getCurrentItem() : 0);
            setTabClickEvent();
        }
    }

    private void setTabClickEvent() {
        ViewGroup tabViewGroup = getTabsLayout();
        if (tabViewGroup != null && tabViewGroup.getChildCount() > 0) {
            // Set the click event for each item, and toggle the Pager when clicked.
            for (int w = 0; w < tabViewGroup.getChildCount(); w++) {
                View itemView = tabViewGroup.getChildAt(w);
                itemView.setTag(w);
                itemView.setOnClickListener(mTabViewClickListener);
                itemView.setOnTouchListener(mTabViewDoubleClickGestureDetector);
            }
        }
    }

    /**
     * Get Tab by position.
     *
     * @param position position
     * @return View of Tab
     */
    @SuppressWarnings("unused")
    public View getTab(int position) {
        if (mTabsLayout != null && mTabsLayout.getChildCount() > position) {
            return mTabsLayout.getChildAt(position);
        } else {
            return null;
        }
    }

    /**
     * Scroll to a specific location.
     */
    private void scrollToChild(int position, int offset) {
        ViewGroup tabsLayout = getTabsLayout();
        if (tabsLayout != null && tabsLayout.getChildCount() > 0 && position < tabsLayout.getChildCount()) {
            View view = tabsLayout.getChildAt(position);
            if (view != null) {
                // Calculates the new X coordinate.
                int newScrollX = view.getLeft() + offset - getLeftMargin(view);
                if (position > 0 || offset > 0) {
                    newScrollX -= getWidth() / 2 - getOffset(view.getWidth()) / 2;
                }

                // If not the same as the previous X coordinate to perform the rolling.
                if (newScrollX != mLastScrollX) {
                    mLastScrollX = newScrollX;
                    scrollTo(newScrollX, 0);
                }
            }
        }
    }

    private int getLeftMargin(View view) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        if (params instanceof MarginLayoutParams) {
            MarginLayoutParams marginParams = (MarginLayoutParams) params;
            return marginParams.leftMargin;
        }
        return 0;
    }

    private int getRightMargin(View view) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        if (params instanceof MarginLayoutParams) {
            MarginLayoutParams marginParams = (MarginLayoutParams) params;
            return marginParams.rightMargin;
        }
        return 0;
    }

    private int getOffset(int newOffset) {
        if (mLastOffset < newOffset) {
            if (mStart) {
                mLastOffset += 1;
                return mLastOffset;
            } else {
                mStart = true;
                mLastOffset += 1;
                return mLastOffset;
            }
        }
        if (mLastOffset > newOffset) {
            if (mStart) {
                mLastOffset -= 1;
                return mLastOffset;
            } else {
                mStart = true;
                mLastOffset -= 1;
                return mLastOffset;
            }
        } else {
            mStart = true;
            mLastOffset = newOffset;
            return mLastOffset;
        }
    }

    /**
     * Select Tab by position.
     */
    public void selectedTab(int newSelectedTabPosition) {
        ViewGroup tabsLayout = getTabsLayout();
        if (newSelectedTabPosition > -1 && tabsLayout != null && newSelectedTabPosition < tabsLayout.getChildCount()) {
            for (int w = 0, size = tabsLayout.getChildCount(); w < size; w++) {
                View tabView = tabsLayout.getChildAt(w);
                tabView.setSelected(w == newSelectedTabPosition);
            }
        }
    }

    public void setViewPager(ViewPager viewPager) {
        if (mDisableViewPager) return;
        this.mViewPager = viewPager;
        this.mViewPager.addOnPageChangeListener(mPageChangedListener);
        setTabClickEvent();
        requestLayout();
    }

    @SuppressWarnings("unused")
    public void setOnPageChangeListener(OnPageChangeListener onPageChangeListener) {
        this.mOnPageChangeListener = onPageChangeListener;
    }

    /**
     * Set fill the screen.
     *
     * @param allowWidthFull true： When the width of the content can not fill the screen,
     *                       automatically adjust the width of each item to fill the screen.
     */
    public void setAllowWidthFull(boolean allowWidthFull) {
        this.mAllowWidthFull = allowWidthFull;
        requestLayout();
    }

    @SuppressWarnings("unused")
    public void setSlidingBlockDrawable(Drawable slidingBlockDrawable) {
        this.mSlidingBlockDrawable = slidingBlockDrawable;
        requestLayout();
    }

    @SuppressWarnings("unused")
    public Drawable getSlidingBlockDrawable() {
        return mSlidingBlockDrawable;
    }

    @SuppressWarnings("unused")
    public void setDisableTensileSlidingBlock(boolean disableTensileSlidingBlock) {
        this.mDisableTensileSlidingBlock = disableTensileSlidingBlock;
        invalidate();
    }

    public int getTabCount() {
        ViewGroup tabsLayout = getTabsLayout();
        return tabsLayout != null ? tabsLayout.getChildCount() : 0;
    }

    @SuppressWarnings("unused")
    public void setOnClickTabListener(OnClickTabListener onClickTabListener) {
        this.mOnClickTabListener = onClickTabListener;
    }

    public void setOnDoubleClickTabListener(OnDoubleClickTabListener onDoubleClickTabListener) {
        this.mOnDoubleClickTabListener = onDoubleClickTabListener;
    }

    @SuppressWarnings("unused")
    public void setDisableViewPager(boolean disableViewPager) {
        this.mDisableViewPager = disableViewPager;
        if (mViewPager != null) {
            mViewPager.removeOnPageChangeListener(mOnPageChangeListener);
            mViewPager = null;
        }
        requestLayout();
    }

    @SuppressWarnings("unused")
    public void setTabViewFactory(TabViewFactory tabViewFactory) {
        this.mTabViewFactory = tabViewFactory;

        reset();

        getViewTreeObserver().addOnGlobalLayoutListener(mSetSelectedTabListener);
    }

    @SuppressWarnings("unused")
    public void setBottomLineColor(int bottomLineColor) {
        this.mBottomLineColor = bottomLineColor;
        if (mBottomLinePaint != null) {
            mBottomLinePaint.setColor(bottomLineColor);
        }
        postInvalidate();
    }

    @SuppressWarnings("unused")
    public void setBottomLineHeight(int bottomLineHeight) {
        this.mBottomLineHeight = bottomLineHeight;
        postInvalidate();
    }

    public interface OnClickTabListener {
        void onClickTab(View tab, int index);
    }

    public interface OnDoubleClickTabListener {
        void onDoubleClickTab(View view, int index);
    }

    public interface TabViewFactory {
        /**
         * Add Tab
         *
         * @param parent              parent view
         * @param currentItemPosition current item position
         */
        void addTabs(ViewGroup parent, int currentItemPosition);
    }

    private class PageChangedListener implements ViewPager.OnPageChangeListener {
        @Override
        public void onPageSelected(int position) {
            selectedTab(position);
            if (mOnPageChangeListener != null) {
                mOnPageChangeListener.onPageSelected(position);
            }
        }

        @Override
        public void onPageScrolled(int nextPagePosition, float positionOffset, int positionOffsetPixels) {
            ViewGroup tabsLayout = getTabsLayout();
            if (nextPagePosition < tabsLayout.getChildCount()) {
                View view = tabsLayout.getChildAt(nextPagePosition);
                if (view != null) {
                    mCurrentPosition = nextPagePosition;
                    mCurrentPositionOffset = positionOffset;
                    scrollToChild(nextPagePosition, (int) (positionOffset * (view.getWidth() + getLeftMargin(view) + getRightMargin(view))));
                    invalidate();
                }
            }
            if (mOnPageChangeListener != null) {
                mOnPageChangeListener.onPageScrolled(nextPagePosition, positionOffset, positionOffsetPixels);
            }
        }

        @Override
        public void onPageScrollStateChanged(int arg0) {
            if (mOnPageChangeListener != null) {
                mOnPageChangeListener.onPageScrollStateChanged(arg0);
            }
        }
    }

    private class TabViewClickListener implements OnClickListener {
        @Override
        public void onClick(View v) {
            int index = (Integer) v.getTag();
            if (mOnClickTabListener != null) {
                mOnClickTabListener.onClickTab(v, index);
            }
            if (mViewPager != null) {
                mViewPager.setCurrentItem(index, true);
            }
        }
    }

    private class SetSelectedTabListener implements ViewTreeObserver.OnGlobalLayoutListener {
        @Override
        public void onGlobalLayout() {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                getViewTreeObserver().removeGlobalOnLayoutListener(this);
            } else {
                getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }

            ViewGroup tabViewGroup = getTabsLayout();
            if (tabViewGroup != null) {
                mCurrentPosition = mViewPager != null ? mViewPager.getCurrentItem() : 0;
                if (!mDisableViewPager) {
                    scrollToChild(mCurrentPosition, 0);
                    selectedTab(mCurrentPosition);
                }
            }
        }
    }

    private class DoubleClickGestureDetector extends GestureDetector.SimpleOnGestureListener implements OnTouchListener {
        private GestureDetector gestureDetector;
        private View currentView;

        public DoubleClickGestureDetector(Context context) {
            gestureDetector = new GestureDetector(context, this);
            gestureDetector.setOnDoubleTapListener(this);
        }

        @Override
        public boolean onDoubleTap(MotionEvent e) {
            if (mOnDoubleClickTabListener != null) {
                mOnDoubleClickTabListener.onDoubleClickTab(currentView, (Integer) currentView.getTag());
                return true;
            } else {
                return false;
            }
        }

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            currentView = v;
            return gestureDetector.onTouchEvent(event);
        }
    }
}
