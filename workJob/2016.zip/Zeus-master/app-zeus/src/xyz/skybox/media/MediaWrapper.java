package xyz.skybox.media;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

import java.io.File;
import java.util.Locale;

import wseemann.media.FFmpegMediaMetadataRetriever;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.util.BitmapUtil;
import xyz.skybox.util.Extensions;
import xyz.skybox.util.FileHelper;
import xyz.skybox.util.Strings;

import static xyz.skybox.util.Util.printExceptionLog;

public class MediaWrapper implements Parcelable {

    public final static int TYPE_ALL = -1;
    public final static int TYPE_VIDEO = 0;
    public final static int TYPE_AUDIO = 1;
    public final static int TYPE_GROUP = 2;
    public final static int TYPE_DIR = 3;
    public final static int TYPE_SUBTITLE = 4;
    public final static int TYPE_PLAYLIST = 5;
//    public final static int TYPE_REMOTE_VIDEO = 6; // It's in RemoteMediaWrapper.

    public boolean DO_HIGH_RCG = false;

    public final static int MEDIA_VIDEO = 0x01;
    public final static int MEDIA_NO_HWACCEL = 0x02;
    public final static int MEDIA_PAUSED = 0x4;
    public final static int MEDIA_FORCE_AUDIO = 0x8;

    protected String mTitle;
    protected String mDisplayTitle;
    private String mArtist;
    private String mGenre;
    private String mCopyright;
    private String mAlbum;
    private int mTrackNumber;
    private int mDiscNumber;
    private String mAlbumArtist;
    private String mDescription;
    private String mRating;
    private String mDate;
    private String mSettings;
    private String mNowPlaying;
    private String mPublisher;
    private String mEncodedBy;
    private String mTrackID;
    private String mArtworkURL;
    private long size;
    private String mRcgType; //MEDIA_RCG_TYPE
    private String mUserRcgType; //MEDIA_USER_RCG_TYPE

    private final Uri mUri;
    private String mFilename;
    private long mTime = 0;
    /* -1 is a valid track (Disabled) */
    private int mAudioTrack = -2;
    private int mSpuTrack = -2;
    private long mLength = 0;
    private long mSize = 0;// file size
    private int mType;
    private int mWidth = 0;
    private int mHeight = 0;
    private Bitmap mPicture;
    private boolean mIsPictureParsed;
    private int mFlags = 0;
    private long mLastModified = 0l;

//    private Media.Slave mSlaves[] = null;

    /**
     * Create a new MediaWrapper
     * @param uri Should not be null.
     */
    public MediaWrapper(Uri uri) {
        if (uri == null)
            throw new NullPointerException("uri was null");

        mUri = uri;
        init(uri);
    }

    @Override
    public boolean equals(Object obj) {
        Uri otherUri = ((MediaWrapper) obj).getUri();
        if (mUri == null || otherUri == null)
            return false;
        if (mUri == otherUri)
            return true;
        return mUri.equals(otherUri);
    }

    private void init(Uri uri) {

        String fileURI = uri.toString();

        if (TextUtils.isEmpty(fileURI)) {
            LogUtil.e("fileURI is null. "+fileURI);
            return;
        }

        if (!fileURI.contains("file://")) {
            LogUtil.e("fileURI is not file:// ("+fileURI+")");
            return;
        }

        // This uri string was encoded, need to decode.
        fileURI = Uri.decode(fileURI);

        File sourceFile = new File(fileURI.replace("file://", ""));
        if (!sourceFile.exists()) {
            LogUtil.e("sourceFile does not exist. ");
            return;
        }

        try {
            FFmpegMediaMetadataRetriever mmr = new FFmpegMediaMetadataRetriever();
            try {
                String path = sourceFile.getAbsolutePath();
                FileHelper fileHelper = FileHelper.getInstance();
                fileHelper.writeToLogFile(FileHelper.START_TAG);
                fileHelper.writeToLogFile(FileHelper.READ_PREFIX + path);

                mmr.setDataSource(sourceFile.getAbsolutePath());

                mLength = parseLong(mmr.extractMetadata(FFmpegMediaMetadataRetriever.METADATA_KEY_DURATION));
                mWidth = parseInt(mmr.extractMetadata(FFmpegMediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
                mHeight = parseInt(mmr.extractMetadata(FFmpegMediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
                mTitle = mmr.extractMetadata(FFmpegMediaMetadataRetriever.METADATA_KEY_TITLE);// return null
                mArtist = mmr.extractMetadata(FFmpegMediaMetadataRetriever.METADATA_KEY_ARTIST);
                mAlbum = mmr.extractMetadata(FFmpegMediaMetadataRetriever.METADATA_KEY_ALBUM);

                mmr.release();
                fileHelper.writeToLogFile(FileHelper.SUCCESS_TAG);

                mTitle = getTitle();
                mSize = sourceFile.length();
                mType = TYPE_ALL;
                defineType();

            } catch (Exception e) {
                String name = "FMMR setDataSource Exception, path: "+sourceFile.getAbsolutePath();
                printExceptionLog(name, e.getMessage(), LogUtil.getStackTrace());

            } finally {
                mmr.release();
            }
        } catch (Exception e) {
            String name = "new FMMR Exception, path: "+sourceFile.getAbsolutePath();
            printExceptionLog(name, e.getMessage(), LogUtil.getStackTrace());
        }
    }

    private int parseInt(String string) {
        if (!TextUtils.isEmpty(string)) {
            try {
                return Integer.parseInt(string);
            } catch (NumberFormatException ignored) {
            }
        }
        return -1;
    }

    private long parseLong(String string) {
        if (!TextUtils.isEmpty(string)) {
            try {
                return Long.parseLong(string);
            } catch (NumberFormatException ignored) {
            }
        }
        return -1;
    }

    public void defineType() {
        if (mType != TYPE_ALL)
            return;

        String fileExt = null, filename = mUri.getLastPathSegment();
        if (TextUtils.isEmpty(filename))
            filename = mTitle;
        if (TextUtils.isEmpty(filename))
            return;
        int index = filename.indexOf('?');
        if (index != -1)
            filename = filename.substring(0, index);

        index = filename.lastIndexOf(".");

        if (index != -1)
            fileExt = filename.substring(index).toLowerCase(Locale.ENGLISH);

        if (!TextUtils.isEmpty(fileExt)) {
            if (Extensions.VIDEO.contains(fileExt)) {
                mType = TYPE_VIDEO;
            } else if (Extensions.AUDIO.contains(fileExt)) {
                mType = TYPE_AUDIO;
            } else if (Extensions.SUBTITLES.contains(fileExt)) {
                mType = TYPE_SUBTITLE;
            } else if (Extensions.PLAYLIST.contains(fileExt)) {
                mType = TYPE_PLAYLIST;
            }
        }
    }

    private void init(long time, long length, int type,
                      Bitmap picture, String title, String artist, String genre, String album, String albumArtist,
                      int width, int height, String artworkURL, int audio, int spu, int trackNumber, int discNumber, long lastModified,
                      String rcgType, String userRcgType, long size) {
        mFilename = null;
        mTime = time;
        mAudioTrack = audio;
        mSpuTrack = spu;
        mLength = length;
        mType = type;
        mPicture = picture;
        mWidth = width;
        mHeight = height;

        mTitle = title;
        mArtist = artist;
        mGenre = genre;
        mAlbum = album;
        mAlbumArtist = albumArtist;
        mArtworkURL = artworkURL;
        mTrackNumber = trackNumber;
        mDiscNumber = discNumber;
        mLastModified = lastModified;

        mRcgType = rcgType;
        mUserRcgType = userRcgType;
        mSize = size;

//        mSlaves = slaves;
    }

    public MediaWrapper(Uri uri, long time, long length, int type,
                        Bitmap picture, String title, String artist, String genre, String album, String albumArtist,
                        int width, int height, String artworkURL, int audio, int spu, int trackNumber, int discNumber, long lastModified,
                        String rcgType, String userRcgType, long size) {
        mUri = uri;
        init(time, length, type, picture, title, artist, genre, album, albumArtist,
                width, height, artworkURL, audio, spu, trackNumber, discNumber, lastModified,
                rcgType, userRcgType, size);
    }

    public String getLocation() {
        return mUri.toString();
    }

    public Uri getUri() {
        return mUri;
    }

    public String getFileName() {
        if (mFilename == null) {
            mFilename = mUri.getLastPathSegment();
        }
        return mFilename;
    }

    public long getTime() {
        return mTime;
    }

    public void setTime(long time) {
        mTime = time;
    }

    public int getAudioTrack() {
        return mAudioTrack;
    }

    public void setAudioTrack(int track) {
        mAudioTrack = track;
    }

    public int getSpuTrack() {
        return mSpuTrack;
    }

    public void setSpuTrack(int track) {
        mSpuTrack = track;
    }

    public long getLength() {
        return mLength;
    }

    public int getType() {
        return mType;
    }

    public void setType(int type) {
        mType = type;
    }

    public int getWidth() {
        return mWidth;
    }

    public int getHeight() {
        return mHeight;
    }

    public long getSize() {
        return mSize;
    }

    /**
     * Returns the raw picture object. Likely to be NULL in VLC for Android
     * due to lazy-loading.
     *
     * Use {@link BitmapUtil#getPictureFromCache(MediaWrapper)} instead.
     *
     * @return The raw picture or NULL
     */
    public Bitmap getPicture() {
        return mPicture;
    }

    /**
     * Sets the raw picture object.
     *
     * In VLC for Android, use {@link MediaDatabase#setPicture(MediaWrapper, Bitmap)} instead.
     *
     * @param p
     */
    public void setPicture(Bitmap p) {
        mPicture = p;
    }

    public boolean isPictureParsed() {
        return mIsPictureParsed;
    }

    public void setPictureParsed(boolean isParsed) {
        mIsPictureParsed = isParsed;
    }

    public void setDisplayTitle(String title) {
        // TODO:  mDisplayTitle and mTitle, mDisplayTitle is not used.
        mDisplayTitle = title;
    }

    public void setArtist(String artist) {
        mArtist = artist;
    }

    public String getTitle() {
        String fileName = getFileName();
        return Strings.formatTitle(fileName);
    }

    public String getReferenceArtist() {
        return mAlbumArtist == null ? mArtist : mAlbumArtist;
    }

    public String getArtist() {
        return mArtist;
    }

    public Boolean isArtistUnknown() {
        return mArtist == null;
    }

    public String getGenre() {
        if (mGenre == null)
            return null;
        else if (mGenre.length() > 1)/* Make genres case insensitive via normalisation */
            return Character.toUpperCase(mGenre.charAt(0)) + mGenre.substring(1).toLowerCase(Locale.getDefault());
        else
            return mGenre;
    }

    public String getCopyright() {
        return mCopyright;
    }

    public String getAlbum() {
        return mAlbum;
    }

    public String getAlbumArtist() {
        return mAlbumArtist;
    }

    public Boolean isAlbumUnknown() {
        return mAlbum == null;
    }

    public int getTrackNumber() {
        return mTrackNumber;
    }

    public int getDiscNumber() {
        return mDiscNumber;
    }

    public void setDescription(String description) {
        mDescription = description;
    }

    public String getDescription() {
        return mDescription;
    }

    public String getRating() {
        return mRating;
    }

    public String getDate() {
        return mDate;
    }

    public String getSettings() {
        return mSettings;
    }

    public String getNowPlaying() {
        return mNowPlaying;
    }

    public String getPublisher() {
        return mPublisher;
    }

    public String getEncodedBy() {
        return mEncodedBy;
    }

    public String getTrackID() {
        return mTrackID;
    }

    public String getArtworkURL() {
        return mArtworkURL;
    }

    public void setArtworkURL(String url) {
        mArtworkURL = url;
    }

    public long getLastModified() {
        return mLastModified;
    }

    public void setLastModified(long mLastModified) {
        this.mLastModified = mLastModified;
    }

    public void addFlags(int flags) {
        mFlags |= flags;
    }

    public void setFlags(int flags) {
        mFlags = flags;
    }

    public int getFlags() {
        return mFlags;
    }

    public boolean hasFlag(int flag) {
        return (mFlags & flag) != 0;
    }

    public void removeFlags(int flags) {
        mFlags &= ~flags;
    }

    public void setRcgType(String rcgType) {
        mRcgType = rcgType;
    }

    public String getRcgType() {
        return mRcgType;
    }

    public void setUserRcgType(String rcgType) {
        mUserRcgType = rcgType;
    }

    public String getUserRcgType() {
        return mUserRcgType;
    }

    public String getFormatTime() {
        String text = "";

        /* Time / Duration */
        if (getLength() > 0) {
            long lastTime = getTime();
            if (lastTime > 0) {
                text = String.format("%s / %s",
                        Strings.millisToText(lastTime),
                        Strings.millisToText(getLength()));
            } else {
                text = Strings.millisToText(getLength());
            }
        }
        return text;
    }

    public void showDetails() {
        LogUtil.d(
                "mLength=" + mLength +
                        ", mWidth=" + mWidth +
                        ", mHeight=" + mHeight +
                        ", mFilename='" + mFilename + '\'' +
                        ", mTitle='" + mTitle + '\'' +
                        ", mDisplayTitle='" + mDisplayTitle + '\'' +
                        ", mUri=" + mUri +
                        ", time=" + mTime +
                        '}');
    }

//    @Nullable
//    public Media.Slave[] getSlaves() {
//        return mSlaves;
//    }

    @Override
    public int describeContents() {
        return 0;
    }

    public MediaWrapper(Parcel in) {
        mUri = in.readParcelable(Uri.class.getClassLoader());
        init(in.readLong(),
                in.readLong(),
                in.readInt(),
                (Bitmap) in.readParcelable(Bitmap.class.getClassLoader()),
                in.readString(),
                in.readString(),
                in.readString(),
                in.readString(),
                in.readString(),
                in.readInt(),
                in.readInt(),
                in.readString(),
                in.readInt(),
                in.readInt(),
                in.readInt(),
                in.readInt(),
                in.readLong(),
                in.readString(),
                in.readString(),
                in.readLong());
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(mUri, flags);
        dest.writeLong(getTime());
        dest.writeLong(getLength());
        dest.writeInt(getType());
        dest.writeParcelable(getPicture(), flags);
        dest.writeString(getTitle());
        dest.writeString(getArtist());
        dest.writeString(getGenre());
        dest.writeString(getAlbum());
        dest.writeString(getAlbumArtist());
        dest.writeInt(getWidth());
        dest.writeInt(getHeight());
        dest.writeString(getArtworkURL());
        dest.writeInt(getAudioTrack());
        dest.writeInt(getSpuTrack());
        dest.writeInt(getTrackNumber());
        dest.writeInt(getDiscNumber());
        dest.writeLong(getLastModified());
        dest.writeString(getRcgType());
        dest.writeString(getUserRcgType());
        dest.writeLong(getSize());

        dest.writeTypedArray(null, flags);
    }

    public static final Creator<MediaWrapper> CREATOR = new Creator<MediaWrapper>() {
        public MediaWrapper createFromParcel(Parcel in) {
            return new MediaWrapper(in);
        }

        public MediaWrapper[] newArray(int size) {
            return new MediaWrapper[size];
        }
    };

}
