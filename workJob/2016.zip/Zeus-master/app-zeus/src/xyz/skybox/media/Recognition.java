package xyz.skybox.media;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Environment;
import android.text.TextUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import wseemann.media.FFmpegMediaMetadataRetriever;
import xyz.skybox.SkyboxApplication;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.util.FileRcgHelper;
import xyz.skybox.util.FileUtils;

import static xyz.skybox.util.Util.printExceptionLog;

//import com.google.gson.Gson;

public class Recognition {

    public static native int nativeRecognition(String fileName, int width, int height, int type, byte[] byteArray);

    public static native void nativeStartupRecognition();

    public static native void nativeShutdownRecognition();

    public static native void nativeSaveTexture(String fileName, int oriWidth, int oriHeight,
                                                int fromX, int fromY, int CutWidth, int CutHeight, int outWidth, int outHeight,
                                                int format, int quality, byte[] byteArray);


    public enum Format {
        eRGB,
        eRGBA,
        eBGR,
        eBGRA,
        eRGB565,
        eA8
    }

    static final int e2D180D = 0;
    static final int e2D360D = 1;
    static final int e2DScreen = 2;
    static final int eLeftRight180D = 3;
    static final int eLeftRight360D = 4;
    static final int eLeftRightScreen = 5;
    static final int eTopBottom180D = 6;
    static final int eTopBottom360D = 7;
    static final int eTopBottomScreen = 8;

    static String TAG = "SKYBOX";

    static boolean sStart = false;

    static int sFormat = 4;

    public static void startupRecognition() {
        if (sStart)
            return;
        sStart = true;
        nativeStartupRecognition();
    }

    public static void shutdownRecognition() {
        nativeShutdownRecognition();
    }

    /**
     * Recognizes the type of local video file.
     *
     * @param uri file:///xxx.xxx
     * @return Bitmap
     *
     * e2D180D,           0
     * e2D360D,           1
     * e2DScreen,         2
     *
     * eLeftRight180D,    3
     * eLeftRight360D,    4
     * eLeftRightScreen,  5
     *
     * eTopBottom180D,    6
     * eTopBottom360D,    7
     * eTopBottomScreen   8
     *
     */
    public static Bitmap getRecognizeThumbnail(Uri uri, int width, int height, MediaWrapper wm) {

        String uriStr = uri.toString();

        if (!uriStr.contains("file://")) {
            return null;
        }

        // This uri string was encoded, need to decode.
        uriStr = Uri.decode(uriStr);

        File sourceFile = new File(uriStr.replace("file://", ""));
        if (!sourceFile.exists()) {
            return null;
        }

        String fileName = sourceFile.getName();
        String filePath = sourceFile.getPath();
        LogUtil.d("start recognize: " + filePath);

        // <--
        FileRcgHelper fileHelper = FileRcgHelper.getInstance();
        fileHelper.writeToLogFile(sourceFile.getAbsolutePath());

        Bitmap frame = getFrameAtTime(sourceFile, 0.6f);

        fileHelper.writeToLogFileByUri(sourceFile.getAbsolutePath());
        // -->

        if (frame == null) {
            MediaDatabase mediaDatabase = MediaDatabase.getInstance();
            mediaDatabase.setRecognizeType(uri, Integer.toString(2));
            wm.setRcgType(Integer.toString(2));
            return null;
        }

        int type = getRecognitionType(frame, fileName);
        LogUtil.d("getRecognizeThumbnail type: " + type+" "+filePath);

        MediaDatabase mediaDatabase = MediaDatabase.getInstance();
        mediaDatabase.setRecognizeType(uri, Integer.toString(type));
        wm.setRcgType(Integer.toString(type));

        byte[] byteArray = bitmapToByteArray(frame);
        return getCropBitmap(type, frame, byteArray, fileName, width, height);
    }

    public static Bitmap getHighRecognizeThumbnail(Uri uri, int width, int height, MediaWrapper wm) {

        String uriStr = uri.toString();

        if (!uriStr.contains("file://")) {
            return null;
        }

        // This uri string was encoded, need to decode.
        uriStr = Uri.decode(uriStr);

        File sourceFile = new File(uriStr.replace("file://", ""));
        if (!sourceFile.exists()) {
            return null;
        }

        String fileName = sourceFile.getName();
        String filePath = sourceFile.getPath();

        LogUtil.d("high recognize type before "+wm.getRcgType()+", path:"+filePath);

        int type = 2;
        int type1 = 2;
        int type2 = 2;
        int type3 = 2;

        // 1.0
        Bitmap frame1 = getFrameAtTime(sourceFile, 0.25f);
        type1 = getRecognitionType(frame1, fileName);
        LogUtil.d("recognition type 1: " + type1);

        // 2.0
        Bitmap frame2 = getFrameAtTime(sourceFile, 0.75f);
        type2 = getRecognitionType(frame2, fileName);
        LogUtil.d("recognition type 2: " + type2);

        Bitmap frame = null;
        if (frame1 != null) {
            type = type1;
            frame = frame1;

        } else if (frame2 != null) {
            type = type2;
            frame = frame2;
        }

        if (type1 != type2) {
            // 3.0
            Bitmap frame3 = getFrameAtTime(sourceFile, 0.55f);
            type3 = getRecognitionType(frame3, fileName);
            LogUtil.d("recognition type 3: " + type3);

            if (type1 == type3 || type2 == type3) {
                type = type3;
                frame = frame3;
            }
        }

        String typeStr = Integer.toString(type);
        if (typeStr.equals(wm.getRcgType())) {
            // No change between the last recognize result and this time.
            LogUtil.d("high recognize no change, type before "+wm.getRcgType()+", type after "+type+", file: "+filePath);
            return null;
        }

        if (frame == null) {
//            MediaDatabase mediaDatabase = MediaDatabase.getInstance();
//            mediaDatabase.setRecognizeType(uri, Integer.toString(2));
//            wm.setRcgType(Integer.toString(2));
            return null;
        }

        MediaDatabase mediaDatabase = MediaDatabase.getInstance();
        mediaDatabase.setRecognizeType(uri, Integer.toString(type));
        wm.setRcgType(Integer.toString(type));

        byte[] byteArray = bitmapToByteArray(frame);
        return getCropBitmap(type, frame, byteArray, fileName, width, height);
    }

    private static int getRecognitionType(Bitmap frame, String fileName) {
        int type = 2;
        if (frame == null) {
            return type;
        }

        byte[] byteArray = bitmapToByteArray(frame);

        if (frame != null && byteArray != null) {
            // Recognize the frame.
            long time5T = LogUtil.currentTimeMillis();
            type = nativeRecognition(fileName, frame.getWidth(), frame.getHeight(), sFormat, byteArray);
            long time6T = LogUtil.currentTimeMillis();
            LogUtil.duration("native recognition ", time5T, time6T);
        }
        if (frame != null) {
            LogUtil.d("frame w, h: " + frame.getWidth() + ", " + frame.getHeight());
        }
        return type;
    }

    private static Bitmap getFrameAtTime(File sourceFile, float percentTime) {
        String fileName = sourceFile.getName();
        String filePath = sourceFile.getPath();
        Bitmap frame = null;

        try {
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            try {
                mmr.setDataSource(sourceFile.getAbsolutePath());
                frame = getBitmapFromAndroidMedia(mmr, percentTime);
            } catch (Exception e) {

                LogUtil.w("AMMR exception path:"+filePath+"; "+e.getMessage());

                FFmpegMediaMetadataRetriever fmmr = new FFmpegMediaMetadataRetriever();
                try {
                    fmmr.setDataSource(sourceFile.getAbsolutePath());
                    frame = getBitmapFromFFmpegMedia(fmmr, fileName, percentTime);
                } catch (Exception ex) {
                    printExceptionLog("FMMR getBitmap Exception, path: "+sourceFile.getAbsolutePath(),
                            ex.getMessage(), LogUtil.getStackTrace());
                } finally {
                    fmmr.release();
                }
            } finally {
                mmr.release();
            }
            if (frame == null) {
                FFmpegMediaMetadataRetriever fmmr = new FFmpegMediaMetadataRetriever();
                try {
                    fmmr.setDataSource(sourceFile.getAbsolutePath());
                    frame = getBitmapFromFFmpegMedia(fmmr, fileName, percentTime);
                } catch (Exception e) {
                    printExceptionLog("FMMR getBitmap-2 Exception, path: "+sourceFile.getAbsolutePath(),
                            e.getMessage(), LogUtil.getStackTrace());
                } finally {
                    fmmr.release();
                }
            }
        } catch (Exception e) {
            printExceptionLog("Recognize getBitmap Exception, path: "+sourceFile.getAbsolutePath(),
                    e.getMessage(), LogUtil.getStackTrace());
        }

        return frame;
    }

    private static Bitmap getBitmapFromAndroidMedia(MediaMetadataRetriever mmr, float percentTime) {
        String timeStr = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        if (TextUtils.isEmpty(timeStr)) {
            // There is a problem with this media file.
            return null;
        }

        long time = Long.parseLong(timeStr);
        if (time <= 0) {
            // There is a problem with this media file.
            return null;
        }

        int p = Math.round(percentTime * 100);
        long time1 = time / 100 * p;

        // 1.1 Get the first frame.
        long time1T = LogUtil.currentTimeMillis();
        Bitmap frame = mmr.getFrameAtTime(time1 * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
        long time2T = LogUtil.currentTimeMillis();
        LogUtil.duration("AndroidMedia getFrameAtTime 1", time1T, time2T);

        if (frame == null) {
            long time3T = LogUtil.currentTimeMillis();
            frame = mmr.getFrameAtTime();
            long time4T = LogUtil.currentTimeMillis();
            LogUtil.duration("AndroidMedia getFrameAtTime 2", time3T, time4T);
        }

        return frame;
    }

    private static Bitmap getBitmapFromFFmpegMedia(FFmpegMediaMetadataRetriever mmr, String fileName, float percentTime) {
        String fileExt = FileUtils.getFileExt(fileName);
        if (TextUtils.isEmpty(fileExt)) {
            // There is a problem with this media file.
            return null;
        }

        if (".rmvb".equals(fileExt)) {
            long time1T = LogUtil.currentTimeMillis();
            Bitmap frame = mmr.getFrameAtTime();
            long time2T = LogUtil.currentTimeMillis();
            LogUtil.duration("FFmpegMedia rmvb getFrameAtTime 1", time1T, time2T);
            return frame;
        }

        String timeStr = mmr.extractMetadata(FFmpegMediaMetadataRetriever.METADATA_KEY_DURATION);
        if (TextUtils.isEmpty(timeStr)) {
            // There is a problem with this media file.
            return null;
        }

        int p = Math.round(percentTime * 100);
        long time = Long.parseLong(timeStr);
        long time1 = time / 100 * p;

        // 1.1 Get the first frame.
        long time1T = LogUtil.currentTimeMillis();
        Bitmap frame = mmr.getFrameAtTime(time1 * 1000, FFmpegMediaMetadataRetriever.OPTION_CLOSEST_SYNC);
        long time2T = LogUtil.currentTimeMillis();
        LogUtil.duration("FFmpegMedia getFrameAtTime 1", time1T, time2T);

        if (frame == null) {
            long time3T = LogUtil.currentTimeMillis();
            frame = mmr.getFrameAtTime();
            long time4T = LogUtil.currentTimeMillis();
            LogUtil.duration("FFmpegMedia getFrameAtTime 2", time3T, time4T);
        }

        return frame;
    }

    private static Bitmap getCropBitmap(int type, Bitmap bitmap, byte[] byteArray, String fileName, int opWidth, int opHeight) {

        if (bitmap == null || bitmap.getWidth() == 0 || bitmap.getHeight() == 0
                || opWidth <= 0 || opHeight <= 0
                || byteArray == null || byteArray.length == 0) {
            LogUtil.e("getCropBitmap failed from bitmap " + bitmap);
            return null;
        }

        // TODO
        int type1 = type;//getType(fileName);

        int oriWidth = bitmap.getWidth();
        int oriHeight = bitmap.getHeight();

        int cutWidth = oriWidth;
        int cutHeight = oriHeight;

        int quality = 1;

        File cache = SkyboxApplication.getAppContext().getExternalCacheDir();
        if (cache == null) {
            cache = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/SKYBOX/tmp");
        }
        String filePath = cache.getAbsolutePath();

        File f = new File(filePath);
        if (!f.exists()) {
            f.mkdir();
        }

        fileName = fileName.replace(".", "_");
        fileName = fileName + ".png";
        File imageFile = new File(filePath, fileName);

        if (imageFile.exists()) {
            imageFile.delete();
        }

        LogUtil.d("imagePath:" + imageFile.getPath());

        switch (type1) {
            case e2D180D:
            case e2D360D:
            case e2DScreen:
                break;//return bitmap;
            case eLeftRight180D:
            case eLeftRight360D:
            case eLeftRightScreen:
                cutWidth = oriWidth / 2;
                break;
            case eTopBottom180D:
            case eTopBottom360D:
            case eTopBottomScreen:
                cutHeight = oriHeight / 2;
                break;
        }

        // set output size
        int outputWidth = opWidth;//400;
        int outputHeight = opHeight;//400;

        float scaleFctor = 1.0f;
        switch (type1) {
            case e2D180D:
            case eLeftRight180D:
            case eTopBottom180D: {
                // 1 : 1
                scaleFctor = 1.0f;
            }
            break;
            case e2D360D:
            case eLeftRight360D:
            case eTopBottom360D: {
                // 2 : 1
                scaleFctor = 0.5f;
            }
            break;
            case e2DScreen: {
                // origin
                scaleFctor = ((float) cutHeight / cutWidth);
            }
            break;
            case eLeftRightScreen:
            case eTopBottomScreen: {
                // 16 : 9
                scaleFctor = 9.0f / 16;
            }
            break;
            default:
                break;
        }

        float revScaleFactor = (float) cutWidth / cutHeight * scaleFctor * opWidth / opHeight;
        int fromX = 0;
        int fromY = 0;
        int cutRegionW = cutWidth;
        int cutRegionH = cutHeight;

        cutRegionW = (int) (cutRegionH * revScaleFactor);
        if (cutRegionW > cutWidth) {
            cutRegionW = cutWidth;
            cutRegionH = (int) (cutRegionW / revScaleFactor);
            fromY = (cutHeight - cutRegionH) / 2;
        } else {
            fromX = (cutWidth - cutRegionW) / 2;
        }

//        cutRegionW = (int)(cutRegionH * revScaleFactor);
//        fromX = (cutWidth - cutRegionW) / 2;
//
//        cutRegionH  = (int)(cutRegionW / revScaleFactor);
//        fromY = (cutHeight - cutRegionH) / 2;

        LogUtil.d("    getType: " + type1);
        LogUtil.d("      oriWH: " + oriWidth + ", " + oriHeight);
        LogUtil.d("     fromXY: " + fromX + ", " + fromY + ", revScaleFactor: " + revScaleFactor);
        LogUtil.d("      cutWH: " + cutWidth + ", " + cutHeight);
        LogUtil.d("cutRegionWH: " + cutRegionW + ", " + cutRegionH);

        nativeSaveTexture(imageFile.getPath(), oriWidth, oriHeight,
                fromX, fromY, cutRegionW, cutRegionH, opWidth, opHeight, sFormat, quality, byteArray);

        File imageFile2 = new File(filePath, fileName);
        if (imageFile2.exists()) {

            LogUtil.d("image2Path:" + imageFile2.getPath());
            Bitmap bitmap1 = BitmapFactory.decodeFile(imageFile2.getPath());
            if (bitmap1 != null) {
                LogUtil.d("image2 bitmap w, h: " + bitmap1.getWidth() + ", " + bitmap1.getHeight());
            }
            return bitmap1;
        } else {
            return null;
        }
    }

    private static Bitmap convert(Bitmap bitmap, Bitmap.Config config) {
        Bitmap convertedBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), config);
        Canvas canvas = new Canvas(convertedBitmap);
        Paint paint = new Paint();
        paint.setColor(Color.BLACK);
        canvas.drawBitmap(bitmap, 0, 0, paint);
        return convertedBitmap;
    }

    private static byte[] bitmapToByteArray(Bitmap bitmap) {
        if (bitmap == null) {
            return null;
        }
        LogUtil.d("1 getByteCount " + bitmap.getByteCount() + " getRowBytes " + bitmap.getRowBytes()
                + " getConfig " + bitmap.getConfig());
        Bitmap convertedBitmap = convert(bitmap, Bitmap.Config.RGB_565);
        LogUtil.d("2 getByteCount " + bitmap.getByteCount() + " getRowBytes " + bitmap.getRowBytes()
                + " getConfig " + bitmap.getConfig());

        int bytes = convertedBitmap.getByteCount();
        ByteBuffer buf = ByteBuffer.allocate(bytes);
        convertedBitmap.copyPixelsToBuffer(buf);
        return buf.array();
    }

    public static void saveBitmapToSdCard(Bitmap bitmap, String fileName) {
        String filePath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/TestImage";
        File f = new File(filePath);
        if (!f.exists()) {
            f.mkdir();
        }

        File imageFile = new File(filePath, fileName + ".png");
        if (imageFile.exists()) {
            fileName += "+";
            imageFile = new File(filePath, fileName + ".png");
        }

        try {
            FileOutputStream fos = new FileOutputStream(imageFile);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static int getTypeByConfig(String filePath) {

        if (filePath.isEmpty()) {
            return -1;
        }

        File videoFile = new File(filePath);
        if (!videoFile.exists()) {
            return -1;
        }

        String json = getFileString();
        if (json == null || json.isEmpty()) {
            return -1;
        }

//        if (sConfigList.isEmpty()) {
//            Gson gson = new Gson();
//            ConfigList configList = gson.fromJson(json, ConfigList.class);
//            sConfigList = configList.list;
//        }

        for (Config config : sConfigList) {
//            LogUtil.d(" ------------------- ");
//            LogUtil.d("                 size: "+config.size);
//            LogUtil.d("   videoFile.length(): "+videoFile.length());
//            LogUtil.d("             lastModified: "+config.lastModified);
//            LogUtil.d(" videoFile.lastModified(): "+videoFile.lastModified());
            if (videoFile.length() == config.size) {
//                LogUtil.d("!! set setting: "+config.setting);
                return config.setting;
            }
        }
        return -1;
    }

    static List<Config> sConfigList = new ArrayList<Config>();

    private static String getFileString() {
        String configPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/test_config.json";
        File configFile = new File(configPath);
        if (!configFile.exists()) {
            // No config file.
            return null;
        }

        String result = "";

        try {
            FileInputStream fis = new FileInputStream(configPath);
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));
            String line = "";
            while ((line = br.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public class Config {
        String name;
        long size;
        long lastModified;
        int setting;
        int snapshotTime;

        public Config(String name, long size, long lastModified, int setting, int snapshotTime) {
            this.name = name;
            this.size = size;
            this.lastModified = lastModified;
            this.setting = setting;
            this.snapshotTime = snapshotTime;
        }
    }

    public class ConfigList {

        public List<Config> list;

        public ConfigList(List<Config> list) {
            this.list = list;
        }
    }

}
