package xyz.skybox.media;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;

import xyz.skybox.common.util.LogUtil;

public class MediaContentProvider extends ContentProvider {

    private static UriMatcher sUriMatcher;

    public static final String AUTHORITY_APP = "xyz.skybox.media.provider.gvr";
    public static final String AUTHORITY = "xyz.skybox.media.provider";

    private static final String PATH_VIDEOS = "videos";
    private static final String PATH_PLAY = "play";
    private static final String PATH_SERVER = "server";
    private static final String PATH_HISTORY = "history";
    private static final String PATH_FAVOURITE = "favourite";

    private static final String CLEAR_ALL = "all";

    private static final int TYPE_VIDEOS = 1;
    private static final int TYPE_PLAY = 2;
    private static final int TYPE_SERVER = 3;
    private static final int TYPE_HISTORY = 4;
    private static final int TYPE_FAVOURITE = 5;

    private MediaDatabase mMediaDatabase;

    static {
        sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        sUriMatcher.addURI(AUTHORITY, PATH_VIDEOS, TYPE_VIDEOS);
        sUriMatcher.addURI(AUTHORITY, PATH_PLAY, TYPE_PLAY);
        sUriMatcher.addURI(AUTHORITY, PATH_SERVER, TYPE_SERVER);
        sUriMatcher.addURI(AUTHORITY, PATH_HISTORY, TYPE_HISTORY);
        sUriMatcher.addURI(AUTHORITY, PATH_FAVOURITE, TYPE_FAVOURITE);
    }

    public MediaContentProvider() {
    }

    @Override
    public boolean onCreate() {
        LogUtil.d(" MediaContentProvider onCreate");
        LogUtil.logStackTrace();
        mMediaDatabase = MediaDatabase.getInstance(getContext());
        return true;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        LogUtil.d(" MediaContentProvider uri " + uri);
        Cursor cursor = null;
        switch (sUriMatcher.match(uri)) {
            case TYPE_VIDEOS:
                cursor = mMediaDatabase.getVideos();
                break;
            case TYPE_PLAY:
                cursor = mMediaDatabase.getExternalPlayMedia();
                break;
            case TYPE_SERVER:
                cursor = mMediaDatabase.getConnectedServer();
                break;
            case TYPE_HISTORY:
                cursor = mMediaDatabase.getHistoryData();
                break;
            case TYPE_FAVOURITE:
                cursor = mMediaDatabase.getAllFavourData();
                break;
        }

        return cursor;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {

        long rowID = 0;
        switch (sUriMatcher.match(uri)) {
            case TYPE_HISTORY:
                rowID = mMediaDatabase.addHistoryItem(values);
                break;
            case TYPE_FAVOURITE:
                rowID = mMediaDatabase.addFavourItem(values);
                break;
        }

        if (rowID > 0) {
            Uri aUri = ContentUris.withAppendedId(Uri.parse(AUTHORITY), rowID);
            return aUri;
        }

        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        int num = 0;
        switch (sUriMatcher.match(uri)) {
            case TYPE_VIDEOS:
                if (CLEAR_ALL.equals(selection)) {
                    num = mMediaDatabase.clearMediaTable();
                } else {
//                    num = mMediaDatabase.deleteHistoryUri(Uri.parse(selection));
                }
                break;
            case TYPE_HISTORY:
                if (CLEAR_ALL.equals(selection)) {
                    num = mMediaDatabase.clearHistory();
                } else {
                    num = mMediaDatabase.deleteHistoryUri(Uri.parse(selection));
                }
                break;
            case TYPE_FAVOURITE:
                if (CLEAR_ALL.equals(selection)) {
                    num = mMediaDatabase.clearFavourTable();
                } else {
                    num = mMediaDatabase.deleteFavour(Uri.parse(selection));
                }
                break;
        }
        return num;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        return -1;
    }
}
