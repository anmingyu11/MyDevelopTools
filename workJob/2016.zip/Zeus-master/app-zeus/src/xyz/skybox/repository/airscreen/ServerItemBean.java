//Todo CopyRight
package xyz.skybox.repository.airscreen;

import android.content.Context;
import android.view.View;

import xyz.skybox.R;
import xyz.skybox.gui.airscreen.AirScreenNetwork;

/**
 * Item for server found result.
 */
public class ServerItemBean {

    private String mServerName;
    private String mDeviceId;
    private String mIp;
    private String mPort;

    private int mDeviceFounded;
    private int mMarginDelta;

    private int mCode;
    private View.OnClickListener mOnClickListener;

    public ServerItemBean(String serverName, String deviceId, final String ip, String port) {
        mServerName = serverName;
        mDeviceId = deviceId;
        mIp = ip;
        this.mPort = port;
        mOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mDeviceFounded == 1) {
                    AirScreenNetwork.getInstance().showLoadingDialog();
                } else if (mDeviceFounded > 3) {
                    int y = (int) (mMarginDelta * 2.5f);
                    AirScreenNetwork.getInstance().showLoadingDialog(y);
                } else {
                    AirScreenNetwork.getInstance().showLoadingDialog(mMarginDelta * (mDeviceFounded - 1));
                }
                AirScreenNetwork.getInstance().connectServerByIpSync(ip);
            }
        };
    }

    public ServerItemBean(String serverName, int code, View.OnClickListener onClickListener) {

        mServerName = serverName;
        this.mCode = code;
        mOnClickListener = onClickListener;
    }

    public String getServerName() {
        return mServerName;
    }

    public void setServerName(String serverName) {
        mServerName = serverName;
    }

    public int getCode() {
        return mCode;
    }

    public void setCode(int code) {
        this.mCode = code;
    }

    public View.OnClickListener getOnClickListener() {
        return mOnClickListener;
    }

    public void setDeviceFounded(int deviceFounded, Context context) {
        mDeviceFounded = deviceFounded;
        mMarginDelta = context.getResources().getDimensionPixelSize(R.dimen.loading_dialog_margin_delta);
    }

    public void setOnClickListener(View.OnClickListener onClickListener) {
        mOnClickListener = onClickListener;
    }
}
