// TODO copyright
package xyz.skybox.repository.airscreen;

import java.util.ArrayList;
import java.util.List;

import xyz.skybox.SkyboxApplication;

public class ServerInfoManager {

    private List<ServerInfo> mServerInfoList = new ArrayList<ServerInfo>();
    private int mCurrentServerInfoIndex = -1;
    private static ServerInfoManager sServerInfoManager;

    private ServerInfoManager() {

    }

    public static ServerInfoManager getInstance() {
        if (sServerInfoManager == null) {
            sServerInfoManager = new ServerInfoManager();
        }
        return sServerInfoManager;
    }

    public boolean addServerInfo(ServerInfo serverInfo) {
        if (!mServerInfoList.contains(serverInfo)) {
            mServerInfoList.add(serverInfo);
            onServerNumChanged();
            return true;
        }
        return false;
    }

    public void clearList() {
        mServerInfoList.clear();
        onServerNumChanged();
    }

    public int getServerNum() {
        return mServerInfoList.size();
    }

    public List<ServerInfo> getServerInfoList() {
        return mServerInfoList;
    }

    public int getIndexOfServerInfo(ServerInfo serverInfo) {
        return mServerInfoList.indexOf(serverInfo);
    }

    public ServerInfo getServerInfoByIndex(int index) {
        return mServerInfoList.get(index);
    }

    public ServerInfo getServerInfoByComputerName(String computerName) {
        for (ServerInfo serverInfo : mServerInfoList) {
            if (serverInfo.computerName.equals(computerName)) {
                return serverInfo;
            }
        }
        return null;
    }

    public ServerInfo getServerInfoByIp(String ip) {
        for (ServerInfo serverInfo : mServerInfoList) {
            if (serverInfo.ip.equals(ip)) {
                return serverInfo;
            }
        }
        return null;
    }

    // TODO: it quit the air screen video page, get current server should be bull.
    public ServerInfo getCurrentServerInfo() {
        if (mCurrentServerInfoIndex >= 0 && mCurrentServerInfoIndex < mServerInfoList.size()) {
            return mServerInfoList.get(mCurrentServerInfoIndex);
        }
        return null;
    }

    public boolean setCurrentServerInfo(ServerInfo serverInfo) {
        if (mServerInfoList.indexOf(serverInfo) != -1) {
            mCurrentServerInfoIndex = mServerInfoList.indexOf(serverInfo);
            return true;
        }
        return false;
    }

    public boolean setCurrentServerInfoIndex(int index) {
        if (index >= 0 && index < mServerInfoList.size()) {
            mCurrentServerInfoIndex = index;
            return true;
        }
        return false;
    }

    public void onServerNumChanged() {
        // TODO server num changed, update UI
    }

    public List<ServerItemBean> parseServerInfoToDeviceItemBean() {
        int serverInfoListSize = mServerInfoList.size();
        List<ServerItemBean> deviceItemBeen = new ArrayList<ServerItemBean>(serverInfoListSize);
        for (ServerInfo serverInfo : mServerInfoList) {
            ServerItemBean serverItemBean = new ServerItemBean(
                    serverInfo.computerName,
                    serverInfo.deviceId,
                    serverInfo.ip,
                    serverInfo.port
            );
            serverItemBean.setDeviceFounded(serverInfoListSize, SkyboxApplication.getAppContext());
            deviceItemBeen.add(serverItemBean);
        }
        return deviceItemBeen;
    }

}
