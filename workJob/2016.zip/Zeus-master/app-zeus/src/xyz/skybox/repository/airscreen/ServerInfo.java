// TODO copyright
package xyz.skybox.repository.airscreen;

import android.os.Parcel;
import android.os.Parcelable;

public class ServerInfo implements Parcelable {

    public String deviceId; // Phone id
    public String computerId; // PC id
    public String computerName;
    public String ip;
    public String port;

    public ServerInfo(String deviceId, String computerId, String computerName, String ip, String port) {
        this.deviceId = deviceId;
        this.computerId = computerId;
        this.computerName = computerName;
        this.ip = ip;
        this.port = port;
    }

    protected ServerInfo(Parcel in) {
        this.deviceId = in.readString();
        this.computerId = in.readString();
        this.computerName = in.readString();
        this.ip = in.readString();
        this.port = in.readString();
    }

    public static final Creator<ServerInfo> CREATOR = new Creator<ServerInfo>() {
        @Override
        public ServerInfo createFromParcel(Parcel in) {
            return new ServerInfo(in);
        }

        @Override
        public ServerInfo[] newArray(int size) {
            return new ServerInfo[size];
        }
    };

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof ServerInfo))
            return false;
        if (obj == this)
            return true;
        //Todo: For now this is the only identifer of pc client
        return this.ip.equals(((ServerInfo) obj).ip);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(deviceId);
        dest.writeString(computerId);
        dest.writeString(computerName);
        dest.writeString(ip);
        dest.writeString(port);
    }

    @Override
    public String toString() {
        return "ServerInfo{" +
                "deviceId='" + deviceId + '\'' +
                ", computerName='" + computerName + '\'' +
                ", ip='" + ip + '\'' +
                ", port='" + port + '\'' +
                '}';
    }
}
