package xyz.skybox.repository.setting;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.database.Cursor;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.statistic.helper.FabricHelper;
import xyz.skybox.repository.SharedPreferencesManager;
import xyz.skybox.util.AndroidDevices;
import xyz.skybox.util.DownloadManagerPro;
import xyz.skybox.util.FileUtils;
import xyz.skybox.util.UpdateUtil;

import static android.app.DownloadManager.STATUS_RUNNING;
import static android.app.DownloadManager.STATUS_SUCCESSFUL;
import static xyz.skybox.repository.SharedPreferencesManager.DEFAULT_REQUEST_ID;
import static xyz.skybox.repository.SharedPreferencesManager.DOWNLOAD_SEPARATOR;

public class ZeusSettings {
    private final Handler mNewApkHandler = new NewApkHandler();
    private final DownloadChangeObserver mDownloadChangeObserver = new DownloadChangeObserver(mNewApkHandler);

    public final static String UPDATE_URL = "http://123.56.203.91:8699/skybox/android/";
    private String mNewApkName = "";
    private String mDownloadApkUri = null;
    private DownloadManagerPro mDownloadManagerPro;
    private DownloadManager mDownloadManager;
    private long mRequestId = DEFAULT_REQUEST_ID;
    private boolean isDownloaded = false;

    final private int MB_SIZE = 1024 * 1024;

    private int mCacheSize = 0;

    private Context mContext;
    private final File mCacheFile = new File(AndroidDevices.MY_VIDEO_DIRECTORY);

    final public ObservableField<String> Cache = new ObservableField<String>(mCacheSize + " MB");
    final public ObservableField<String> Version = new ObservableField<String>("v1.0");
    final public ObservableBoolean CanClear = new ObservableBoolean(false);
    final public ObservableBoolean HasNew = new ObservableBoolean(false);

    private static ZeusSettings sZeusSettings;

    private ZeusSettings(Context context) {
        mContext = context;
        setVersion(UpdateUtil.versionName(context));
        setHasNew(false);
        isDownloaded = false;
        invalidateCacheSize();
        mDownloadManager = (DownloadManager) mContext.getSystemService(Context.DOWNLOAD_SERVICE);
        mDownloadManagerPro = new DownloadManagerPro(mDownloadManager);
    }

    public static ZeusSettings getInstance(Context context) {
        if (sZeusSettings == null) {
            sZeusSettings = new ZeusSettings(context);
        }
        return sZeusSettings;
    }

    public void invalidateCacheSize() {
        setCacheSize(0);
        invalidateCacheSize(mCacheFile);
    }

    public void checkIfNewEditionAvailable() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(UPDATE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        UpdateService service = retrofit.create(UpdateService.class);

        Call<UpdateMessage> call = service.getUpdateMessage();
        call.enqueue(new Callback<UpdateMessage>() {
            @Override
            public void onResponse(Call<UpdateMessage> call, Response<UpdateMessage> response) {
                UpdateMessage updateMessage = response.body();
                LogUtil.d(updateMessage.toString());
                if (isNewApkAvailable(Integer.valueOf(updateMessage.version))) {
                    //Not Newest version.
                    mNewApkName = updateMessage.filename;

                    //get from SharePreferencesManager for record.
                    String downloadedApkName = null;
                    int status = -100;
                    long requestId = -100;
                    String download = SharedPreferencesManager.getInstance(mContext).getDownload();
                    LogUtil.d("download : " + download);
                    if (!download.equals("")) {
                        String[] args = download.split(DOWNLOAD_SEPARATOR);
                        requestId = Long.valueOf(args[0]);
                        status = Integer.valueOf(args[1]);
                        downloadedApkName = args[2];

                        if (mNewApkName.equals(downloadedApkName)
                                && status == STATUS_SUCCESSFUL) {
                            //if has downloaded this.
                            File file = new File(
                                    mContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                                            + AndroidDevices.FILE_SEPARATOR
                                            + mNewApkName);
                            if (file.exists()) {
                                isDownloaded = true;
                            } else {
                                isDownloaded = false;
                            }
                            setHasNew(true);
                        } else if (status == STATUS_RUNNING) {
                            //if this is downloading
                            mRequestId = requestId;
                            setHasNew(false);
                            return;
                        } else {
                            //if not downloading
                            isDownloaded = false;
                            setHasNew(true);
                        }
                    } else {
                        isDownloaded = false;
                        setHasNew(true);
                    }
                } else {
                    setHasNew(false);
                    mNewApkName = null;
                }
            }

            @Override
            public void onFailure(Call<UpdateMessage> call, Throwable t) {
                setHasNew(false);
                mNewApkName = null;
            }
        });
    }


    private boolean isNewApkAvailable(int versionFromServer) {
        int versionCode = UpdateUtil.versionCode(mContext);
        LogUtil.d("version from app : " + versionCode + " version from server : " + versionFromServer);
        if (versionFromServer > versionCode) {
            return true;
        } else if (versionFromServer < versionCode) {
            FabricHelper.logException(new RuntimeException("The version name from server is : "
                    + versionFromServer + " current is  : " + versionCode));
            return false;
        } else {
            return false;
        }
    }

    private final BroadcastReceiver mDownloadReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            long downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);

            if (downloadId != mRequestId) {
                return;
            } else {
                //Reset this
                installDownloadedApk();
                resetDownloadToSharedPreference();//Successed
            }
        }
    };

    public void register() {
        registerDownloadReceiver();
        registerDownloadObserver();
    }

    public void registerDownloadReceiver() {
        if (mDownloadReceiver != null) {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
            mContext.registerReceiver(mDownloadReceiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
        } else {
            String err = "Register download receiver is null";
            LogUtil.e(err);
            FabricHelper.logException(new NullPointerException(err));
        }
    }

    public void registerDownloadObserver() {
        mContext.getContentResolver().registerContentObserver(DownloadManagerPro.CONTENT_URI, true, mDownloadChangeObserver);
    }

    public void unRegister() {
        unRegisterDownloadReceiver();
        unregisterDownloadObserver();
    }

    public void unregisterDownloadObserver() {
        mContext.getContentResolver().unregisterContentObserver(mDownloadChangeObserver);
    }

    public void unRegisterDownloadReceiver() {
        if (mDownloadReceiver != null) {
            mContext.unregisterReceiver(mDownloadReceiver);
        } else {
            String err = "Unregister download receiver is null";
            LogUtil.e(err);
            FabricHelper.logException(new NullPointerException(err));
        }
    }

    private void downloadApk() {
        if (mNewApkName == null || !HasNew.get()) {
            return;
        }

        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(UPDATE_URL + mNewApkName));
        request.setDestinationInExternalFilesDir(mContext, Environment.DIRECTORY_DOWNLOADS, mNewApkName);
        request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE);
        request.setTitle("Download " + mNewApkName);
        request.setDescription("Application is downloading.");
        request.setAllowedOverRoaming(false);

        Toast.makeText(mContext, "Downloading", Toast.LENGTH_SHORT).show();

        mRequestId = mDownloadManager.enqueue(request);

        setDownloadToSharedPreference();

    }

    private void setDownloadToSharedPreference() {
        SharedPreferencesManager.getInstance(mContext)
                .setDownload(mRequestId + DOWNLOAD_SEPARATOR
                        + mDownloadManagerPro.getStatusById(mRequestId) + DOWNLOAD_SEPARATOR
                        + mNewApkName);
    }

    private void setDownloadToSharedPreference(int status) {
        SharedPreferencesManager.getInstance(mContext)
                .setDownload(mRequestId + DOWNLOAD_SEPARATOR
                        + status + DOWNLOAD_SEPARATOR
                        + mNewApkName);
    }

    private void resetDownloadToSharedPreference() {
        SharedPreferencesManager.getInstance(mContext).setDownload("");
    }

    private void invalidateCacheSize(File file) {
        if (file.isFile()) {
            int dotIndex = file.getName().lastIndexOf(".");
            boolean isCache = (dotIndex == -1);
            //Todo avoid downloading tasks
            //||(DLManager.getInstance(mContext).getDownloadingTasks());
            if (isCache) {
                LogUtil.v("Dumpfile length : " + file.length() / MB_SIZE + " MB");
                setCacheSize(mCacheSize + (int) file.length() / MB_SIZE);
            } else {
                String fileExt = file.getName().substring(dotIndex);
            }
            return;
        }

        if (file.isDirectory()) {
            File[] childFiles = file.listFiles();
            if (childFiles == null || childFiles.length == 0) {
                return;
            }

            for (int i = 0; i < childFiles.length; i++) {
                invalidateCacheSize(childFiles[i]);
            }
        }
    }

    public void setCacheSize(int size) {
        if (size == 0) {
            setCanClear(false);
        } else {
            setCanClear(true);
        }
        mCacheSize = size;
        Cache.set(mCacheSize + " MB");
    }

    public void onClearClick(View view) {
        FileUtils.clearCache(mCacheFile);
        invalidateCacheSize();
    }

    private void installDownloadedApk() {
        mDownloadApkUri =
                mContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                        + AndroidDevices.FILE_SEPARATOR
                        + mNewApkName;

        File file = new File(mDownloadApkUri);
        if (file.exists()) {
            UpdateUtil.installApk(mContext, file);
        } else {
            String err = "file : " + file.getAbsolutePath() + " not exists";
            LogUtil.d(err);
            FabricHelper.logException(new FileNotFoundException(err));
        }
    }

    public void onNewClick(View view) {
        //Todo check if file exists.
        if (isDownloaded) {
            installDownloadedApk();
        } else {
            downloadApk();
        }
    }

    public void onFeedBackClick(View view) {
        String[] feedBackEmailAddress = {"Hello@Skybox.xyz"};
        String feedBackTitle = "Feedback email to SourceTechnology";
        String feedBackContent = "Feedback content";
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("plain/text");
        intent.putExtra(Intent.EXTRA_EMAIL, feedBackEmailAddress);
        intent.putExtra(Intent.EXTRA_SUBJECT, feedBackTitle);
        intent.putExtra(Intent.EXTRA_TEXT, feedBackContent);

        mContext.startActivity(Intent.createChooser(intent, "Send Email"));
    }

    public void onAboutUsClick(View view) {
        String url = "https://skybox.xyz";

        Uri uri = Uri.parse(url);

        Intent intent = new Intent(Intent.ACTION_VIEW, uri);

        mContext.startActivity(intent);
    }

    public void setVersion(String version) {
        Version.set(version);
    }

    public void setCanClear(boolean can) {
        CanClear.set(can);
    }

    public void setHasNew(boolean has) {
        //LogUtil.printTraceStack("hasNew : " + has);
        HasNew.set(has);
    }

    private class DownloadChangeObserver extends ContentObserver {

        /**
         * Creates a content observer.
         *
         * @param handler The handler to run {@link #onChange} on, or null if none.
         */
        public DownloadChangeObserver(Handler handler) {
            super(handler);
        }

        @Override
        public void onChange(boolean selfChange) {
            super.onChange(selfChange);
            updateNew();
        }

        public void updateNew() {
            mNewApkHandler.sendEmptyMessage(mDownloadManagerPro.getStatusById(mRequestId));
        }

    }

    private class NewApkHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            DownloadManager.Query query = new DownloadManager.Query().setFilterById(mRequestId);
            Cursor c = mDownloadManager.query(query);
            if (c != null && c.moveToFirst()) {
                int status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                switch (status) {
                    case DownloadManager.STATUS_PENDING:
                    case STATUS_RUNNING: {
                        setHasNew(false);
                        setDownloadToSharedPreference(STATUS_RUNNING);
                        break;
                    }
                    case STATUS_SUCCESSFUL: {
                        setHasNew(true);
                        isDownloaded = true;
                        setDownloadToSharedPreference(STATUS_SUCCESSFUL);
                        break;
                    }
                    case DownloadManager.STATUS_PAUSED:
                    case DownloadManager.STATUS_FAILED: {
                        setHasNew(true);
                        isDownloaded = false;
                        resetDownloadToSharedPreference();//failed reset
                        break;
                    }
                }
                if (c != null) {
                    c.close();
                }
            }
        }
    }
}
