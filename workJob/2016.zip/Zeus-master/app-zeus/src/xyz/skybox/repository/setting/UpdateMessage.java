package xyz.skybox.repository.setting;

public class UpdateMessage {

    String code;
    String version;
    String filename;

    public UpdateMessage(String code,
                         String version,
                         String filename) {
        this.code = code;
        this.version = version;
        this.filename = filename;
    }

    @Override
    public String toString() {
        return "UpdateMessage{" +
                "code=" + code +
                ", version=" + version +
                ", fileName=" + filename +
                '}';
    }

}
