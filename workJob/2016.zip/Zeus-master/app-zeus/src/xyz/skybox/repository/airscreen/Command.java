// TODO copyright
package xyz.skybox.repository.airscreen;

import java.util.List;

public class Command {

    public static class CmdBase {

        public String command;

        public CmdBase(String command) {
            this.command = command;
        }
    }

    public static class CmdSearch extends CmdBase {

        public String project;
        public String deviceId;
        public String deviceType;
        public String udpPort;

        public CmdSearch(String project, String deviceId, String deviceType, String udpPort) {
            super("search");
            this.project = project;
            this.deviceId = deviceId;
            this.deviceType = deviceType;
            this.udpPort = udpPort;
        }
    }

    public static class CmdAddDevice extends CmdBase {

        public String deviceId;
        public String deviceName;
        public String deviceType;

        public CmdAddDevice(String deviceId, String deviceName, String deviceType) {
            super("addDevice");
            this.deviceId = deviceId;
            this.deviceName = deviceName;
            this.deviceType = deviceType;
        }
    }

    public static class CmdLogin extends CmdBase {

        public String loginCode;

        public CmdLogin(String loginCode) {
            super("login");
            this.loginCode = loginCode;
        }
    }

    /**
     * 12. Notify server has started downloading a video.
     * event: "clientMessage",
     * data: {
     * command: "downloadMediaStarted",
     * id: (string) // Media ID
     * }
     */
    public static class CmdDownloadMediaStarted extends CmdBase {

        public String id;

        public CmdDownloadMediaStarted(String id) {
            super("downloadMediaStarted");
            this.id = id;
        }
    }

    /**
     * 13. Notify server a video has been downloaded completed.
     * event: "clientMessage",
     * data: {
     * command: "downloadMediaFinished",
     * id: (string) // Media ID
     * }
     */
    public static class CmdDownloadMediaFinished extends CmdBase {

        public String id;

        public CmdDownloadMediaFinished(String id) {
            super("downloadMediaFinished");
            this.id = id;
        }
    }

    /**
     * 14. Notify server to cancel a video download.
     * event: "clientMessage",
     * data: {
     * command: "downloadMediaCancelled",
     * id: (string) // Media ID
     * }
     */
    public static class CmdDownloadMediaCancelled extends CmdBase {

        public String id;

        public CmdDownloadMediaCancelled(String id) {
            super("downloadMediaCancelled");
            this.id = id;
        }
    }

    /**
     * 16.
     * event: "clientMessage",
     * data: {
     * command: "disconnect"
     * }
     */
    public static class CmdDisconnect extends CmdBase {
        public CmdDisconnect() {
            super("disconnect");
        }
    }

    /**
     * command: "setChannelPlayList"
     */
    public static class CmdSetChannelPlayList extends CmdBase {

        public List<ChannelInfo> list;

        public CmdSetChannelPlayList(List<ChannelInfo> list) {
            super("setChannelPlayList");
            this.list = list;
        }
    }

    /**
     *
     id: (int),
     mediaPath: (string), // begin with '/storage/'
     time: (int), // 单位为毫秒
     playingState: (string), // 现有状态'stopped','playing','paused'
     meidaPathList: [
     {
     mediaPath: (string), // begin with '/storage/'
     },
     ...
     ]
     */
    public static class ChannelInfo {

        public int id;
        public String mediaPath;
        public int time;
        public String playingState;
        public List<MediaPath> list;

        public ChannelInfo(int id, String mediaPath, int time, String playingState, List<MediaPath> list) {
            this.id = id;
            this.mediaPath = mediaPath;
            this.time = time;
            this.playingState = playingState;
            this.list = list;
        }
    }

    public static class MediaPath {

        public String mediaPath;

        public MediaPath(String mediaPath) {
            this.mediaPath = mediaPath;
        }
    }


    /**
     * -------------------------------------------------------------------------------------------
     * Server return to Client -------------------------------------------------------------------
     * -------------------------------------------------------------------------------------------
     */
    /**
     * data: {
     * udp: true,
     * project: "direwolf server",
     * command: "searchResult",
     * deviceId: (string), // Phone id
     * computerId: (string), // PC id
     * computerName: (string),
     * ip: (string),
     * port: (string)
     * }
     */
    public static class CmdSearchResult extends CmdBase {

        public String deviceId; // Phone id
        public String computerId; // PC id
        public String computerName; // PC name
        public String ip; // PC ip
        public String port; // PC port

        public CmdSearchResult(String command, String deviceId, String computerId, String computerName, String ip, String port) {
            super(command);

            this.deviceId = deviceId;
            this.computerId = computerId;
            this.computerName = computerName;
            this.ip = ip;
            this.port = port;
        }
    }

    /**
     * event: "serverMessage",
     * data: {
     * command: "addDeviceResult",
     * success: (bool),
     * isLoggedIn: (bool)
     * }
     */
    public static class CmdAddDeviceResult extends CmdBase {
        public int success;
        public int isLoggedIn;

        public CmdAddDeviceResult(String command, int success, int isLoggedIn) {
            super(command);
            this.success = success;
            this.isLoggedIn = isLoggedIn;
        }
    }

    /**
     * event: "serverMessage",
     * data: {
     * command: "loginResult",
     * success: (bool)
     * }
     */
    public static class CmdLoginResult extends CmdBase {
        public int success;

        public CmdLoginResult(String command, int success) {
            super(command);
            this.success = success;
        }
    }

    /**
     * event: "serverMessage",
     * data: {
     * command: "getMediaListResult",
     * list: [
     * {
     * id: (string),
     * name: (string),
     * duration: (int), // ms
     * size: (int),
     * url: (string),
     * thumbnail: (string), // url on server
     * thumbnailWidth: (int),
     * thumbnailHeight: (int),
     * lastModified: (int),
     * defaultVRSetting: (int),
     * userVRSetting: (int)
     * },
     * ...
     * ]
     * }
     */
    public static class CmdMediaInfo extends CmdBase {
        public String id;
        public String name;
        public int duration;
        public long size;
        public String url;
        public String thumbnail;
        public int thumbnailWidth;
        public int thumbnailHeight;
        public long lastModified;
        public int defaultVRSetting;
        public int userVRSetting;

        public CmdMediaInfo(String command, String id, String name, int duration, long size,
                            String url, String thumbnail, int thumbnailWidth, int thumbnailHeight,
                            long lastModified, int defaultVRSetting, int userVRSetting) {
            super(command);
            this.id = id;
            this.name = name;
            this.duration = duration;
            this.size = size;
            this.url = url;
            this.thumbnail = thumbnail;
            this.thumbnailWidth = thumbnailWidth;
            this.thumbnailHeight = thumbnailHeight;
            this.lastModified = lastModified;
            this.defaultVRSetting = defaultVRSetting;
            this.userVRSetting = userVRSetting;
        }
    }

    public static class CmdGetMediaListResult extends CmdBase {

        public List<CmdMediaInfo> list;

        public CmdGetMediaListResult(String command, List<CmdMediaInfo> list) {
            super(command);
            this.list = list;
        }
    }

    /**
     * 5. Server active disconnect.
     * event: "serverMessage",
     * data: {
     * command: "activeDisconnect"
     * }
     */
    public static class CmdActiveDisconnect extends CmdBase {
        public CmdActiveDisconnect(String command) {
            super(command);
        }
    }

    /**
     * 6. error
     * event: "serverMessage",
     * data: {
     * command: "error",
     * message: (string)
     * }
     */
    public static class CmdError extends CmdBase {

        public String message;

        public CmdError(String command, String message) {
            super(command);
            this.message = message;
        }
    }

    /**
     * 14. Notify client to download a video.
     * event: "serverMessage",
     * data: {
     * command: "needDownloadMedia",
     * id: (string) // Media ID
     * }
     */
    public static class CmdNeedDownloadMedia extends CmdBase {

        public String id; // media id

        public CmdNeedDownloadMedia(String command, String id) {
            super(command);
            this.id = id;
        }
    }

    /**
     * 15. Notify client to cancel download a video.
     * event: "serverMessage",
     * data: {
     * command: "cancelDownloadMedia",
     * id: (string) // Media ID
     * }
     */
    public static class CmdCancelDownloadMedia extends CmdBase {

        public String id; // media id

        public CmdCancelDownloadMedia(String command, String id) {
            super(command);
            this.id = id;
        }
    }

    /**
     * 16. Notify client has deleted a video.
     * event: "serverMessage",
     * data: {
     * command: "deleteMedia",
     * id: (string) // Media ID
     * }
     */
    public static class CmdDeleteMedia extends CmdBase {

        public String id; // media id

        public CmdDeleteMedia(String command, String id) {
            super(command);
            this.id = id;
        }
    }

    /**
     * 17. Notify client has deleted all video.
     * event: "serverMessage",
     * data: {
     * command: "deleteAllMedias"
     * }
     */
    public static class CmdDeleteAllMedias extends CmdBase {
        public CmdDeleteAllMedias(String command) {
            super(command);
        }
    }

    /**
     * 19. Notify all clients that the server is in a blocked state.
     * event: "serverMessage",
     * data: {
     * command: "startBlocking",
     * reason: (string) // blocking reason：（openFile）
     * }
     */
    public static class CmdStartBlocking extends CmdBase {

        public String reason;

        public CmdStartBlocking(String command, String reason) {
            super(command);
            this.reason = reason;
        }
    }

    /**
     * 20. Notify all clients that the server is in a non-blocked state.
     * event: "serverMessage",
     * data: {
     * command: "stopBlocking"
     * }
     */
    public static class CmdStopBlocking extends CmdBase {
        public CmdStopBlocking(String command) {
            super(command);
        }
    }

    /**
     * 21. Update newly added videos.
     * event: "serverMessage",
     data: {
     command: "updateNewMediasToClients",
     list: [
     {
     id: (string),
     name: (string),
     duration: (int), // 单位为毫秒
     size: (int),
     url: (string),
     thumbnail: (string), // 缩略图在服务器上的地址
     thumbnailWidth: (int),
     thumbnailHeight: (int),
     lastModified: (int), // 文件最后修改时间
     defaultVRSetting: (int),
     userVRSetting: (int)
     },
     ...
     ]
     }
     */
    public static class CmdUpdateNewMediasToClients extends CmdBase {

        public List<CmdMediaInfo> list;

        public CmdUpdateNewMediasToClients(String command, List<CmdMediaInfo> list) {
            super(command);
            this.list = list;
        }
    }


    /**
     * 22. Update the processed video.
     * event: "serverMessage",
     data: {
     command: "updateReadyMediaToClients",
     media: {
     id: (string),
     name: (string),
     duration: (int), // 单位为毫秒
     size: (int),
     url: (string),
     thumbnail: (string), // 缩略图在服务器上的地址
     thumbnailWidth: (int),
     thumbnailHeight: (int),
     lastModified: (int), // 文件最后修改时间
     defaultVRSetting: (int),
     userVRSetting: (int)
     }
     }
     */
    public static class CmdUpdateReadyMediaToClients extends CmdMediaInfo {

        public CmdUpdateReadyMediaToClients(String command, String id, String name, int duration, long size,
                            String url, String thumbnail, int thumbnailWidth, int thumbnailHeight,
                            long lastModified, int defaultVRSetting, int userVRSetting) {
            super(command,
                    id,
                    name,
                    duration,
                    size,
                    url,
                    thumbnail,
                    thumbnailWidth,
                    thumbnailHeight,
                    lastModified,
                    defaultVRSetting,
                    userVRSetting);
        }

    }

}
