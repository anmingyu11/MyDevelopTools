//Todo copyright
package xyz.skybox.repository;

import android.content.Context;
import android.content.SharedPreferences;

import xyz.skybox.gui.MainActivity;

public class SharedPreferencesManager {
    private SharedPreferences mSharedPreferences;
    private static SharedPreferencesManager sInstance;

    //Settings Key
    private final String NET_WORK_SERVICE_DESTROY = "NET_WORK_SERVICE_DESTROY";
    private final String IS_FIRST_RUN = "IS_FIRST_RUN";
    private final String FRAGMENT_ID = "FRAGMENT_ID";
    private final String DOWNLOAD_APK = "ID_NAME_STATUS";
    public static final String DOWNLOAD_SEPARATOR = ":";

    //Settings Value
    private Boolean isNetWorkServiceDestroy = false;
    private Boolean isFirstRun = true;
    private int mFragmentId = MainActivity.FRAGMENT_MY_VIDEOS;
    public final static int DEFAULT_REQUEST_ID = -31415926;

    public static SharedPreferencesManager getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new SharedPreferencesManager(context);
        }
        return sInstance;
    }

    private SharedPreferencesManager(Context context) {
        mSharedPreferences = context.getSharedPreferences("ZeusSettings", Context.MODE_PRIVATE);
    }

    public boolean isNetWorkServiceDestroy() {
        return isNetWorkServiceDestroy = mSharedPreferences.getBoolean(NET_WORK_SERVICE_DESTROY, false);
    }

    public boolean setNetWorkServiceDestroy(boolean isDestroyed) {
        return mSharedPreferences.edit().putBoolean(NET_WORK_SERVICE_DESTROY, isDestroyed).commit();
    }

    public boolean isFirstRun() {
        return isFirstRun = mSharedPreferences.getBoolean(IS_FIRST_RUN, true);
    }

    public boolean setNotFirstRun() {
        return mSharedPreferences.edit().putBoolean(IS_FIRST_RUN, false).commit();
    }

    public int getCurrentFragmentId() {
        return mSharedPreferences.getInt(FRAGMENT_ID, MainActivity.FRAGMENT_GALLERY);
    }

    public boolean setCurrentFragmentId(int id) {
        return mSharedPreferences.edit().putInt(FRAGMENT_ID, id).commit();
    }

    public boolean setDownload(String download) {
        return mSharedPreferences.edit().putString(DOWNLOAD_APK, download).commit();
    }

    public String getDownload() {
        return mSharedPreferences.getString(DOWNLOAD_APK, "");
    }

    public boolean getFragmentListMode(String fragment) {
        return mSharedPreferences.getBoolean(fragment, true);
    }

    public boolean saveFragmentListMode(String fragment, boolean isListMode) {
        return mSharedPreferences.edit().putBoolean(fragment, isListMode).commit();
    }

}
