package xyz.skybox.repository.setting;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import xyz.skybox.util.UpdateUtil;


public class InstallReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("android.intent.action.PACKAGE_ADDED")) {
            String packageName = intent.getDataString();
            if (packageName.equals(UpdateUtil.packageName(context))) {
                ZeusSettings.getInstance(context).setHasNew(false);
            }
        }
    }

}
