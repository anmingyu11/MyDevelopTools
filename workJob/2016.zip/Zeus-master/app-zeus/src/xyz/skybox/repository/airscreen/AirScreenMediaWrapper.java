//Todo copyRight
package xyz.skybox.repository.airscreen;

import android.app.Activity;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.graphics.drawable.Drawable;
import android.view.View;

import xyz.skybox.R;
import xyz.skybox.common.util.GuavaUtil;
import xyz.skybox.gui.MainActivity;
import xyz.skybox.repository.networkservice.NetworkService;
import xyz.skybox.util.LaunchHelper;
import xyz.skybox.util.Strings;
import xyz.skybox.util.Util;

public class AirScreenMediaWrapper {

    public final static int TYPE_REMOTE_VIDEO = 6;
    /**
     * id: (string),
     * name: (string),
     * duration: (int), // ms
     * size: (int),
     * url: (string),
     * thumbnail: (string), // url on server
     * thumbnailWidth: (int),
     * thumbnailHeight: (int),
     * lastModified: (int),
     * defaultVRSetting: (int),
     * userVRSetting: (int)
     */
    private boolean isClickable = true;

    private MainActivity mMainActivity;
    private String mId;
    private String mTitle;
    private int mDuration;
    private long mSize;
    private String mVideoUrl;
    private String mThumbnailUrl;
    private int mThumbnailWidth;
    private int mThumbnailHeight;
    private long mLastModified;// time ms
    private int mDefaultVrSetting;
    private int mUserVrSetting;

    //This two observable field just set it and this can be changed.
    public final ObservableInt mDownloadSize = new ObservableInt(0);
    public final ObservableField<String> mDownloadTip = new ObservableField<String>("");
    public final ObservableInt mState = new ObservableInt(STATE_NEED_DOWNLOAD);
    public final ObservableField<Drawable> mDownloadIcon = new ObservableField<Drawable>();
    public final ObservableBoolean isProgressBarVisible = new ObservableBoolean(false);
    public final ObservableBoolean isDownloadTipVisible = new ObservableBoolean(false);
    public final ObservableBoolean isDownloadFailed = new ObservableBoolean(false);
    public boolean isListMode = false;

    public static final int STATE_NEED_DOWNLOAD = 0;
    public static final int STATE_DOWNLOADING = 1;
    public static final int STATE_HAS_DOWNLOAD = 2;
    public static final int STATE_DOWNLOAD_FAILED = 3;

    private static final String[] TIPS = new String[]{
            "", "DOWNLOADING", "", "DOWNLOAD FAILED"
    };
    private static final int[] GRID_DRAWABLES = new int[]{
            R.drawable.air_screen_download_start_grid, R.drawable.air_screen_download_cancel_grid,
            R.drawable.download_grid_finished, R.drawable.air_screen_download_restart_grid
    };

    private static final int[] LIST_DRAWABLES = new int[]{
            R.drawable.air_screen_download_start_list, R.drawable.air_screen_download_cancel_list,
            R.drawable.download_list_finished, R.drawable.air_screen_download_restart_list
    };

    public AirScreenMediaWrapper(
            MainActivity activity,
            String id,
            String title,
            int duration,
            long size,
            String videoUrl,
            String thumbnailUrl,
            int thumbnailWidth,
            int thumbnailHeight,
            long lastModified,
            int defaultVrSetting,
            int userVrSetting) {
        mMainActivity = activity;
        mId = id;
        mTitle = title;
        mDuration = duration;
        mSize = size;
        mVideoUrl = videoUrl;
        mThumbnailUrl = thumbnailUrl;
        mThumbnailWidth = thumbnailWidth;
        mThumbnailHeight = thumbnailHeight;
        mLastModified = lastModified;
        mDefaultVrSetting = defaultVrSetting;
        mUserVrSetting = userVrSetting;
        setState(STATE_NEED_DOWNLOAD);
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public String getTitleOnView() {
        return Util.formatTitle(mTitle);
    }

    public int getDuration() {
        return mDuration;
    }

    public String getDurationString() {
        return Strings.millisToText(mDuration);
    }

    public void setDuration(int duration) {
        mDuration = duration;
    }

    public long getSize() {
        return mSize;
    }

    public void setSize(long size) {
        mSize = size;
    }

    public String getVideoUrl() {
        return mVideoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        mVideoUrl = videoUrl;
    }

    public String getThumbnailUrl() {
        return mThumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        mThumbnailUrl = thumbnailUrl;
    }

    public int getThumbnailWidth() {
        return mThumbnailWidth;
    }

    public void setThumbnailWidth(int thumbnailWidth) {
        mThumbnailWidth = thumbnailWidth;
    }

    public int getThumbnailHeight() {
        return mThumbnailHeight;
    }

    public void setThumbnailHeight(int thumbnailHeight) {
        mThumbnailHeight = thumbnailHeight;
    }

    public long getLastModified() {
        return mLastModified;
    }

    public void setLastModified(long lastModified) {
        mLastModified = lastModified;
    }

    public int getDefaultVrSetting() {
        return mDefaultVrSetting;
    }

    public void setDefaultVrSetting(int defaultVrSetting) {
        mDefaultVrSetting = defaultVrSetting;
    }

    public int getUserVrSetting() {
        return mUserVrSetting;
    }

    public void setUserVrSetting(int userVrSetting) {
        mUserVrSetting = userVrSetting;
    }

    public void setDownloadSize(int downloadSize) {
        mDownloadSize.set(downloadSize);
    }

    public void setDownloadTip(String tip) {
        mDownloadTip.set(tip);
        if (!tip.equals("")) {
            isDownloadTipVisible.set(true);
        } else {
            isDownloadTipVisible.set(false);
        }
    }

    public int getState() {
        return mState.get();
    }

    public void setState(int state) {
        mState.set(state);
        setDownloadTip(TIPS[state]);
        mDownloadIcon.set(mMainActivity.getResources().
                getDrawable(isListMode ?
                        LIST_DRAWABLES[state] :
                        GRID_DRAWABLES[state]));

        if (state == STATE_NEED_DOWNLOAD) {
            isDownloadFailed.set(false);
            isProgressBarVisible.set(false);
        } else if (state == STATE_DOWNLOAD_FAILED) {
            isDownloadFailed.set(true);
            isProgressBarVisible.set(true);
        } else if (state == STATE_HAS_DOWNLOAD) {
            isDownloadFailed.set(false);
            isProgressBarVisible.set(false);
        } else if (state == STATE_DOWNLOADING) {
            isDownloadFailed.set(false);
            isProgressBarVisible.set(true);
        }
    }

    public boolean isClickable() {
        return isClickable;
    }

    public void setClickable(boolean clickable) {
        isClickable = clickable;
    }

    public void onClickThumbnail(View view) {
        if (isClickable) {
            LaunchHelper launchHelper = new LaunchHelper((Activity) view.getContext());
            launchHelper.launchVrFromAir(this, "airscreen");
        }
    }

    public void onClickDownloadIcon(View view) {
        GuavaUtil.checkNotNull(mMainActivity);

        NetworkService.NetworkBinder binder = mMainActivity.getNetworkBinder();
        if (binder == null) {
            throw new NullPointerException("binder is null ");
        }

        if (isClickable) {
            switch (mState.get()) {
                case STATE_NEED_DOWNLOAD: {
                    binder.getDownloader().startDownload(mVideoUrl, this);
                    break;
                }
                case STATE_DOWNLOADING: {
                    binder.getDownloader().cancelDownload(mVideoUrl, this);
                    break;
                }
                case STATE_HAS_DOWNLOAD: {
                    break;
                }
                case STATE_DOWNLOAD_FAILED: {
                    binder.getDownloader().startDownload(mVideoUrl, this);
                }
            }
        }
    }

    public void setListMode(boolean listMode) {
        isListMode = listMode;
        mDownloadIcon.set(mMainActivity.getResources().
                getDrawable(isListMode ?
                        LIST_DRAWABLES[mState.get()] :
                        GRID_DRAWABLES[mState.get()]));
    }
}
