//Todo copyright
package xyz.skybox.repository.networkservice;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.Nullable;

import java.io.File;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import xyz.skybox.common.util.LogUtil;
import xyz.skybox.downloader.bizs.DLInfo;
import xyz.skybox.downloader.bizs.DLManager;
import xyz.skybox.downloader.interfaces.IDListener;
import xyz.skybox.gui.airscreen.AirScreenNetwork;
import xyz.skybox.media.MediaLibrary;
import xyz.skybox.repository.SharedPreferencesManager;
import xyz.skybox.repository.airscreen.AirScreenMediaWrapper;

import static xyz.skybox.util.AndroidDevices.FILE_SEPARATOR;
import static xyz.skybox.util.AndroidDevices.MY_VIDEO_DIRECTORY;

public class NetworkService extends Service {

    private NetworkBinder mBinder;
    private Downloader mDownloader = null;
    private Context mContext;

    public NetworkService() {
        super();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        LogUtil.e("onCreate");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        int result = super.onStartCommand(intent, flags, startId);
        LogUtil.e("onStartCommand");
        return result;
    }

    private void initBind() {
        mContext = this;
        if (mBinder == null) {
            mBinder = new NetworkBinder();
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        initBind();
        LogUtil.e("onBind");
        return mBinder;
    }

    @Override
    public void onRebind(Intent intent) {
        super.onRebind(intent);
        initBind();
        LogUtil.e("onRebind");
    }

    @Override
    public boolean onUnbind(Intent intent) {
        boolean result = super.onUnbind(intent);
        LogUtil.e("onUnbind");
        return result;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        LogUtil.e("onTaskRemoved");
    }

    public class NetworkBinder extends Binder {

        public NetworkBinder() {
        }

        public Downloader getDownloader() {
            if (mDownloader == null) {
                mDownloader = new Downloader();
            }
            return mDownloader;
        }

        public void cleanBinder() {
            getDownloader().pauseAllDownload();
            getDownloader().free();
        }
    }

    private void freeService() {
        mBinder.cleanBinder();
        mBinder = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        freeService();
        SharedPreferencesManager.getInstance(mContext).setNetWorkServiceDestroy(true);
        LogUtil.e("onDestroy");
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        LogUtil.e("onLowMemory");
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        LogUtil.e("onTrimMemory");
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        LogUtil.e("onConfigurationChanged");
    }

    public class Downloader {
        private DLManager mDLManager;

        private Downloader() {
            init();
        }

        private void init() {
            if (mContext != null) {
                mDLManager = DLManager.getInstance(mContext);
            } else {
                throw new NullPointerException("mContext cannot be null");
            }
        }

        private String formatFileName(String fileName) {
            int lastIndexOfdot = fileName.lastIndexOf(".");
            fileName = fileName.substring(0, lastIndexOfdot)
                    + fileName.substring(lastIndexOfdot, fileName.length()).replaceAll(" ", "_");
            return fileName.replaceAll(" ", "_");
        }

        public void startDownload(ConcurrentHashMap<String, AirScreenMediaWrapper> downloadMap) {
            for (String url : downloadMap.keySet()) {
                startDownload(url, downloadMap.get(url));
            }
        }

        public void startDownload(String url, final AirScreenMediaWrapper wrapper) {
            DLManager.getInstance(mContext)
                    .dlStart(
                            url,
                            MY_VIDEO_DIRECTORY,
                            null,
                            null,
                            new IDListener() {
                                private long wrapperDivider;

                                @Override
                                public void onPrepare() {
                                    wrapper.setState(AirScreenMediaWrapper.STATE_NEED_DOWNLOAD);
                                    LogUtil.d("onPrepare");
                                }

                                @Override
                                public void onStart(String fileName, String realUrl, long fileLength) {
                                    wrapperDivider = fileLength / 100;
                                    wrapper.setState(AirScreenMediaWrapper.STATE_DOWNLOADING);
                                    AirScreenNetwork.getInstance().notifyDownloadMediaStarted(wrapper.getId());
                                    LogUtil.d("WrapperDivider : " + wrapperDivider);
                                    LogUtil.d("start : " + fileName + " realUrl : " + realUrl + " fileLength : " + fileLength);
                                }

                                @Override
                                public void onProgress(long progress) {
                                    final long realProgress = progress / wrapperDivider;
                                    wrapper.setDownloadSize((int) realProgress);
                                    LogUtil.e("onProgress realSize: " + realProgress);
                                }

                                @Override
                                public void onStop(long progress) {
                                    final long realProgress = progress / wrapperDivider;
                                    wrapper.setDownloadSize(0);
                                    wrapper.setState(AirScreenMediaWrapper.STATE_NEED_DOWNLOAD);
                                    LogUtil.e("onStop : realProgress : " + realProgress);
                                }

                                @Override
                                public void onFinish(File file) {
                                    wrapper.setState(AirScreenMediaWrapper.STATE_HAS_DOWNLOAD);
                                    File newFile = new File(MY_VIDEO_DIRECTORY + FILE_SEPARATOR + formatFileName(wrapper.getTitle()));
                                    file.renameTo(newFile);
                                    AirScreenNetwork.getInstance().notifyDownloadMediaFinished(wrapper.getId());
                                    LogUtil.e("File name : " + file.getName() + " rename to : " + newFile.getName());
                                    MediaLibrary.getInstance().scanMediaItems();
                                    LogUtil.e("onFinish : " + file.getAbsolutePath());
                                }

                                @Override
                                public void onError(int status, String error) {
                                    wrapper.setState(AirScreenMediaWrapper.STATE_DOWNLOAD_FAILED);
                                    LogUtil.e("onError status:  " + status + " Error : " + error);
                                }
                            });
        }

        public void resumeDownload(String url, AirScreenMediaWrapper wrapper) {
            if (mDLManager.getDLInfo(url) != null) {
                startDownload(url, wrapper);
                LogUtil.e("Url : " + url + " exists, " + "download start");
            } else {
                LogUtil.e("This url: " + url + " not exists");
            }
        }

        /**
         * resume Download which in the task table.
         *
         * @param downloadMap
         */
        public void resumeAllDownload(ConcurrentHashMap<String, AirScreenMediaWrapper> downloadMap) {
            for (String url : downloadMap.keySet()) {
                resumeDownload(url, downloadMap.get(url));
            }
        }

        public void pauseDownload(String url) {
            mDLManager.dlStop(url);
            LogUtil.e("download stop : " + url);
        }

        public void pauseAllDownload() {
            for (String url : getAllDownloadingTasks().keySet()) {
                pauseDownload(url);
            }
        }

        public void cancelDownload(String url, AirScreenMediaWrapper wrapper) {
            mDLManager.dlCancel(url);
            AirScreenNetwork.getInstance().notifyDownloadMediaCancelled(wrapper.getId());
            LogUtil.e("cancel url : " + url);
        }

        public void cancelDownload(String url) {
            mDLManager.dlCancel(url);
            LogUtil.e("cancel url : " + url);
        }

        public void cancelAllDownload() {
            List<String> urls = mDLManager.getAllDLUrls();
            for (String url : urls) {
                cancelDownload(url);
            }
            LogUtil.e("cancel all download");
        }

        public void clearDownloadDb() {
            mDLManager.clearDownloadDataBase();
        }

        private ConcurrentHashMap<String, DLInfo> getAllDownloadingTasks() {
            return mDLManager.getDownloadingTasks();
        }

        public void free() {
            mDLManager = null;
        }
    }
}
