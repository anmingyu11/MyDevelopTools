// TODO
package xyz.skybox.repository.airscreen;

import android.util.Log;

import xyz.skybox.statistic.helper.FabricHelper;
import xyz.skybox.gui.airscreen.AirScreenNetwork;

public class CallbackRunnable implements Runnable {

    private static String TAG = "GUAN";

    private AirScreenNetwork mAirScreenNetwork = null;

    private boolean flag = true;

    public CallbackRunnable(AirScreenNetwork airScreenNetwork) {
        mAirScreenNetwork = airScreenNetwork;
    }

    @Override
    public void run() {

        while (flag) {
            if (mAirScreenNetwork == null) {
                stopLoop();
            } else {
                mAirScreenNetwork.tick();
            }

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                FabricHelper.logException(e);
                e.printStackTrace();
            }
        }
    }

    public void stopLoop() {
        flag = false;
        Log.e(TAG, " stopLoop flag: "+flag);
    }

}
