//Todo copyRight
package xyz.skybox.repository.imageloader;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.List;

import xyz.skybox.R;
import xyz.skybox.SkyboxApplication;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.statistic.helper.FabricHelper;
import xyz.skybox.media.MediaDatabase;
import xyz.skybox.media.MediaWrapper;
import xyz.skybox.media.Recognition;
import xyz.skybox.util.BitmapUtil;

public class ZeusLocalThumbnailRunnable implements Runnable {

    private String TAG;
    private int mWidth = 0;
    private int mHeight = 0;
    /**
     * When this runnable run in to the end , set isDone is true, so we can remove this in LocalThumbnailMap.
     */
    private boolean isDone = false;
    private boolean isRunning = false;

    private MediaWrapper mLocalMediaWrapper;
    private List<ThumbnailListener> mThumbnailListeners;

    public interface ThumbnailListener {
        void setThumbnail(Bitmap bitmap);
    }

    public ZeusLocalThumbnailRunnable(MediaWrapper localMediaWrapper) {
        TAG = localMediaWrapper.getLocation();
        mLocalMediaWrapper = localMediaWrapper;
        mThumbnailListeners = new ArrayList<ThumbnailListener>();

        mWidth = SkyboxApplication.getAppResources().getDimensionPixelSize(R.dimen.grid_card_thumb_width);
        mHeight = SkyboxApplication.getAppResources().getDimensionPixelSize(R.dimen.grid_card_thumb_height);
    }

    public void setHeight(int height) {
        mHeight = height;
    }

    public void setWidth(int width) {
        mWidth = width;
    }

    public String getTAG() {
        return TAG;
    }

    @Override
    public void run() {
        setRunning(true);

        try {
            LogUtil.d(TAG + " ------LocalThumbnailRunnable started------");
            LogUtil.d(TAG + " step 1 :  " + mLocalMediaWrapper.getUri());
            //防止异步重新加载.
            Bitmap bitmap = BitmapUtil.getPicture(mLocalMediaWrapper);
            if (bitmap != null) {
                setDone(true);
                setThumbnails(bitmap);
                LogUtil.d(TAG + " ------LocalThumbnailRunnable stopped------");
                return;
            }

            setDone(false);

            long time1 = LogUtil.currentTimeMillis();
            bitmap = Recognition.getRecognizeThumbnail(mLocalMediaWrapper.getUri(), mWidth, mHeight, mLocalMediaWrapper);
            long time2 = LogUtil.currentTimeMillis();
            LogUtil.duration(TAG + " getRecognizeThumbnail ", time1, time2);
            if (bitmap != null) {
                LogUtil.d(TAG + " getRecognizeThumbnail bitmap w, h: " + bitmap.getWidth() + "," + bitmap.getHeight());
            } else {
                LogUtil.d(TAG + " getRecognizeThumbnail bitmap failed");
            }
            LogUtil.d(TAG + " step 2 :  byte:" + bitmap + "/n item:" + mLocalMediaWrapper.getUri());

            if (bitmap == null) {
                LogUtil.d(TAG + " Thumbnail create failed " + mLocalMediaWrapper.getFileName());

                setDone(false);

                setThumbnails(null);
            } else {
                LogUtil.d(TAG + " Thumbnail created for " + mLocalMediaWrapper.getFileName());
                MediaDatabase.setPicture(mLocalMediaWrapper, bitmap);

                setDone(true);

                setThumbnails(bitmap);
            }
            LogUtil.d(TAG + " ------LocalThumbnailRunnable stopped------");
        } catch (Exception e) {
            FabricHelper.logException(e);
            e.printStackTrace();
        } finally {
            setRunning(false);
        }
    }

    public void addThumbnailListener(ThumbnailListener thumbnailListener) {
        mThumbnailListeners.add(thumbnailListener);
    }

    public List<ThumbnailListener> getThumbnailListeners() {
        return mThumbnailListeners;
    }

    private void setThumbnails(Bitmap bitmap) {
        for (ThumbnailListener thumbnailListener : mThumbnailListeners) {
            thumbnailListener.setThumbnail(bitmap);
        }
    }

    public void setDone(boolean done) {
        isDone = done;
        if (isDone) {
            ZeusImageLoader.LocalThumbnailExecutorController.removeExistLocalThumbnail(this);
        }
    }

    public void setRunning(boolean running) {
        isRunning = running;
    }

    public boolean isRunning() {
        return isRunning;
    }

    public boolean isDone() {
        return isDone;
    }
}
