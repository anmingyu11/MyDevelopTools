//Todo copyRight
package xyz.skybox.repository.networkservice;

public interface NetWorkServiceBindListener {
    void connected();
    void disconnect();
}
