package xyz.skybox.repository.imageloader;

import android.app.Activity;
import android.content.Context;
import android.databinding.BindingAdapter;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import xyz.skybox.R;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.statistic.helper.FabricHelper;
import xyz.skybox.gui.base.drawable.LoadingDrawable;
import xyz.skybox.gui.base.view.ThumbnailImageView;
import xyz.skybox.media.MediaDatabase;
import xyz.skybox.media.MediaLibrary;
import xyz.skybox.media.MediaWrapper;
import xyz.skybox.util.BitmapUtil;

public class ZeusImageLoader {

    @BindingAdapter({"RemoteThumbnailUrl"})
    public static void loadRemotePicture(final ImageView imageView, String url) {
        final Context context = imageView.getContext();

        final ThumbnailImageView thumbnailImageView;

        if (imageView instanceof ThumbnailImageView) {
            thumbnailImageView = (ThumbnailImageView) imageView;
        } else {
            throw new IllegalArgumentException("imageView is not instance of ThumbnailImageView");
        }

        Target target = new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                if (imageView.getTag() == this) {
                    thumbnailImageView.setBackground(new BitmapDrawable(context.getResources(), bitmap));
                    thumbnailImageView.stopLoading();
                    thumbnailImageView.removeLoadingImgSrc();
                }
            }

            @Override
            public void onBitmapFailed(Drawable errorDrawable) {
                if (imageView.getTag() == this) {
                    thumbnailImageView.setBackground(context.getResources().getDrawable(R.color.color_air_screen_thumnail_placeholder_background));
                    thumbnailImageView.stopLoading();
                    thumbnailImageView.removeLoadingImgSrc();
                    thumbnailImageView.setImageDrawable(errorDrawable);
                }
            }

            @Override
            public void onPrepareLoad(Drawable placeHolderDrawable) {
                if (imageView.getTag() == this) {
                    thumbnailImageView.setBackground(context.getResources().getDrawable(R.color.color_air_screen_thumnail_placeholder_background));
                    thumbnailImageView.setLoadingImgSrc();
                    thumbnailImageView.startLoading();
                }
            }
        };

        imageView.setTag(target);
        Picasso.with(context).
                load(url).
                error(R.drawable.load_img_failed).
                placeholder(new LoadingDrawable(context)).
                into(target);
    }

    public static void loadRcgType(final MediaWrapper mediaWrapper) {
        String type = MediaDatabase.getInstance().getMedia(mediaWrapper.getUri()).getRcgType();

        if (type != null) {
            //第一步获取成功， 添加到vr
            LogUtil.d("loadRcgType " + " get it from bit map cache " + " name : "
                    + mediaWrapper.getTitle() + " type : " + mediaWrapper.getRcgType());
            MediaLibrary.getInstance().notifyVRMediaUpdated(mediaWrapper);
        } else {
            //第二步： 没有获取到， 添加local thumbnail listener到executor中，等待执行
            LocalThumbnailExecutor.addLocalThumbnailListener(
                    mediaWrapper,
                    new ZeusLocalThumbnailRunnable.ThumbnailListener() {
                        @Override
                        public void setThumbnail(final Bitmap bitmap) {
                            //添加到vr
                            LogUtil.d("loadRcgType " + " get from runnable : " + " name : "
                                    + mediaWrapper.getTitle() + " type : " + mediaWrapper.getRcgType());
                            MediaLibrary.getInstance().notifyVRMediaUpdated(mediaWrapper);
                        }
                    });
            //第三步： 开始加载
            LocalThumbnailExecutorController.execute();
        }
    }

    @BindingAdapter({"LocalMedia"})
    public static void loadLocalPicture(final ImageView imageView, MediaWrapper mediaWrapper) {
        final Context context = imageView.getContext();
        final ThumbnailImageView thumbnailImageView;
        Bitmap bitmap = null;

        if (imageView instanceof ThumbnailImageView) {
            thumbnailImageView = (ThumbnailImageView) imageView;
        } else {
            throw new IllegalArgumentException("imageView is not instance of ThumbnailImageView");
        }

        final Target target = new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                if (imageView.getTag() == this) {
                    thumbnailImageView.setBackground(new BitmapDrawable(context.getResources(), bitmap));
                    thumbnailImageView.stopLoading();
                    thumbnailImageView.removeLoadingImgSrc();
                }
            }

            @Override
            public void onBitmapFailed(Drawable errorDrawable) {
                if (imageView.getTag() == this) {
                    thumbnailImageView.setBackground(context.getResources().getDrawable(R.color.color_air_screen_thumnail_placeholder_background));
                    thumbnailImageView.stopLoading();
                    thumbnailImageView.removeLoadingImgSrc();
                    thumbnailImageView.setImageDrawable(errorDrawable);
                }
            }

            @Override
            public void onPrepareLoad(Drawable placeHolderDrawable) {
                if (imageView.getTag() == this) {
                    thumbnailImageView.setBackground(context.getResources().getDrawable(R.color.color_air_screen_thumnail_placeholder_background));
                    thumbnailImageView.setLoadingImgSrc();
                    thumbnailImageView.startLoading();
                }
            }
        };

        imageView.setTag(target);

        target.onPrepareLoad(new LoadingDrawable(context));

        //第一步： 获取缩略图， 从内存缓存中获取，如果没有，读取数据库中的picture字段。
        bitmap = BitmapUtil.getPicture(mediaWrapper);

        if (bitmap != null) {
            //第一步获取成功， 加载缩略图
            target.onBitmapLoaded(bitmap, null);
        } else {
            //第二步： 没有获取到， 添加local thumbnail listener到executor中，等待执行
            LocalThumbnailExecutor.addLocalThumbnailListener(
                    mediaWrapper,
                    new ZeusLocalThumbnailRunnable.ThumbnailListener() {
                        @Override
                        public void setThumbnail(final Bitmap bitmap) {
                            ((Activity) context).runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    setCover(context, target, bitmap);
                                }
                            });
                        }
                    });
            //第三步： 开始加载
            LocalThumbnailExecutorController.execute();
        }
    }


    private static void setCover(Context context, Target target, Bitmap bitmap) {
        if (bitmap != null) {
            target.onBitmapLoaded(bitmap, null);
        } else {
            target.onBitmapFailed(context.getResources().getDrawable(R.drawable.load_img_failed));
        }
    }

    public static class LocalThumbnailExecutorController {

        public static void execute() {
            LocalThumbnailExecutor.execute();
        }

        public static void destroy() {
            LocalThumbnailExecutor.destroy();
        }

        public static void removeExistLocalThumbnail(ZeusLocalThumbnailRunnable localThumbnail) {
            LocalThumbnailExecutor.removeExistLocalThumbnail(localThumbnail);
        }
    }

    private static class LocalThumbnailExecutor {
        /**
         * 存储将要execute的local thumbnail
         */
        private static final ConcurrentHashMap<String, ZeusLocalThumbnailRunnable> LOCAL_THUMBNAIL_MAP = new ConcurrentHashMap<String, ZeusLocalThumbnailRunnable>();
        //读写锁
        private static final ReadWriteLock READ_WRITE_LOCK = new ReentrantReadWriteLock();

        //缩略图加载线程线程池
        private static ThreadPoolExecutor sExecutor = null;
        private static final ThreadFactory THREAD_FACTORY = new ThreadFactory() {
            @Override
            public Thread newThread(Runnable runnable) {
                Thread thread = new Thread(runnable);
                thread.setPriority(Thread.NORM_PRIORITY);
                return thread;
            }
        };
        private static final int CORE_POOL_SIZE = 3;
        private static final int MAXIMUM_POOL_SIZE = 3;
        private static final int KEEP_ALIVE_TIME = 5;


        private static void addLocalThumbnailListener(MediaWrapper mediaWrapper, ZeusLocalThumbnailRunnable.ThumbnailListener thumbnailListener) {
            READ_WRITE_LOCK.writeLock().lock();
            //未获取缩略图或未成功
            if (mapContains(mediaWrapper)) {
                //如果已经添加了对应的localThumbnail，在已有的thumbnail value中添加新的listener
                LogUtil.d(mediaWrapper.getLocation() + " exists ");
                LOCAL_THUMBNAIL_MAP.get(mediaWrapper.getLocation()).addThumbnailListener(thumbnailListener);
            } else {
                //如果没有添加对应的localThumbnail，创建的thumbnail对象
                LogUtil.d(mediaWrapper.getLocation() + " not exists create a new Thumbnail");
                ZeusLocalThumbnailRunnable localThumbnail = new ZeusLocalThumbnailRunnable(mediaWrapper);
                localThumbnail.addThumbnailListener(thumbnailListener);
                LOCAL_THUMBNAIL_MAP.put(mediaWrapper.getLocation(), localThumbnail);
            }
            READ_WRITE_LOCK.writeLock().unlock();
        }

        private static void removeExistLocalThumbnail(ZeusLocalThumbnailRunnable localThumbnail) {
            LOCAL_THUMBNAIL_MAP.remove(localThumbnail.getTAG());
        }

        /**
         * @param mediaWrapper
         * @return 执行哈希表sLocalThumbnails中是否存在
         */
        private static boolean mapContains(MediaWrapper mediaWrapper) {
            return LOCAL_THUMBNAIL_MAP.containsKey(mediaWrapper.getLocation());
        }

        private static void createExecutor() {
            sExecutor = new ThreadPoolExecutor(
                    CORE_POOL_SIZE,
                    MAXIMUM_POOL_SIZE,
                    KEEP_ALIVE_TIME,
                    TimeUnit.SECONDS,
                    new LinkedBlockingQueue<Runnable>(),
                    THREAD_FACTORY);
        }

        private static void execute() {
            if (sExecutor == null) {
                LogUtil.d("Thumbnail executor is null create");
                createExecutor();
            }
            if (sExecutor.isShutdown() || sExecutor.isTerminated()) {
                LogUtil.d("Thumbnail executor is terminated");
                createExecutor();
            } else if (sExecutor.isTerminating()) {
                try {
                    if (sExecutor.awaitTermination(2, TimeUnit.SECONDS)) {
                        LogUtil.d("Thumbnail executor is awaited and then terminated");
                        createExecutor();
                    } else {
                        throw new InterruptedException("await termination failed");
                    }
                } catch (InterruptedException e) {
                    FabricHelper.logException(e);
                    e.printStackTrace();
                } finally {
                    destroy();
                }
            }

            Set<String> keySet = LOCAL_THUMBNAIL_MAP.keySet();
            LogUtil.d("LocalThumbnailExecutor Start , Task Size : " + keySet.size());
            for (String key : LOCAL_THUMBNAIL_MAP.keySet()) {

                ZeusLocalThumbnailRunnable localThumbnail = LOCAL_THUMBNAIL_MAP.get(key);
                LogUtil.d("BadAssImageLoader : " + key
                        + " isRunning : " + localThumbnail.isRunning()
                        + " isDone : " + localThumbnail.isDone());
                //去掉正在BlockQueue中等待的任务,或者正在执行中的任务．
                if (!sExecutor.getQueue().contains(localThumbnail)
                        && !localThumbnail.isRunning()) {
                    sExecutor.execute(LOCAL_THUMBNAIL_MAP.get(key));
                }
            }

        }

        private static void destroy() {
            LogUtil.d("------ destroy start ------");
            BlockingQueue<Runnable> blockingDeque = sExecutor.getQueue();
            LogUtil.d("before clear queue size : " + blockingDeque.size());
            blockingDeque.clear();
            LogUtil.d("after clear queue size : " + blockingDeque.size());
            LOCAL_THUMBNAIL_MAP.clear();
            sExecutor.shutdownNow();
            LogUtil.d("------ destroy end ------");
        }

    }
}
