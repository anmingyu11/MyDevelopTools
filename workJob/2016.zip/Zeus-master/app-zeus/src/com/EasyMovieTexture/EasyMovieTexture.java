package com.EasyMovieTexture;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.DhcpInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.Surface;

import com.google.gson.Gson;
import com.google.vr.ndk.base.DaydreamApi;
import com.unity3d.player.UnityPlayer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Map;

import tv.danmaku.ijk.media.player.IMediaPlayer;
import tv.danmaku.ijk.media.player.IjkMediaPlayer;
import xyz.skybox.R;
import xyz.skybox.SkyboxApplication;
import xyz.skybox.common.util.LogUtil;
import xyz.skybox.imageloader.ImageLoader;
import xyz.skybox.media.MediaContentProvider;
import xyz.skybox.media.MediaLibrary;
import xyz.skybox.media.MediaUtils;
import xyz.skybox.media.MediaWrapper;
import xyz.skybox.media.Recognition;
import xyz.skybox.util.AndroidDevices;
import xyz.skybox.util.FileRcgHelper;
import xyz.skybox.util.NetworkEvent;

import static android.content.Context.WIFI_SERVICE;
import static android.support.v4.content.PermissionChecker.PERMISSION_GRANTED;
import static xyz.skybox.util.Util.printExceptionLog;


//import android.opengl.GLES20;

/**
 *
 */
public class EasyMovieTexture implements
        SurfaceTexture.OnFrameAvailableListener,
        IMediaPlayer.OnPreparedListener,
        IMediaPlayer.OnCompletionListener,
        IMediaPlayer.OnErrorListener,
        IMediaPlayer.OnBufferingUpdateListener {
    private Activity m_UnityActivity = null;
    private MediaLibrary mMediaLibrary;
    private IMediaPlayer m_MediaPlayer = null;

    private int m_iUnityTextureID = -1;
    private int m_iSurfaceTextureID = -1;
    private SurfaceTexture m_SurfaceTexture = null;
    private Surface m_Surface = null;
    private int m_iCurrentSeekPercent = 0;
    private int m_iCurrentSeekPosition = 0;
    public int m_iNativeMgrID;
    private String m_strFileName;
    private int m_iErrorCode;
    private int m_iErrorCodeExtra;
    private boolean m_bRockchip = true;
    private boolean m_bSplitOBB = false;
    private String m_strOBBName;
    public boolean m_bUpdate = false;
    private Uri mUri;
    private Map<String, String> mHeaders;

    public static ArrayList<EasyMovieTexture> m_objCtrl = new ArrayList<EasyMovieTexture>();

    public static EasyMovieTexture GetObject(int iID) {
        for (int i = 0; i < m_objCtrl.size(); i++) {
            if (m_objCtrl.get(i).m_iNativeMgrID == iID) {
                return m_objCtrl.get(i);
            }
        }
        return null;
    }

    private static final int GL_TEXTURE_EXTERNAL_OES = 0x8D65;

//    public native int InitNDK(Object obj);

//    public native void SetAssetManager(AssetManager assetManager);

    public native int InitApplication();

    public native void QuitApplication();

    public native void SetVideoSize(int InWidth, int InHeight, boolean bRockchip);

    public native void Render(float[] InValue, int Length);

//  public native void SetManagerID(int iID);

//  public native int GetManagerID();

    public native int GetSrcTexID();

    public native void SetUnityTextureID(int iTextureID);

//    public native int nativeRecognition(String fileName, int width, int height, int type, byte[] byteArray);
//
//    public native void nativeStartupRecognition();
//
//    public native void nativeShutdownRecognition();

    static {
        LogUtil.logStackTrace();

//        System.loadLibrary("skybox");

        Recognition.startupRecognition();

    }

    MEDIA_PLAYER_STATE m_iCurrentState = MEDIA_PLAYER_STATE.NOT_READY;

    public void Destroy() {
        if (m_iSurfaceTextureID != -1) {
//            int[] textures = new int[1];
//            textures[0] = m_iSurfaceTextureID;
//            GLES20.glDeleteTextures(1, textures, 0);
            m_iSurfaceTextureID = -1;
        }

//        SetManagerID(m_iNativeMgrID);
        QuitApplication();

        m_objCtrl.remove(this);
    }

    public void UnLoad() {
        if (m_MediaPlayer != null) {
            if (m_iCurrentState != MEDIA_PLAYER_STATE.NOT_READY) {
                try {
                    this.m_MediaPlayer.stop();
                    this.m_MediaPlayer.release();
                    this.m_MediaPlayer = null;
                    if (this.m_Surface != null) {
                        this.m_Surface.release();
                        this.m_Surface = null;
                    }
                    if (this.m_SurfaceTexture != null) {
                        this.m_SurfaceTexture.release();
                        this.m_SurfaceTexture = null;
                    }
                    if (this.m_iSurfaceTextureID != -1) {
//                        int[] arrayOfInt = new int[1];
//                        arrayOfInt[0] = this.m_iSurfaceTextureID;
//                        GLES20.glDeleteTextures(1, arrayOfInt, 0);
                        this.m_iSurfaceTextureID = -1;
                    }
                    return;
                } catch (SecurityException localSecurityException2) {
                    localSecurityException2.printStackTrace();
                } catch (IllegalStateException localIllegalStateException2) {
                    localIllegalStateException2.printStackTrace();
                }
            }
        }
    }

    public boolean Load() throws SecurityException, IllegalStateException, IOException {

        UnLoad();

        m_iCurrentState = MEDIA_PLAYER_STATE.NOT_READY;


        IjkMediaPlayer localIjkMediaPlayer = new IjkMediaPlayer();
        localIjkMediaPlayer.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "mediacodec-all-videos", 1L);
        localIjkMediaPlayer.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "opensles", 0L);
        localIjkMediaPlayer.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "overlay-format", IjkMediaPlayer.SDL_FCC_RV32);
        localIjkMediaPlayer.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "framedrop", 1L);
        localIjkMediaPlayer.setOption(IjkMediaPlayer.OPT_CATEGORY_PLAYER, "start-on-prepared", 0L);
        localIjkMediaPlayer.setOption(IjkMediaPlayer.OPT_CATEGORY_FORMAT, "http-detect-range-support", 0L);
        localIjkMediaPlayer.setOption(IjkMediaPlayer.OPT_CATEGORY_CODEC, "skip_loop_filter", 48L);
        this.m_MediaPlayer = localIjkMediaPlayer;
        this.m_MediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        this.m_bUpdate = false;

        this.mUri = Uri.parse(this.m_strFileName);

        this.m_MediaPlayer.setDataSource(this.m_UnityActivity.getApplicationContext(), this.mUri, this.mHeaders);

        if (this.m_iSurfaceTextureID == -1)
            this.m_iSurfaceTextureID = GetSrcTexID();

        this.m_SurfaceTexture = new SurfaceTexture(this.m_iSurfaceTextureID);
        this.m_SurfaceTexture.setOnFrameAvailableListener(this);
        this.m_Surface = new Surface(this.m_SurfaceTexture);
        this.m_MediaPlayer.setSurface(this.m_Surface);
        this.m_MediaPlayer.setOnPreparedListener(this);
        this.m_MediaPlayer.setOnCompletionListener(this);
        this.m_MediaPlayer.setOnErrorListener(this);
        this.m_MediaPlayer.prepareAsync();

        return true;
    }

    synchronized public void onFrameAvailable(SurfaceTexture surface) {
        m_bUpdate = true;
    }

    public void UpdateVideoTexture() {

        if (m_bUpdate == false)
            return;

        if (m_MediaPlayer != null) {
            if (m_iCurrentState == MEDIA_PLAYER_STATE.PLAYING || m_iCurrentState == MEDIA_PLAYER_STATE.PAUSED) {

//                SetManagerID(m_iNativeMgrID);

//                boolean[] abValue = new boolean[1];
//                GLES20.glGetBooleanv(GLES20.GL_DEPTH_TEST, abValue, 0);
//                GLES20.glDisable(GLES20.GL_DEPTH_TEST);
                m_SurfaceTexture.updateTexImage();

                float[] mMat = new float[16];

                m_SurfaceTexture.getTransformMatrix(mMat);

                Render(mMat, 16);

//                if (abValue[0]) {
//                    GLES20.glEnable(GLES20.GL_DEPTH_TEST);
//                } else {
//
//                }

//                abValue = null;
            }
        }
    }

    public void SetRockchip(boolean bValue) {
        m_bRockchip = bValue;
    }

    public void SetLooping(boolean bLoop) {
        if (m_MediaPlayer != null)
            m_MediaPlayer.setLooping(bLoop);
    }

    public void SetVolume(float fVolume) {
        if (m_MediaPlayer != null) {
            m_MediaPlayer.setVolume(fVolume, fVolume);
        }
    }


    public void SetSeekPosition(int iSeek) {
        if (m_MediaPlayer != null) {
            if (m_iCurrentState == MEDIA_PLAYER_STATE.READY || m_iCurrentState == MEDIA_PLAYER_STATE.PLAYING || m_iCurrentState == MEDIA_PLAYER_STATE.PAUSED) {
                m_MediaPlayer.seekTo(iSeek);
            }
        }
    }

    public int GetSeekPosition() {
        if (m_MediaPlayer != null) {
            if (m_iCurrentState == MEDIA_PLAYER_STATE.READY || m_iCurrentState == MEDIA_PLAYER_STATE.PLAYING || m_iCurrentState == MEDIA_PLAYER_STATE.PAUSED) {
                try {
                    m_iCurrentSeekPosition = (int) m_MediaPlayer.getCurrentPosition();
                } catch (SecurityException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IllegalStateException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }

        return m_iCurrentSeekPosition;
    }

    public int GetCurrentSeekPercent() {
        return m_iCurrentSeekPercent;
    }


    public void Play(int iSeek) {
        if (m_MediaPlayer != null) {
            if (m_iCurrentState == MEDIA_PLAYER_STATE.READY || m_iCurrentState == MEDIA_PLAYER_STATE.PAUSED || m_iCurrentState == MEDIA_PLAYER_STATE.END) {

                m_MediaPlayer.start();
                m_MediaPlayer.seekTo(iSeek);

                m_iCurrentState = MEDIA_PLAYER_STATE.PLAYING;
            }
        }
    }

    public void Reset() {
        if (m_MediaPlayer != null) {
            if (m_iCurrentState == MEDIA_PLAYER_STATE.PLAYING) {
                m_MediaPlayer.reset();
            }
        }
        m_iCurrentState = MEDIA_PLAYER_STATE.NOT_READY;
    }

    public void Stop() {
        if (m_MediaPlayer != null) {
            if (m_iCurrentState == MEDIA_PLAYER_STATE.PLAYING) {
                m_MediaPlayer.stop();

            }

        }
        m_iCurrentState = MEDIA_PLAYER_STATE.NOT_READY;
    }

    public void RePlay() {
        if (m_MediaPlayer != null) {
            if (m_iCurrentState == MEDIA_PLAYER_STATE.PAUSED) {
                m_MediaPlayer.start();
                m_iCurrentState = MEDIA_PLAYER_STATE.PLAYING;
            }
        }
    }

    public void Pause() {
        if (m_MediaPlayer != null) {
            if (m_iCurrentState == MEDIA_PLAYER_STATE.PLAYING) {
                m_MediaPlayer.pause();
                m_iCurrentState = MEDIA_PLAYER_STATE.PAUSED;
            }
        }
    }

    public int GetVideoWidth() {
        if (m_MediaPlayer != null) {
            return m_MediaPlayer.getVideoWidth();
        }

        return 0;
    }

    public int GetVideoHeight() {
        if (m_MediaPlayer != null) {
            return m_MediaPlayer.getVideoHeight();
        }

        return 0;
    }

    public boolean IsUpdateFrame() {
        if (m_bUpdate == true) {
            return true;
        } else {
            return false;
        }
    }

    public void SetUnityTexture(int iTextureID) {
        m_iUnityTextureID = iTextureID;
//        SetManagerID(m_iNativeMgrID);
        SetUnityTextureID(m_iUnityTextureID);
    }

    public void SetSplitOBB(boolean bValue, String strOBBName) {
        m_bSplitOBB = bValue;
        m_strOBBName = strOBBName;
    }

    public int GetDuration() {
        if (m_MediaPlayer != null) {
            return (int) m_MediaPlayer.getDuration();
        }
        return -1;
    }

    public int InitNative(EasyMovieTexture obj) {
        IjkMediaPlayer.loadLibrariesOnce(null);
        IjkMediaPlayer.native_profileBegin("libijkplayer.so");
//        m_iNativeMgrID = InitNDK(obj);
        m_objCtrl.add(this);

        return m_iNativeMgrID;
    }

    public void SetUnityActivity(Activity unityActivity) {
//        SetManagerID(m_iNativeMgrID);
        m_UnityActivity = unityActivity;
//        SetAssetManager(m_UnityActivity.getAssets());

        // Set application context and scan medias.
        //Todo this is no need SkyboxApplication.setAppContext(unityActivity.getApplicationContext());
    }

    public void NDK_SetFileName(String strFileName) {
        m_strFileName = strFileName;
    }

    public void InitJniManager() {
//        SetManagerID(m_iNativeMgrID);
        InitApplication();
    }

    public int GetStatus() {
        return m_iCurrentState.GetValue();
    }

    public void SetNotReady() {
        m_iCurrentState = MEDIA_PLAYER_STATE.NOT_READY;
    }

    public void SetWindowSize() {
//        SetManagerID(m_iNativeMgrID);
        SetVideoSize(GetVideoWidth(), GetVideoHeight(), m_bRockchip);
    }

    public int GetError() {
        return m_iErrorCode;
    }

    public int GetErrorExtra() {
        return m_iErrorCodeExtra;
    }

    @Override
    public boolean onError(IMediaPlayer arg0, int arg1, int arg2) {

        if (arg0 == m_MediaPlayer) {
            String strError;

            switch (arg1) {
                case MediaPlayer.MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK:
                    strError = "MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK";
                    break;
                case MediaPlayer.MEDIA_ERROR_SERVER_DIED:
                    strError = "MEDIA_ERROR_SERVER_DIED";
                    break;
                case MediaPlayer.MEDIA_ERROR_UNKNOWN:
                    strError = "MEDIA_ERROR_UNKNOWN";
                    break;
                default:
                    strError = "Unknown error " + arg1;
            }

            m_iErrorCode = arg1;
            m_iErrorCodeExtra = arg2;

            m_iCurrentState = MEDIA_PLAYER_STATE.ERROR;

            return true;
        }

        return false;
    }

    @Override
    public void onCompletion(IMediaPlayer arg0) {
        if (arg0 == m_MediaPlayer)
            m_iCurrentState = MEDIA_PLAYER_STATE.END;
    }

    @Override
    public void onBufferingUpdate(IMediaPlayer arg0, int arg1) {
        if (arg0 == m_MediaPlayer)
            m_iCurrentSeekPercent = arg1;
    }

    @Override
    public void onPrepared(IMediaPlayer arg0) {
        if (arg0 == m_MediaPlayer) {
            m_iCurrentState = MEDIA_PLAYER_STATE.READY;

//            SetManagerID(m_iNativeMgrID);
            m_iCurrentSeekPercent = 0;
            m_MediaPlayer.setOnBufferingUpdateListener(this);
        }
    }

    public enum MEDIA_PLAYER_STATE {
        NOT_READY(0),
        READY(1),
        END(2),
        PLAYING(3),
        PAUSED(4),
        STOPPED(5),
        ERROR(6);

        private int iValue;

        MEDIA_PLAYER_STATE(int i) {
            iValue = i;
        }

        public int GetValue() {
            return iValue;
        }
    }


    /**
     * ---------------------------------------------------------------------------------------------
     * ---------------------------------------------------------------------------------------------
     */

    private final static String TAG = "SKYBOX";

    private static final String MY_VIDEO_PATH_KEY = "/SKYBOX/";
    private static final int AIR_PLAY_TYPE = 6;

    private static final String ANDROID_APK_NAME = "vlc-android-debug.apk";
    private static final String ANDROID_PACKAGE_NAME = "xyz.skybox";
    private static final String ANDROID_CLASS_NAME = "xyz.skybox.gui.MainActivity";

    private static final String SHARED_FILE_NAME = "ZeusSettings";
    private static final String SHARED_FILE_BOOLEAN_VALUE = "IS_FIRST_RUN";

    // Media.
    private static final String MEDIA_LOCATION = "_id"; //standard key for primary key, needed for search suggestions
    private static final String MEDIA_LENGTH = "length";
    private static final String MEDIA_TYPE = "type";
    private static final String MEDIA_TITLE = "title";
    private static final String MEDIA_ARTIST = "artist";
    private static final String MEDIA_LAST_MODIFIED = "last_modified";

    // History.
    private static final String HISTORY_DATE = MEDIA_LAST_MODIFIED;
    private static final String HISTORY_TITLE = MEDIA_TITLE;
    private static final String HISTORY_ARTIST = MEDIA_ARTIST;
    private static final String HISTORY_URI = MEDIA_LOCATION;
    private static final String HISTORY_TYPE = MEDIA_TYPE;
    private static final String HISTORY_LENGTH = MEDIA_LENGTH;
    private static final String HISTORY_FILE_SIZE = "size";
    private static final String HISTORY_SERVER_ID = "id";// server id

    // Favorite.
    private static final String FAVOUR_URI = "uri";
    private static final String FAVOUR_TITLE = "title";
    private static final String FAVOUR_ICON_URL = "icon_url";
    private static final String FAVOUR_LENGTH = "length";
    private static final String FAVOUR_FILE_SIZE = "size";
    private static final String FAVOUR_SERVER_ID = "id";// server id

    private static final String PROVIDER_URI = "content://" + MediaContentProvider.AUTHORITY + "/";
    private static final String APP_PROVIDER_URI = "content://" + MediaContentProvider.AUTHORITY_APP + "/";

    private static final String PATH_VIDEOS = "videos";
    private static final String PATH_PLAY = "play";
    private static final String PATH_SERVER = "server";
    private static final String PATH_HISTORY = "history";
    private static final String PATH_FAVOURITE = "favourite";

    private static final String PROVIDER_VIDEOS_URI = PROVIDER_URI + PATH_VIDEOS;
    private static final String PROVIDER_PLAY_URI = APP_PROVIDER_URI + PATH_PLAY;
    private static final String PROVIDER_SERVER_URI = APP_PROVIDER_URI + PATH_SERVER;
    private static final String PROVIDER_HISTORY_URI = PROVIDER_URI + PATH_HISTORY;
    private static final String PROVIDER_FAVOURITE_URI = PROVIDER_URI + PATH_FAVOURITE;

    private Thread mLoadThread;
    private Thread mLoadHistoryThread;
    private Thread mLoadFavouriteThread;
    private Thread mGetNetworkInfoThread;
    private Thread mGetPlayThread;
    private boolean mScanCompleted = false;
    private boolean mLoadCompleted = false;
    private boolean mLoadHistoryCompleted = false;
    private boolean mLoadFavouriteCompleted = false;
    private boolean mGetPlayCompleted = false;

    private VideoInfo mPlayVideoInfo;

    private ArrayList<VideoInfo> mVideosList = new ArrayList<VideoInfo>();
    private ArrayList<VideoInfo> mHistoryList = new ArrayList<VideoInfo>();
    private ArrayList<VideoInfo> mFavouriteList = new ArrayList<VideoInfo>();

    public void enableDebug(boolean enable) {
        LogUtil.enableDebug(enable);
    }

    public int getThumbWidth() {
        return SkyboxApplication.getAppResources().getDimensionPixelSize(R.dimen.grid_card_thumb_width);
    }

    public int getThumbHeight() {
        return SkyboxApplication.getAppResources().getDimensionPixelSize(R.dimen.grid_card_thumb_height);
    }

    public boolean isAndroidAppInstalled() {
        return isAppInstalled(m_UnityActivity, ANDROID_PACKAGE_NAME);
    }

    private boolean isAppInstalled(Context context, String packageName) {
        PackageInfo packageInfo;
        try {
            packageInfo = context.getPackageManager().getPackageInfo(packageName, 0);
        } catch (PackageManager.NameNotFoundException e) {
            packageInfo = null;
//            e.printStackTrace();
        }
        if (packageInfo == null) {
            return false;
        } else {
            return true;
        }
    }

    private Context getTargetContext() throws PackageManager.NameNotFoundException {
        return m_UnityActivity.createPackageContext(ANDROID_PACKAGE_NAME, Context.CONTEXT_IGNORE_SECURITY);
    }

    public boolean checkRunAndroidApp() {
        try {
            SharedPreferences share = getTargetContext().getSharedPreferences(SHARED_FILE_NAME,
                    Context.MODE_WORLD_READABLE | Context.MODE_MULTI_PROCESS);

            // If app run, it will get value of false.
            return !share.getBoolean(SHARED_FILE_BOOLEAN_VALUE, true);

        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return false;
    }

    public void launchInstallApk() {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setDataAndType(Uri.parse("file://" + Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + ANDROID_APK_NAME),
                "application/vnd.android.package-archive");
        m_UnityActivity.startActivity(intent);
    }

    public void launchAndroidApp() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setComponent(new ComponentName(ANDROID_PACKAGE_NAME, ANDROID_CLASS_NAME));
            m_UnityActivity.startActivity(intent);
        } catch (ActivityNotFoundException e) {
        }
    }

    public boolean loadAndroidApk() {
        return copyApkFromAssets(m_UnityActivity, ANDROID_APK_NAME,
                Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + ANDROID_APK_NAME);
    }

    private boolean copyApkFromAssets(Context context, String fileName, String path) {

        boolean copyIsFinish = false;
        try {

            InputStream is = context.getAssets().open(fileName);
            File file = new File(path);
            file.createNewFile();
            FileOutputStream fos = new FileOutputStream(file);
            byte[] temp = new byte[1024];
            int i = 0;
            while ((i = is.read(temp)) > 0) {
                fos.write(temp, 0, i);
            }
            fos.close();
            is.close();
            copyIsFinish = true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return copyIsFinish;
    }

    public class ServerInfo {

        String computerId;
        String computerName;
        String ip;
        String port;

        public String getComputerId() {
            if (TextUtils.isEmpty(computerId)) {
                computerId = "no_computer_id";
            }
            return computerId;
        }

        public String getComputerName() {
            if (TextUtils.isEmpty(computerName)) {
                computerName = "no_computer_name";
            }
            return computerName;
        }

        public String getComputerIp() {
            if (TextUtils.isEmpty(ip)) {
                ip = "no_computer_ip";
            }
            return ip;
        }

        public String getComputerPort() {
            if (TextUtils.isEmpty(port)) {
                port = "no_computer_port";
            }
            return port;
        }

    }

    public class VideoInfo {

        String MEDIA_LOCATION; // 0
        long MEDIA_TIME;
        long MEDIA_LENGTH;
        int MEDIA_TYPE;
        String MEDIA_TITLE;
        String MEDIA_ARTIST;
        String MEDIA_GENRE;
        String MEDIA_ALBUM;
        String MEDIA_ALBUMARTIST;
        int MEDIA_WIDTH;
        int MEDIA_HEIGHT;
        String MEDIA_ARTWORKURL;
        int MEDIA_AUDIOTRACK;
        int MEDIA_SPUTRACK;
        int MEDIA_TRACKNUMBER;//14
        int MEDIA_DISCNUMBER;//15
        long MEDIA_LAST_MODIFIED;//16
        byte[] MEDIA_PICTURE;// 17
        String MEDIA_EXTERNAL_PLAY;// 18
        String MEDIA_RCG_TYPE; // 19
        String MEDIA_USER_RCG_TYPE; // 20
        long MEDIA_SIZE; // 21
        String MEDIA_THUMBNAIL_URI; // 22
        int MEDIA_THUMBNAIL_WIDTH; // 23
        int MEDIA_THUMBNAIL_HEIGHT; // 24
        String MEDIA_REMOTE_ID; // 25
        String MEDIA_SERVER_ID; // 25

        public void setMediaRcgType(String rcgType) {
            MEDIA_RCG_TYPE = rcgType;
        }

        public void setMediaPicture(byte[] picture) {
            MEDIA_PICTURE = picture;
        }

        public String getMediaLocation() {
            if (TextUtils.isEmpty(MEDIA_LOCATION)) {
                MEDIA_LOCATION = "no_media_location";
            }
            return MEDIA_LOCATION;
        }

        public String getMediaRcgType() {
            if (TextUtils.isEmpty(MEDIA_RCG_TYPE)) {
                MEDIA_RCG_TYPE = "no_media_rcg_type";
            }
            return MEDIA_RCG_TYPE;
        }

        public long getMediaLength() {
            return MEDIA_LENGTH;
        }

        public byte[] getMediaPicture() {
            if (MEDIA_PICTURE == null) {
                MEDIA_PICTURE = new byte[]{1};
            }
            return MEDIA_PICTURE;
        }

        public int getMediaType() {
            return MEDIA_TYPE;
        }

        public String getMediaId() {
            if (TextUtils.isEmpty(MEDIA_REMOTE_ID)) {
                MEDIA_REMOTE_ID = "no_media_id";
            }
            return MEDIA_REMOTE_ID;
        }

        public String getMediaServerId() {
            if (TextUtils.isEmpty(MEDIA_SERVER_ID)) {
                MEDIA_SERVER_ID = "no_server_id";
            }
            return MEDIA_SERVER_ID;
        }

        public long getMediaSize() {
            return MEDIA_SIZE;
        }

        /**
         * If it's a local video, get tab of video.
         *
         * @return "gallery" or "my_videos"
         */
        public String getMediaTab() {
            if (TextUtils.isEmpty(MEDIA_REMOTE_ID)) {
                MEDIA_REMOTE_ID = "no_media_tab";
            }
            return MEDIA_REMOTE_ID;
        }

        public String getMediaName() {
            if (TextUtils.isEmpty(MEDIA_TITLE)) {
                MEDIA_TITLE = "no_media_name";
            }
            return MEDIA_TITLE;
        }

    }

    /**
     * Get videos info.
     */
    public VideoInfo getVideoByIndex(int index) {
        if (!mLoadCompleted) {
            VideoInfo info = new VideoInfo();
            info.MEDIA_LOCATION = "no_play";
            return info;
        }

        VideoInfo info = mVideosList.get(index);
        if (info == null) {
            info = new VideoInfo();
            info.MEDIA_LOCATION = "no_play";
        }

        LogUtil.i(" getVideoByIndex index: " + index);
        LogUtil.i("   info.MEDIA_LOCATION: " + info.MEDIA_LOCATION);
        return info;
    }

    public int getVideosNumByUnity() {
        if (mLoadCompleted) {
            if (mLoadThread != null && mLoadThread.isAlive()) {
                mLoadThread.interrupt();
            }
//            startLoadPicturesByUnity();
            return mVideosList.size();
        }
        return -1;
    }

    public void startGetVideosByUnity() {
        // Re-start get videos, mVideosList need clear.
        mVideosList.clear();
        mLoadCompleted = false;

        mLoadThread = new Thread(new Runnable() {
            @Override
            public void run() {
                mLoadCompleted = false;
                getVideos();
                mLoadCompleted = true;
            }
        });
        mLoadThread.start();
    }

    public void updateVideo(String Uri) {

        for (VideoInfo info : mVideosList) {

            if (Uri.equals(info.getMediaLocation())) {

//                info.MEDIA_RCG_TYPE = ;
//                info.MEDIA_PICTURE;
//                VideoInfo newInfo;
//                int index = mVideosList.indexOf(info);
//                mVideosList.set(index, newInfo );
            }

        }

//        VideoInfo info = mVideosList.indexOf();

    }

    /**
     * Get history info.
     */
    public VideoInfo getHistoryByIndex(int index) {
        if (!mLoadHistoryCompleted) {
            VideoInfo info = new VideoInfo();
            info.MEDIA_LOCATION = "no_play";
            return info;
        }

        VideoInfo info = mHistoryList.get(index);
        if (info == null) {
            info = new VideoInfo();
            info.MEDIA_LOCATION = "no_play";
        }
        return info;
    }

    public int getHistoryNumByUnity() {
        if (mLoadHistoryCompleted) {
            if (mLoadHistoryThread != null && mLoadHistoryThread.isAlive()) {
                mLoadHistoryThread.interrupt();
            }
            return mHistoryList.size();
        }
        return -1;
    }

    public void startGetHistoryByUnity() {
        // mHistoryList need clear.
        mHistoryList.clear();
        mLoadHistoryCompleted = false;

        mLoadHistoryThread = new Thread(new Runnable() {
            @Override
            public void run() {
                mLoadHistoryCompleted = false;
                getHistory();
                mLoadHistoryCompleted = true;
            }
        });
        mLoadHistoryThread.start();
    }

    /**
     * Get favourite info.
     */
    public VideoInfo getFavouriteByIndex(int index) {
        if (!mLoadFavouriteCompleted) {
            VideoInfo info = new VideoInfo();
            info.MEDIA_LOCATION = "no_play";
            return info;
        }

        VideoInfo info = mFavouriteList.get(index);
        if (info == null) {
            info = new VideoInfo();
            info.MEDIA_LOCATION = "no_play";
        }
        return info;
    }

    public int getFavouriteNumByUnity() {
        if (mLoadFavouriteCompleted) {
            if (mLoadFavouriteThread != null && mLoadFavouriteThread.isAlive()) {
                mLoadFavouriteThread.interrupt();
            }
            return mFavouriteList.size();
        }
        return -1;
    }

    public void startGetFavouriteByUnity() {
        // mFavouriteList need clear.
        mFavouriteList.clear();
        mLoadFavouriteCompleted = false;

        mLoadFavouriteThread = new Thread(new Runnable() {
            @Override
            public void run() {
                mLoadFavouriteCompleted = false;
                getFavourite();
                mLoadFavouriteCompleted = true;
            }
        });
        mLoadFavouriteThread.start();
    }

    public boolean isScanCompleted() {
        return mScanCompleted;
    }

//    public void startGetPlayVideoByUnity() {
//        mGetPlayThread = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                mGetPlayCompleted = false;
//                getExternalPlayVideoInfo();
//                mGetPlayCompleted = true;
//            }
//        });
//        mGetPlayThread.start();
//    }

//    public VideoInfo getPlayVideoInfoByUnity() {
//        if (mGetPlayCompleted) {
//            if (mGetPlayThread != null && mGetPlayThread.isAlive()) {
//                mGetPlayThread.interrupt();
//            }
//            return mPlayVideoInfo;
//        }
//        return null;
//    }

    public String getMyVideoPathKey() {
        return MY_VIDEO_PATH_KEY;
    }

    public int getAirPlayType() {
        return AIR_PLAY_TYPE;
    }

    public ServerInfo getConnectedServer() {

        if (m_UnityActivity == null) {
            Log.d(TAG, "get connected server, m_UnityActivity is null. " + m_UnityActivity);
            return null;
        }

        Uri uri = Uri.parse(PROVIDER_SERVER_URI);
        Cursor cursor = m_UnityActivity.getContentResolver().query(uri, null, null, null, null);

        ServerInfo serverInfo = null;

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                try {
                    int indexId = cursor.getColumnIndex("_id");
                    int indexName = cursor.getColumnIndex("name");
                    int indexIp = cursor.getColumnIndex("ip");
                    int indexPort = cursor.getColumnIndex("port");
                    if (indexId < 0 || indexName < 0 || indexIp < 0 || indexPort < 0) {
                        Log.d(TAG, "get connected server, getColumnIndex id, name, ip, port: "
                                + indexId + ", " + indexName + ", " + indexIp + ", " + indexPort);
                        serverInfo = new ServerInfo();
                        serverInfo.computerId = "no_id";
                        return serverInfo;
                    }

                    serverInfo = new ServerInfo();
                    serverInfo.computerId = cursor.getString(indexId);
                    serverInfo.computerName = cursor.getString(indexName);
                    serverInfo.ip = cursor.getString(indexIp);
                    serverInfo.port = cursor.getString(indexPort);

                } catch (IllegalStateException e) {
                    cursor.close();
                    Log.d(TAG, "get connected server, IllegalStateException: " + e.toString());
                }
            }
            cursor.close();
        }

        if (serverInfo == null) {
            serverInfo = new ServerInfo();
            serverInfo.computerId = "no_id";
        }

        return serverInfo;
    }

    private String decode(String string) {
        if (TextUtils.isEmpty(string)) {
            return "";
        }
        return Uri.decode(string);
    }

    public VideoInfo getExternalPlayVideoInfo() {

        mPlayVideoInfo = null;

        Uri uri = Uri.parse(PROVIDER_PLAY_URI);
        Cursor cursor = m_UnityActivity.getContentResolver().query(uri, null, null, null, null);

        VideoInfo video = null;

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                try {

                    Log.d(TAG, "------**********-----");
                    Log.d(TAG, " MEDIA_LOCATION: " + cursor.getString(0));
                    Log.d(TAG, "   MEDIA_LENGTH: " + cursor.getString(2));
                    Log.d(TAG, "     MEDIA_TYPE: " + cursor.getString(3));
                    Log.d(TAG, "    MEDIA_TITLE: " + cursor.getString(4));
                    Log.d(TAG, "MEDIA_EXTERNAL_PLAY: " + cursor.getString(18));

                    video = new VideoInfo();
                    video.MEDIA_LOCATION = decode(cursor.getString(0));
                    video.MEDIA_TIME = cursor.getLong(1);
                    video.MEDIA_LENGTH = cursor.getLong(2);
                    video.MEDIA_TYPE = cursor.getInt(3);
                    video.MEDIA_TITLE = cursor.getString(4);
                    video.MEDIA_ARTIST = cursor.getString(5);
                    video.MEDIA_GENRE = cursor.getString(6);
                    video.MEDIA_ALBUM = cursor.getString(7);
                    video.MEDIA_ALBUMARTIST = cursor.getString(8);
                    video.MEDIA_WIDTH = cursor.getInt(9);
                    video.MEDIA_HEIGHT = cursor.getInt(10);
                    video.MEDIA_ARTWORKURL = cursor.getString(11);
                    video.MEDIA_AUDIOTRACK = cursor.getInt(12);
                    video.MEDIA_SPUTRACK = cursor.getInt(13);
                    video.MEDIA_TRACKNUMBER = cursor.getInt(14);
                    video.MEDIA_DISCNUMBER = cursor.getInt(15);
                    video.MEDIA_LAST_MODIFIED = cursor.getLong(16);
                    video.MEDIA_PICTURE = cursor.getBlob(17);
                    video.MEDIA_EXTERNAL_PLAY = cursor.getString(18);
                    video.MEDIA_RCG_TYPE = cursor.getString(19);
                    video.MEDIA_USER_RCG_TYPE = cursor.getString(20);
                    video.MEDIA_SIZE = cursor.getLong(21);
                    video.MEDIA_THUMBNAIL_URI = cursor.getString(22);
                    video.MEDIA_THUMBNAIL_WIDTH = cursor.getInt(23);
                    video.MEDIA_THUMBNAIL_HEIGHT = cursor.getInt(24);
                    video.MEDIA_REMOTE_ID = cursor.getString(25);

                } catch (IllegalStateException e) {
                    cursor.close();
                }
            }
            cursor.close();
        }

        if (video != null) {
            mPlayVideoInfo = video;
        } else {
            mPlayVideoInfo = new VideoInfo();
            mPlayVideoInfo.MEDIA_LOCATION = "no_play";
        }
        return mPlayVideoInfo;
    }

    private void getVideos() {

        mVideosList.clear();

        Uri uri = Uri.parse(PROVIDER_VIDEOS_URI);
        Cursor cursor = m_UnityActivity.getContentResolver().query(uri, null, null, null, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                try {
                    int count = 0;
                    do {
                        VideoInfo video = new VideoInfo();
                        video.MEDIA_LOCATION = decode(cursor.getString(0));
                        video.MEDIA_TIME = cursor.getLong(1);
                        video.MEDIA_LENGTH = cursor.getLong(2);
                        video.MEDIA_TYPE = cursor.getInt(3);
                        video.MEDIA_TITLE = cursor.getString(4);
                        video.MEDIA_ARTIST = cursor.getString(5);
                        video.MEDIA_GENRE = cursor.getString(6);
                        video.MEDIA_ALBUM = cursor.getString(7);
                        video.MEDIA_ALBUMARTIST = cursor.getString(8);
                        video.MEDIA_WIDTH = cursor.getInt(9);
                        video.MEDIA_HEIGHT = cursor.getInt(10);
                        video.MEDIA_ARTWORKURL = cursor.getString(11);
                        video.MEDIA_AUDIOTRACK = cursor.getInt(12);
                        video.MEDIA_SPUTRACK = cursor.getInt(13);
                        video.MEDIA_TRACKNUMBER = cursor.getInt(14);
                        video.MEDIA_DISCNUMBER = cursor.getInt(15);
                        video.MEDIA_LAST_MODIFIED = cursor.getLong(16);
                        video.MEDIA_PICTURE = cursor.getBlob(17);
                        video.MEDIA_EXTERNAL_PLAY = cursor.getString(18);
                        video.MEDIA_RCG_TYPE = cursor.getString(19);
                        video.MEDIA_USER_RCG_TYPE = cursor.getString(20);
                        video.MEDIA_SIZE = cursor.getLong(21);
                        video.MEDIA_THUMBNAIL_URI = cursor.getString(22);
                        video.MEDIA_THUMBNAIL_WIDTH = cursor.getInt(23);
                        video.MEDIA_THUMBNAIL_HEIGHT = cursor.getInt(24);
                        video.MEDIA_REMOTE_ID = cursor.getString(25);

                        mVideosList.add(video);
                        count++;

                        LogUtil.i("------------------ ");
                        LogUtil.i("     mVideosList.size: " + mVideosList.size());
                        LogUtil.i(" video.MEDIA_LOCATION: " + video.MEDIA_LOCATION);

                    } while (cursor.moveToNext() && count < 200);
                } catch (IllegalStateException e) {
                    cursor.close();
                }
            }
            cursor.close();
        }
    }

    public void removeVideoData(String locationUri) {
        int count = -1;
        try {
            count = m_UnityActivity.getContentResolver().delete(Uri.parse(PROVIDER_VIDEOS_URI), locationUri, null);
        } catch (IllegalArgumentException e) {
        }

        LogUtil.i("remove video data: " + locationUri);
        LogUtil.i("remove result: " + count);
    }

    /**
     * Add history into database.
     *
     * @param locationUri file:///xxx/xxx.xxx
     */
    public void addHistory(String locationUri, String name, long length, long size, String serverId) {

        ContentValues values = new ContentValues();
        values.put(HISTORY_URI, locationUri);
        values.put(HISTORY_TITLE, name);
//        values.put(HISTORY_ARTIST, mw.getArtist());
        values.put(HISTORY_TYPE, 0);
        values.put(HISTORY_LENGTH, length);
        values.put(HISTORY_FILE_SIZE, size);
        values.put(HISTORY_SERVER_ID, serverId);

        Uri uri = null;
        try {
            uri = m_UnityActivity.getContentResolver().insert(Uri.parse(PROVIDER_HISTORY_URI), values);
        } catch (IllegalArgumentException e) {
        }

        LogUtil.i("Add history: " + locationUri);
        LogUtil.i("Add history: " + uri);
    }

    public void removeHistory(String locationUri) {
        int count = -1;
        try {
            count = m_UnityActivity.getContentResolver().delete(Uri.parse(PROVIDER_HISTORY_URI), locationUri, null);
        } catch (IllegalArgumentException e) {
        }

        LogUtil.i("remove History: " + locationUri);
        LogUtil.i("remove result: " + count);
    }

    private void getHistory() {

        mHistoryList.clear();

        Cursor cursor = m_UnityActivity.getContentResolver().query(Uri.parse(PROVIDER_HISTORY_URI), null, null, null, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                try {
                    do {
                        LogUtil.i("-------------------");
                        LogUtil.i("       HISTORY_URI: " + cursor.getString(0));
                        LogUtil.i("     HISTORY_TITLE: " + cursor.getString(1));
                        LogUtil.i("    HISTORY_ARTIST: " + cursor.getString(2));
                        LogUtil.i("      HISTORY_TYPE: " + cursor.getInt(3));
                        LogUtil.i("    HISTORY_LENGTH: " + cursor.getLong(4));
                        LogUtil.i("      HISTORY_DATE: " + cursor.getString(5));
                        LogUtil.i(" HISTORY_FILE_SIZE: " + cursor.getLong(6));
                        LogUtil.i(" HISTORY_SERVER_ID: " + cursor.getString(7));

                        VideoInfo video = new VideoInfo();
                        video.MEDIA_LOCATION = decode(cursor.getString(0));
                        video.MEDIA_TITLE = cursor.getString(1);
                        video.MEDIA_LENGTH = cursor.getLong(4);
                        video.MEDIA_SIZE = cursor.getLong(6);
                        video.MEDIA_SERVER_ID = cursor.getString(7);

                        mHistoryList.add(video);

                    } while (cursor.moveToNext());
                } catch (IllegalStateException e) {
                }
            }
            cursor.close();
        }
    }

    public void addFavourite(String locationUri, String name, long length, long size, String serverId) {

        ContentValues values = new ContentValues();
        values.put(FAVOUR_URI, locationUri);
        values.put(FAVOUR_TITLE, name);
        values.put(FAVOUR_ICON_URL, "FAVOUR_ICON_URL");
        values.put(FAVOUR_LENGTH, length);
        values.put(FAVOUR_FILE_SIZE, size);
        values.put(FAVOUR_SERVER_ID, serverId);

        Uri uri = null;
        try {
            uri = m_UnityActivity.getContentResolver().insert(Uri.parse(PROVIDER_FAVOURITE_URI), values);
        } catch (IllegalArgumentException e) {
        }

        LogUtil.i("Add favourite: " + locationUri);
        LogUtil.i("Add result: " + uri);
    }

    public void removeFavourite(String locationUri) {

        int count = -1;
        try {
            count = m_UnityActivity.getContentResolver().delete(Uri.parse(PROVIDER_FAVOURITE_URI), locationUri, null);
        } catch (IllegalArgumentException e) {
        }

        LogUtil.i("remove favourite: " + locationUri);
        LogUtil.i("remove result: " + count);
    }

    private void getFavourite() {

        mFavouriteList.clear();

        Cursor cursor = m_UnityActivity.getContentResolver().query(Uri.parse(PROVIDER_FAVOURITE_URI), null, null, null, null);

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                try {
                    do {
                        LogUtil.i("-------------------");
                        LogUtil.i("       FAVOUR_URI: " + cursor.getString(0));
                        LogUtil.i("     FAVOUR_TITLE: " + cursor.getString(1));
                        LogUtil.i("  FAVOUR_ICON_URL: " + cursor.getString(2));
                        LogUtil.i("    FAVOUR_LENGTH: " + cursor.getLong(3));
                        LogUtil.i(" FAVOUR_FILE_SIZE: " + cursor.getLong(4));
                        LogUtil.i(" FAVOUR_SERVER_ID: " + cursor.getString(5));

                        VideoInfo video = new VideoInfo();
                        video.MEDIA_LOCATION = decode(cursor.getString(0));
                        video.MEDIA_TITLE = cursor.getString(1);
                        video.MEDIA_LENGTH = cursor.getLong(3);
                        video.MEDIA_SIZE = cursor.getLong(4);
                        video.MEDIA_SERVER_ID = cursor.getString(5);

                        mFavouriteList.add(video);

                    } while (cursor.moveToNext());
                } catch (IllegalStateException e) {
                }
            }
            cursor.close();
        }
    }

    public String getDeviceId() {
        if (m_UnityActivity != null) {
            String deviceId = AndroidDevices.getUniversalID(m_UnityActivity);
            if (TextUtils.isEmpty(deviceId)) {
                deviceId = "null";
            }
            LogUtil.d("deviceId: " + deviceId);
            AndroidDevices.setUserId(deviceId);
            return deviceId;
        }
        return null;
    }

    private byte[] bitmapToByteArray(Bitmap bitmap) {
        int bytes = bitmap.getByteCount();
        ByteBuffer buf = ByteBuffer.allocate(bytes);
        bitmap.copyPixelsToBuffer(buf);
        return buf.array();
    }

    public void saveBitmapToSdCard(Bitmap bitmap, String fileName) {

        String filePath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/TestImage";
        File f = new File(filePath);
        if (!f.exists()) {
            f.mkdir();
        }

        File imageFile = new File(filePath, fileName + ".png");

        try {
            FileOutputStream fos = new FileOutputStream(imageFile);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Must got Video list.
     */
    public void startLoadPicturesByUnity() {
        loadPictures();
    }

    private void loadPictures() {
        ArrayList<MediaWrapper> list = mMediaLibrary.getVideoItems();

        LogUtil.d("loadPictures: " + mVideosList.size());
        LogUtil.logStackTrace();

        FileRcgHelper fileHelper = FileRcgHelper.getInstance();
        ArrayList<String> invalidFiles = null;
        if (!fileHelper.isLogFileExists()) {
            /**
             * Check and filter invalid files path.
             */
            // 1. Check log file in Sdcard,
            //    and save invalid file path into file ".SKYBOX_invalid_files.txt" in Sdcard.
            fileHelper.checkAndReadLogFile();

            // 2. Delete all old log files and re-create new log file for this time scan.
            fileHelper.deleteAllLogFiles();
            fileHelper.createLogFileOnSdcard();

            // 3. Get invalid files path from file ".SKYBOX_invalid_files.txt".
            invalidFiles = fileHelper.readFromInvalidFile();
        }

        for (VideoInfo info : mVideosList) {
            if (TextUtils.isEmpty(info.MEDIA_LOCATION)) {
                continue;
            }
            if (info.MEDIA_LOCATION.contains("file://")) {

                String path = info.MEDIA_LOCATION.replace("file://", "");
                if (invalidFiles != null && invalidFiles.size() > 0
                        && invalidFiles.contains(path)) {
                    continue;
                }

            } else {
                // must be file://XXX
                continue;
            }

            for (MediaWrapper wm : list) {
                if (info.MEDIA_LOCATION.equals(decode(wm.getLocation()))) {
                    ImageLoader.loadLocalPicture(info, wm);
                }
            }
        }
    }

    public void loadPictureByUnity(String locationUri) {
        loadPicture(locationUri);
    }

    private void loadPicture(String locationUri) {
        ArrayList<MediaWrapper> list = mMediaLibrary.getVideoItems();
        for (VideoInfo info : mVideosList) {
            if (!info.MEDIA_LOCATION.isEmpty()
                    && info.MEDIA_LOCATION.equals(locationUri)) {
                for (MediaWrapper wm : list) {
                    if (info.MEDIA_LOCATION.equals(decode(wm.getLocation()))) {
                        wm.DO_HIGH_RCG = true;
                        ImageLoader.createLocalPicture(info, wm);
                    }
                }
            }
        }
    }

    public void clearVideoDataByUnity() {
        clearVideoData();
    }

    private void clearVideoData() {
        mVideosList.clear();
    }

    public void clearHistoryDataByUnity() {
        clearHistoryData();
    }

    private void clearHistoryData() {
        mHistoryList.clear();
    }

    public void clearFavouriteDataByUnity() {
        clearFavouriteData();
    }

    private void clearFavouriteData() {
        mFavouriteList.clear();
    }

    public long getMaxMemory() {
        return ((int) Runtime.getRuntime().maxMemory()) / 1024 / 1024;
    }

    public long getTotalMemory() {
        return ((int) Runtime.getRuntime().totalMemory()) / 1024 / 1024;
    }

    public long getFreeMemory() {
        return ((int) Runtime.getRuntime().freeMemory()) / 1024 / 1024;
    }

    public void startGooglePlay() {
        if (m_UnityActivity != null) {
            m_UnityActivity.runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        String packageName = m_UnityActivity.getPackageName();
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse("market://details?id=" + packageName));

                        if (intent.resolveActivity(m_UnityActivity.getPackageManager()) != null) {
                            // APP Google Play
                            Intent vrIntent = DaydreamApi.setupVrIntent(intent);
                            DaydreamApi.create(m_UnityActivity.getBaseContext()).launchInVr(vrIntent);

                        } else {
                            // HTTP Google Play
                            intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=" + packageName));
                            Intent vrIntent = DaydreamApi.setupVrIntent(intent);
                            if (intent.resolveActivity(m_UnityActivity.getPackageManager()) != null) {
                                DaydreamApi.create(m_UnityActivity.getBaseContext()).launchInVr(vrIntent);
                            }
                        }
                    } catch (Exception e) {
                        LogUtil.e("startGooglePlay " + e.getMessage());
                    }
                }
            });
        }
    }

    /**
     * Permission ----------------------------------------------------------------------------------
     */

    public boolean hasPermission(String permission) {
        if (m_UnityActivity == null) {
            LogUtil.e("UnityActivity is " + m_UnityActivity);
            return false;
        }

        return hasPermissionImpl(permission);
    }

    public boolean[] hasPermissions(String[] permissions) {
        if (permissions == null) {
            Log.w("PermissionsFragment", "No permission asked, no permissions returned");
            return new boolean[0];
        }

        int length = permissions.length;
        boolean[] grantResults = new boolean[length];
        for (int i = 0; i < length; i++) {
            LogUtil.d("Checking permission for " + permissions[i]);
            grantResults[i] = hasPermission(permissions[i]);
        }

        return grantResults;
    }

    private boolean hasPermissionImpl(String permission) {
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                LogUtil.d("Checking permission " + permission);
                return m_UnityActivity.checkSelfPermission(permission) == PERMISSION_GRANTED;//this is same to packageManager permission_granted
            } catch (Exception e) {
                String name = "BV:" + Build.VERSION.SDK_INT + " PE:" + permission;
                String reason = e.getMessage();
                String stackTraceString = LogUtil.getStackTrace(e);

                printExceptionLog(name, reason, stackTraceString);

                return activityCompatCheckSelfPermission(permission);
            }
        }
        return true;
    }

    private boolean activityCompatCheckSelfPermission(String permission) {
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                LogUtil.d("ActivityCompat Checking permission " + permission);
                return ActivityCompat.checkSelfPermission(m_UnityActivity.getBaseContext(), permission)
                        == PERMISSION_GRANTED;
            } catch (Exception e) {
                String name = "BV:" + Build.VERSION.SDK_INT + " PE:" + permission;
                String reason = e.getMessage();
                String stackTraceString = LogUtil.getStackTrace(e);

                printExceptionLog(name, reason, stackTraceString);
                return false;
            }
        }
        return true;
    }

    /**
     * Network info --------------------------------------------------------------------------------
     */
    public void getNetworkInfoForUnity() {
        if (m_UnityActivity == null) {
            LogUtil.e("UnityActivity is null. " + m_UnityActivity);
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                getNetworkInfoImpl();
            }
        }).start();
    }

    private void getNetworkInfoImpl() {
        Context context = SkyboxApplication.getAppContext();
        if (context == null) {
            LogUtil.e("UnityActivity is null. " + m_UnityActivity);
            return;
        }

        long time1T = LogUtil.currentTimeMillis();
        try {
            WifiManager wifiManager = ((WifiManager) context.getSystemService(WIFI_SERVICE));
            DhcpInfo dhcpInfo = wifiManager.getDhcpInfo();
            WifiInfo wifiInfo = wifiManager.getConnectionInfo();

            String ipAddress = intToIp(dhcpInfo.ipAddress);
            String netmask = intToIp(dhcpInfo.netmask);
            String gateway = intToIp(dhcpInfo.gateway);
            String serverAddress = intToIp(dhcpInfo.serverAddress);
            String dns1 = intToIp(dhcpInfo.dns1);
            String dns2 = intToIp(dhcpInfo.dns2);
            String leaseDuration = Integer.toString(dhcpInfo.leaseDuration);
            String wifiIpAddress = intToIp(wifiInfo.getIpAddress());
            String wifiMacAddress = wifiInfo.getMacAddress();

            NetworkEvent event = new NetworkEvent(ipAddress, netmask,
                    gateway, serverAddress, dns1, dns2, leaseDuration, wifiIpAddress, wifiMacAddress);
            Gson gson = new Gson();
            String gsonMsg = gson.toJson(event);
            UnityPlayer.UnitySendMessage("NetworkComponent", "GetNetworkInfo", gsonMsg);

            LogUtil.d("     ipAddress: " + ipAddress);
            LogUtil.d("       netmask: " + netmask);
            LogUtil.d("       gateway: " + gateway);
            LogUtil.d(" serverAddress: " + serverAddress);
            LogUtil.d("          dns1: " + dns1);
            LogUtil.d("          dns2: " + dns2);
            LogUtil.d(" leaseDuration: " + leaseDuration);
            LogUtil.d(" wifiIpAddress: " + wifiIpAddress);
            LogUtil.d("wifiMacAddress: " + wifiMacAddress);

        } catch (Exception e) {
            LogUtil.e("getNetworkInfoImpl Exception: " + e.getMessage());
        }
        long time2T = LogUtil.currentTimeMillis();
        LogUtil.duration(" getNetworkInfoImpl ", time1T, time2T);
    }

    private String intToIp(int paramInt) {
        return (paramInt & 0xFF) + "." + (0xFF & paramInt >> 8) + "." + (0xFF & paramInt >> 16) + "."
                + (0xFF & paramInt >> 24);
    }

    /**
     * Find media data. ----------------------------------------------------------------------------------
     */

    public void removeLocalScanReceiver() {
        removeReceiver(mLocalScanReceiver);
    }

    public void startScanVideos() {
        boolean isDirectoryMake = AndroidDevices.initMyVideoDir();

        mMediaLibrary = MediaLibrary.getInstance();
        initLocalScanActionReceiver();

        if (!mMediaLibrary.isWorking() && mMediaLibrary.getMediaItems().isEmpty()) {
            mMediaLibrary.scanMediaItems();
        }
    }

    private void initLocalScanActionReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(MediaUtils.ACTION_SCAN_START);
        filter.addAction(MediaUtils.ACTION_SCAN_STOP);
        addReceiver(filter, mLocalScanReceiver);
    }

    private void addReceiver(IntentFilter filter, BroadcastReceiver receiver) {
        LocalBroadcastManager.getInstance(m_UnityActivity).registerReceiver(receiver, filter);
    }

    private void removeReceiver(BroadcastReceiver receiver) {
        LocalBroadcastManager.getInstance(m_UnityActivity).unregisterReceiver(receiver);
    }

    private final BroadcastReceiver mLocalScanReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (action.equalsIgnoreCase(MediaUtils.ACTION_SCAN_START)) {
                LogUtil.d(" Action scan start receive. ");
                mScanCompleted = false;
            } else if (action.equalsIgnoreCase(MediaUtils.ACTION_SCAN_STOP)) {
                LogUtil.d(" Action scan stop receive. ");
                mScanCompleted = true;

                ArrayList<MediaWrapper> list = mMediaLibrary.getVideoItems();
                LogUtil.d(" list.size: " + list.size());
                for (MediaWrapper wm : list) {
                    LogUtil.d("Title: " + wm.getTitle());
                }
            }
        }
    };

}
