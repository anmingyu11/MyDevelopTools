package xyz.skybox.common;

import android.content.Context;
import android.content.res.Resources;


public class SkyboxApplicationProxy {

    private static Context instance;

    public static void setAppContext(Context context) {
        instance = context;
    }

    public static Context getAppContext() {
        return instance;
    }

    public static Resources getAppResources() {
        return instance.getResources();
    }

}
